from pydantic import BaseModel
from typing import List, Optional

class BoundingBox(BaseModel):
    x0: float
    y0: float
    x1: float
    y1: float

class Paragraph(BaseModel):
    text: str
    bbox: Optional[BoundingBox] = None
    block_type: Optional[str] = "text"

class HeaderCandidate(BaseModel):
    text: str
    bbox: Optional[BoundingBox] = None
    confidence: float = 0.0

class FooterCandidate(BaseModel):
    text: str
    bbox: Optional[BoundingBox] = None
    confidence: float = 0.0

class ImagePlaceholder(BaseModel):
    tag: str
    bbox: Optional[BoundingBox] = None

class TablePlaceholder(BaseModel):
    tag: str
    bbox: Optional[BoundingBox] = None

class Footnote(BaseModel):
    footnote_index: int
    reference_text: str
    text: str
    bbox: Optional[BoundingBox] = None

class Hyperlink(BaseModel):
    text: str
    url: str
    bbox: Optional[BoundingBox] = None

class PageLayout(BaseModel):
    page_number: int
    width: float
    height: float
    paragraphs: List[Paragraph] = []
    headers: List[HeaderCandidate] = []
    footers: List[FooterCandidate] = []
    images: List[ImagePlaceholder] = []
    tables: List[TablePlaceholder] = []
    footnotes: List[Footnote] = []
    hyperlinks: List[Hyperlink] = []

class DocumentLayout(BaseModel):
    total_pages: int
    pages: List[PageLayout] = []
