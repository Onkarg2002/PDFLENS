import os
import json
import logging
from pathlib import Path

from src.services.layout_engine import LayoutAnalysisEngine
from src.schema.layout_schema import DocumentLayout
from src.services.extractors.pdf_converter import convert_pdf_to_docx
from src.services.pipeline.document_pipeline import run_docx_pipeline
from src.services.docx_repair_engine import DOCXRepairEngine
from src.services.validation_engine import ValidationEngine

logger = logging.getLogger(__name__)

class LayoutGuidedPipeline:
    """
    The orchestrator for the new Layout-Guided DOCX Repair Pipeline.
    It separates Document Understanding (LayoutAnalysisEngine) from
    Document Generation (Win32 COM).
    """

    def __init__(self, pdf_path: str | Path, output_folder: str | Path):
        self.pdf_path = Path(pdf_path)
        self.output_folder = Path(output_folder)
        self.temp_docx_path = self.output_folder / "Temporary.docx"

    def run_stage_1_understanding(self) -> DocumentLayout:
        """Runs the Layout Analysis Engine to understand the original PDF."""
        logger.info("Starting Layout Analysis Engine...")
        with LayoutAnalysisEngine(self.pdf_path) as engine:
            layout_model = engine.build_initial_layout()
            logger.info(f"Layout Analysis complete. Extracted {layout_model.total_pages} pages.")
            return layout_model

    def run_stage_2_generation(self) -> Path:
        """
        Runs the existing Win32 COM pipeline to generate the Temporary DOCX.
        Images and tables will be replaced by placeholders as per the existing pipeline logic.
        """
        logger.info("Starting Word COM Generation for Temporary.docx...")
        
        # Ensure output folder exists
        os.makedirs(self.output_folder, exist_ok=True)
        
        # 1. Convert PDF to DOCX
        logger.info("Converting PDF to DOCX...")
        convert_pdf_to_docx(str(self.pdf_path), str(self.temp_docx_path))
        
        # 2. Run the existing pipeline
        # The existing pipeline handles replacing images/tables with <IMAGE_x> and <TABLE_x>
        run_docx_pipeline(
            pdf_path=str(self.pdf_path),
            doc_path=str(self.temp_docx_path),
            output_folder=str(self.output_folder),
            base_name=self.pdf_path.stem,
            extract_tables=True,
            extract_images=True,
            extract_header=False,
            extract_footer=False,
            extract_hyperlinks=True,
            extract_footnote=False,
            _word_instance=None # Use a fresh COM instance, or orchestrator should pass this
        )
        
        logger.info(f"Generated Temporary DOCX at {self.temp_docx_path}")
        return self.temp_docx_path

    def run_full_pipeline(self):
        """
        Executes the entire layout-guided pipeline sequentially.
        """
        # Phase 1 & 2 & 3: Understanding
        layout_model = self.run_stage_1_understanding()
        
        # Phase 4: Generation
        temp_docx = self.run_stage_2_generation()
        
        # Phase 5 & 6: Repair
        logger.info("Starting DOCX Repair Engine...")
        repair_engine = DOCXRepairEngine(temp_docx, layout_model)
        
        # Apply repairs
        repair_engine.repair_headers_and_footers()
        repair_engine.repair_footnotes_and_cleanup()
        repair_engine.repair_reading_order()
        
        # Save final repaired docx (for now overwriting temp, or save as final)
        final_docx_path = self.output_folder / f"{self.pdf_path.stem}_Repaired.docx"
        repair_engine.save(final_docx_path)
        logger.info(f"DOCX Repair complete. Saved to {final_docx_path}")
        
        # Phase 7: Validation & Output
        logger.info("Merging Layout Engine Headers/Footers into meta.json...")
        original_meta_path = self.output_folder / f"{self.pdf_path.stem}_meta.json"
        
        if original_meta_path.exists():
            with open(original_meta_path, 'r', encoding='utf-8') as f:
                meta_data = json.load(f)
                
            # meta_data is expected to be a list of page dicts
            if isinstance(meta_data, list):
                for page_dict in meta_data:
                    page_num = page_dict.get("page_number", 1)
                    # Find corresponding page in PyMuPDF Layout (1-indexed)
                    layout_page = next((p for p in layout_model.pages if p.page_number == page_num), None)
                    
                    if layout_page:
                        # Extract and combine headers
                        headers = [h.text.strip() for h in layout_page.headers if h.text.strip()]
                        page_dict["header"] = "\n".join(headers) if headers else ""
                        
                        # Extract and combine footers
                        footers = [f.text.strip() for f in layout_page.footers if f.text.strip()]
                        page_dict["footer"] = "\n".join(footers) if footers else ""
                        
            # Save the merged metadata
            merged_meta_path = self.output_folder / "meta.json"
            with open(merged_meta_path, 'w', encoding='utf-8') as f:
                json.dump(meta_data, f, indent=2)
            logger.info(f"Merged meta.json saved to {merged_meta_path}")
            return final_docx_path, merged_meta_path
            
        else:
            logger.warning(f"Could not find original meta.json at {original_meta_path}")
            return final_docx_path, original_meta_path

if __name__ == "__main__":
    pass
