from __future__ import annotations
import gc,json,os,queue,sys,threading,time,win32gui,win32con,pythoncom,win32com.client
from concurrent.futures import Future
from contextlib import contextmanager
from typing import Any, Callable, Optional
import pypdfium2 as pdfium
from src.constants.constant import (WD_GO_TO_PAGE, WD_GO_TO_ABSOLUTE,FOLDER_EXTRACTED_IMAGES,SUFFIX_FULL_ANALYSIS,)
from src.utils.file_util import safe_com, com_retry, pt_to_inch, ensure_dir
from src.services.extractors.image_extractor import (extract_images_from_range,register_pdf_cache, unregister_pdf_cache,)
from src.services.extractors.text_extractor import (extract_page_text, build_page_full_text,)
from src.services.extractors.table_extractor import (_build_table_record,)
from src.services.extractors.table_screenshot import close_pdf_cache
from src.services.extractors.header_footer_extractor import (extract_pdf_header_footer_zones, save_pdf_zones_json,apply_pdf_zones_to_docx, rescue_first_page_footer, rescue_page_footer,analyze_header_footer_range,extract_real_section_headers_footers,extract_layout_metadata,)
from src.services.extractors.footnote_extractor import (extract_footnotes_from_docx_xml,save_footnotes_json,)
from src.services.layout_fixer import (fix_docx_layout, fix_compatibility_flags, optimised_open_params,)
from src.services.pipeline.page_boundary import (set_page_boundary_logger,get_doc_content_end,invalidate_page_boundary_cache,refresh_content_end_after_mutation,safe_page_range,_ensure_page_starts,)


# Constants 
CHUNK_SIZE          = 20      
_SECTION_CACHE_MAX  = 64     
_GC_PAGE_INTERVAL   = 50    
_TICKER_INTERVAL    = 3.0  
_WARN_THRESHOLD_SEC = 60.0 

_RPC_UNAVAILABLE   = -2147023174   
_CALL_REJECTED     = -2147418111  
_STALE_COM_CODES   = {str(_RPC_UNAVAILABLE), str(_CALL_REJECTED),
                      hex(_RPC_UNAVAILABLE), hex(_CALL_REJECTED),
                      "800706ba", "80010001"}

# SENTINEL EXCEPTION  — stale persistent Word proxy

class StaleWordInstanceError(RuntimeError):
    """
    Raised when the injected _word_instance COM proxy is detected as stale
    (Word process has exited or become unreachable).

    worker.py catches this specific type, recycles the Word.Application,
    and retries the entire document job.  It must NOT be caught anywhere
    inside document_pipeline.py itself so it propagates cleanly to worker.py.
    """

def _is_stale_com_error(exc: Exception) -> bool:
    """Return True if exc looks like a dead/unreachable Word COM server."""
    msg = str(exc)
    return any(code in msg for code in _STALE_COM_CODES)


_PRINT_LOCK = threading.Lock()
_PIPELINE_LOGGER = None


def _log(msg: str = "") -> None:
    """Structured JSON log; preserves all pipeline observability."""
    global _PIPELINE_LOGGER
    if _PIPELINE_LOGGER is None:
        from src.utils.structured_log import configure_logging, get_logger
        configure_logging()
        _PIPELINE_LOGGER = get_logger("pdf_lens.pipeline")
    from src.utils.structured_log import log_event
    if msg:
        log_event(_PIPELINE_LOGGER, "pipeline", msg=msg, component="pipeline")


# LIVE TICKER  — heartbeat during any blocking operation

class _Ticker:
    """
    Prints 'still running...' every _TICKER_INTERVAL seconds while a
    blocking operation is in progress.

    Usage:
        with _Ticker("Step 1  PDF zones"):
            result = long_running_function()
    """

    def __init__(self, label: str):
        self._label  = label
        self._stop   = threading.Event()
        self._t0     = 0.0
        self._thread = None

    def __enter__(self):
        self._t0 = time.perf_counter()
        self._stop.clear()
        _log(f"  [{self._label}] starting...")
        self._thread = threading.Thread(
            target=self._run, daemon=True,
            name=f"Ticker-{self._label[:20]}")
        self._thread.start()
        return self

    def __exit__(self, *_):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)
        elapsed = time.perf_counter() - self._t0
        _log(f"  [{self._label}] done in {_fmt_min(elapsed)}")

    def _run(self):
        while not self._stop.wait(_TICKER_INTERVAL):
            elapsed = time.perf_counter() - self._t0
            _log(f"  [{self._label}] still running... ({_fmt_min(elapsed)})")


# PROGRESS BAR  

class _ProgressBar:
    _BAR_WIDTH = 35

    def __init__(self, total: int, label: str = "Progress"):
        self.total    = max(total, 1)
        self.label    = label
        self._current = 0
        self._start_t = 0.0
        self._active  = False

    def start(self) -> None:
        self._start_t = time.perf_counter()
        self._active  = True
        self._render(0)

    def update(self, current: int) -> None:
        self._current = current
        if self._active:
            self._render(current)

    def finish(self) -> None:
        self._active = False
        self._render(self.total)
        with _PRINT_LOCK:
            sys.stdout.write("\n")
            sys.stdout.flush()

    def _render(self, current: int) -> None:
        pct     = current / self.total
        filled  = int(self._BAR_WIDTH * pct)
        bar     = "=" * filled + "-" * (self._BAR_WIDTH - filled)
        elapsed = time.perf_counter() - self._start_t
        eta_str = "ETA --:--"
        if current > 0:
            eta_str = f"ETA {_fmt_sec((elapsed / current) * (self.total - current))}"
        line = (f"  {self.label} [{bar}] {current}/{self.total} "
                f"{pct*100:5.1f}%  {_fmt_sec(elapsed)}  {eta_str}")
        with _PRINT_LOCK:
            sys.stdout.write("\r" + line)
            sys.stdout.flush()

# TIMING

def _fmt_sec(s: float) -> str:
    s = int(s)
    return f"{s//60}:{s%60:02d}"

def _fmt_min(s: float) -> str:
    s = int(round(s))
    m, sec = divmod(s, 60)
    if m == 0:   return f"{sec}s"
    if sec == 0: return f"{m}m"
    return f"{m}m {sec}s"


class _TimingLog:
    def __init__(self):
        self._entries: list[tuple[str, float]] = []
        self._start = time.perf_counter()

    @contextmanager
    def step(self, label: str):
        t0 = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - t0
            self._entries.append((label, elapsed))
            _log(f"  DONE  {label:<44}  {_fmt_min(elapsed)}")

    def summary(self) -> str:
        total_wall  = time.perf_counter() - self._start
        total_steps = sum(e for _, e in self._entries)
        col = 46
        sep = "=" * (col + 18)
        rows = [
            "", sep,
            f"  {'PIPELINE TIMING SUMMARY':^{col+16}}",
            sep,
            f"  {'Step':<{col}}  {'Duration':>8}  {'Share':>6}",
            "  " + "-" * (col + 16),
        ]
        for lbl, e in self._entries:
            pct = 100 * e / total_steps if total_steps else 0
            rows.append(f"  {lbl:<{col}}  {_fmt_min(e):>8}  {pct:5.1f}%")
        rows += [
            "  " + "-" * (col + 16),
            f"  {'Total wall-clock':<{col}}  {_fmt_min(total_wall):>8}",
            sep, "",
        ]
        return "\n".join(rows)

# PDF CACHE STUBS

def _open_pdf_cache(pdf_path: str) -> None:
    if pdf_path and os.path.isfile(pdf_path):
        _log(f"  [pdf_cache] lazy mode (no preload): {os.path.basename(pdf_path)}")


def _close_pdf_cache_entry(pdf_path: str) -> None:
    pass

# COM STA WORKER THREAD

class _COMWorker:
    """
    All Word COM calls run on one dedicated STA thread.
    Callers submit a lambda via run() and block until the result arrives.
    A heartbeat line is printed every _TICKER_INTERVAL seconds so CMD
    never goes silent during long Word operations.
    """

    def __init__(self):
        self._task_queue: queue.Queue = queue.Queue()
        self._thread = threading.Thread(
            target=self._loop, name="COMWorkerSTA", daemon=True)
        self._word = None

    def start(self) -> None:
        _log("  [COM] Starting STA worker thread...")
        self._thread.start()
        ready = Future()
        self._task_queue.put(("_init", ready))
        _log("  [COM] Waiting for Word to launch (up to 2 min)...")
        ready.result(timeout=120)
        _log("  [COM] Word launched and ready")

    def stop(self) -> None:
        _log("  [COM] Shutting down worker...")
        done = Future()
        self._task_queue.put(("_stop", done))
        try:
            done.result(timeout=30)
        except Exception:
            pass
        self._thread.join(timeout=10)
        _log("  [COM] Worker stopped")

    def run(self, fn: Callable, label: str = "COM call",
            timeout: float = 1800.0) -> Any:
        """
        Submit fn(word) to the STA thread and block until complete.
        Prints heartbeat every _TICKER_INTERVAL seconds.
        Prints WARNING if the call exceeds _WARN_THRESHOLD_SEC.
        """
        fut = Future()
        self._task_queue.put(("_call", fn, fut))

        t0       = time.perf_counter()
        warned   = False
        deadline = t0 + timeout

        _log(f"  [COM] >>> {label}")

        while True:
            remaining  = deadline - time.perf_counter()
            if remaining <= 0:
                raise TimeoutError(
                    f"[COM] '{label}' timed out after {timeout:.0f}s")

            wait_slice = min(_TICKER_INTERVAL, remaining)
            try:
                result  = fut.result(timeout=wait_slice)
                elapsed = time.perf_counter() - t0
                _log(f"  [COM] <<< {label}  ({_fmt_min(elapsed)})")
                if elapsed >= _WARN_THRESHOLD_SEC:
                    _log(f"  [WARNING] '{label}' took {_fmt_min(elapsed)}")
                return result
            except Exception as exc:
                from concurrent.futures import TimeoutError as _FT
                if not isinstance(exc, _FT):
                    _log(f"  [COM] ERROR in '{label}': {exc}")
                    raise

            elapsed = time.perf_counter() - t0
            _log(f"  [COM] '{label}' still running... ({_fmt_min(elapsed)})")

            if not warned and elapsed >= _WARN_THRESHOLD_SEC:
                _log(f"  [WARNING] '{label}' running for {_fmt_min(elapsed)}"
                     f" — Word may be waiting on a dialog")
                warned = True

    def _loop(self):
        pythoncom.CoInitialize() 
        # Suppress "Word will now convert your PDF…" popup before Word launches
        try:
            import winreg
            hive = winreg.HKEY_CURRENT_USER
            base = r"SOFTWARE\Microsoft\Office"
            for ver in ("16.0", "15.0", "14.0"):
                path = rf"{base}\{ver}\Word\Options"
                try:
                    with winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE) as k:
                        winreg.SetValueEx(k, "DontWarnPDFToWord", 0, winreg.REG_DWORD, 1)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            while True:
                item = self._task_queue.get()
                kind = item[0]

                if kind == "_init":
                    future = item[1]
                    try:
                        self._word               = win32com.client.DispatchEx("Word.Application")
                        self._word.Visible       = False
                        self._word.DisplayAlerts = 0
                        self._word.ScreenUpdating = False

                        _w = self._word
                        try:
                            _w.DisplayStatusBar = False
                        except Exception:
                            pass
                        for _opt, _val in (
                            ("DoNotPromptForConvert",            True),   # suppress PDF reflow popup
                            ("ConfirmConversions",               False),
                            ("Pagination",                       False),
                            ("CheckSpellingAsYouType",           False),
                            ("CheckGrammarAsYouType",            False),
                            ("CheckGrammarWithSpelling",         False),
                            ("ShowReadabilityStatistics",        False),
                            ("AutoFormatAsYouTypeApplyHeadings", False),
                            ("AutoFormatAsYouTypeApplyBullets",  False),
                        ):
                            try:
                                setattr(_w.Options, _opt, _val)
                            except Exception:
                                pass

                        future.set_result(True)
                    except Exception as e:
                        future.set_exception(e)

                elif kind == "_call":
                    _, fn, future = item
                    try:
                        future.set_result(fn(self._word))
                    except Exception as e:
                        future.set_exception(e)

                elif kind == "_stop":
                    future = item[1]
                    try:
                        if self._word is not None:
                            try:
                                self._word.Quit()
                            except Exception:
                                pass
                            del self._word
                            self._word = None
                        future.set_result(True)
                    except Exception as e:
                        future.set_exception(e)
                    break
        finally:
            pythoncom.CoUninitialize()



# WORD DIALOG AUTO-DISMISSER
_DISMISS_TARGET_TITLES = {"microsoft word", "word"}


def _collect_all_buttons(parent_hwnd: int) -> list[int]:
    buttons: list[int] = []
    def _cb(hwnd, _):
        if "button" in win32gui.GetClassName(hwnd).lower():
            buttons.append(hwnd)
        return True
    try:
        win32gui.EnumChildWindows(parent_hwnd, _cb, None)
    except Exception:
        pass
    return buttons


def _click_child_button(parent_hwnd: int, want_texts: list[str]) -> bool:
    for hwnd in _collect_all_buttons(parent_hwnd):
        label = win32gui.GetWindowText(hwnd).strip().lower().replace("&", "")
        for w in want_texts:
            if w in label:
                try:
                    win32gui.SendMessage(hwnd, win32con.BM_CLICK, 0, 0)
                except Exception:
                    pass
                return True
    return False


def _dismiss_word_window(hwnd: int, _) -> bool:
    if not win32gui.IsWindowVisible(hwnd):
        return True
    title = win32gui.GetWindowText(hwnd).strip().lower()
    if title not in _DISMISS_TARGET_TITLES:
        return True
    if _click_child_button(hwnd, ["save"]):
        _log("  [dismiss] clicked Save")
        return True
    if _click_child_button(hwnd, ["ok"]):
        _log("  [dismiss] clicked OK")
        return True
    if _click_child_button(hwnd, ["yes"]):
        _log("  [dismiss] clicked Yes")
        return True
    try:
        import win32api
        win32api.PostMessage(hwnd, win32con.WM_SYSKEYDOWN, ord("S"), 0)
    except Exception:
        pass
    return True


def _auto_dismiss_word(stop_event: threading.Event,
                        interval: float = 0.15) -> None:
    while not stop_event.is_set():
        try:
            win32gui.EnumWindows(_dismiss_word_window, None)
        except Exception:
            pass
        stop_event.wait(interval)


def start_dismiss_thread() -> tuple[threading.Event, threading.Thread]:
    stop = threading.Event()
    t    = threading.Thread(target=_auto_dismiss_word,
                             args=(stop,), daemon=True)
    t.start()
    return stop, t



# SAFE DOCUMENT CLOSE

def _close_doc_safely(doc, max_retries: int = 8) -> None:
    for attempt in range(max_retries):
        try:
            doc.Close(SaveChanges=0)
            return
        except Exception as exc:
            err     = str(exc).lower()
            is_busy = any(kw in err for kw in
                          ("rejected", "callee", "-2147418111"))
            if attempt < max_retries - 1 and is_busy:
                _log(f"  [close] Word busy retry {attempt+1}...")
                try:
                    def _enter(hwnd, _):
                        if win32gui.IsWindowVisible(hwnd) and \
                                win32gui.GetWindowText(hwnd).strip().lower() \
                                in _DISMISS_TARGET_TITLES:
                            win32gui.PostMessage(
                                hwnd, win32con.WM_KEYDOWN,
                                win32con.VK_RETURN, 0)
                        return True
                    win32gui.EnumWindows(_enter, None)
                except Exception:
                    pass
                time.sleep(0.8)
            else:
                _log(f"  [close] Close failed (ignored): {exc}")
                return



# DOCX HELPERS
def _read_docx_header_distance_pt(doc_path: str,
                                   fallback: float = 72.0) -> float:
    try:
        from docx import Document as _D
        sec = _D(doc_path).sections[0]
        emu = sec.header_distance
        if emu and emu > 0:
            return max(18.0, min(emu / 12700, 144.0))
    except Exception as e:
        _log(f"  [hdr_max_pt] {e}")
    return fallback


def _read_docx_footer_min_ratio(doc_path: str,
                                 fallback: float = 0.85) -> float:
    try:
        from docx import Document as _D
        sec   = _D(doc_path).sections[0]
        f_emu = sec.footer_distance or 0
        p_emu = sec.page_height     or 0
        if p_emu > 0 and f_emu > 0:
            ratio = 1.0 - (f_emu / 12700 * 2.5) / (p_emu / 12700)
            return max(0.70, min(ratio, 0.95))
    except Exception as e:
        _log(f"  [ftr_min_ratio] {e}")
    return fallback


def _quick_page_count(pdf_path: str) -> str:
    try:
        doc = pdfium.PdfDocument(pdf_path)
        n   = len(doc)
        doc.close()
        return str(n)
    except Exception:
        return "?"

# MAIN PIPELINE

def run_docx_pipeline(
    pdf_path:           str,
    doc_path:           str,
    output_folder:      str,
    base_name:          str,
    extract_tables:     bool = True,
    extract_images:     bool = True,
    extract_header:     bool = True,
    extract_footer:     bool = True,
    extract_hyperlinks: bool = True,
    extract_footnote:   bool = False,
    _word_instance      = None,  
) -> dict:

    try:
        sys.stdout.reconfigure(line_buffering=True)
    except AttributeError:
        pass

    timing = _TimingLog()

    pdf_path      = os.path.abspath(pdf_path) if pdf_path else ""
    doc_path      = os.path.abspath(doc_path)
    output_folder = os.path.abspath(output_folder)
    img_folder    = ensure_dir(os.path.join(output_folder,
                                             FOLDER_EXTRACTED_IMAGES))

    _log()
    _log("  " + "=" * 62)
    _log(f"  {'PDF -> DOCX PIPELINE':^62}")
    _log(f"  {os.path.basename(pdf_path or doc_path)[:62]:^62}")
    _log("  " + "=" * 62)
    _log(f"  pdf_path      : {pdf_path}")
    _log(f"  doc_path      : {doc_path}")
    _log(f"  output_folder : {output_folder}")
    _log()

    # PDF cache
    if pdf_path and os.path.isfile(pdf_path):
        _open_pdf_cache(pdf_path)
    else:
        _log("  [init] No PDF file — skipping cache.")

    # Start dialog dismisser 
    _log("  [init] Starting dialog-dismiss thread...")
    _stop_dismiss, _dismiss_thread = start_dismiss_thread()
    _log("  [init] Dismiss thread started")

    # start COM worker
    with timing.step("Word launch"), _Ticker("Word launch"):
        if _word_instance is not None:
    
            class _PersistentAdapter:
                def start(self_):
                    _log("  [COM] Reusing persistent Word instance (no launch)")

                def stop(self_):
                    _log("  [COM] Skipping Word shutdown (persistent instance)")

                def run(self_, fn, label="COM call", timeout=1800.0):
                    return _word_instance.run(fn, label=label, timeout=timeout)

            com = _PersistentAdapter()
            com.start()
        else:
            com = _COMWorker()
            com.start()

    try:
        # Step 1: PDF zones
        pdf_zones  = {}
        zones_path = ""
        if pdf_path and os.path.isfile(pdf_path):
            with timing.step("Step 1  PDF zones"), \
                 _Ticker("Step 1  PDF zones"):
                n_pages = _quick_page_count(pdf_path)
                _log(f"  [Step 1] {n_pages} pages — parsing header/footer zones...")
                hdr_max_pt    = _read_docx_header_distance_pt(doc_path)
                ftr_min_ratio = _read_docx_footer_min_ratio(doc_path)
                _log(f"  [Step 1] hdr_max={hdr_max_pt:.1f}pt  "
                     f"ftr_min={ftr_min_ratio:.3f}")
                pdf_zones  = extract_pdf_header_footer_zones(
                    pdf_path,
                    hdr_max_pt=hdr_max_pt,
                    ftr_min_ratio=ftr_min_ratio,
                )
                zones_path = save_pdf_zones_json(
                    pdf_zones, output_folder, base_name)
                _tmp_zones = os.path.join(
                    output_folder, f"_tmp_{base_name}_pdf_zones.json")
                try:
                    if os.path.isfile(zones_path):
                        os.replace(zones_path, _tmp_zones)
                        zones_path = _tmp_zones
                except Exception:
                    pass
                _log(f"  [Step 1] {len(pdf_zones)} zones extracted")
        else:
            _log("  [Step 1] No PDF — skipping zones.")

        # Step 2: Open DOCX 
        with timing.step("Step 2  Open DOCX"):
            _log(f"\n  [DEBUG] Opening DOCX: {doc_path}")

            def _open_doc(word):
                """
                Open the DOCX via COM with two stale-proxy guards:

                Guard A (pre-Open probe):
                    Verifies word.Documents is accessible BEFORE calling Open.
                    Catches Word processes that died between jobs.

                Guard B (Open call itself):
                    Wraps Documents.Open so that Word dying in the narrow
                    window between the probe passing and Open executing is
                    also caught.  Only RPC/call-rejected COM codes are treated
                    as stale — all other exceptions (bad path, corrupt file,
                    etc.) propagate as-is so they are NOT silently retried.

                Both guards raise StaleWordInstanceError so worker.py can
                recycle Word and retry the whole document.
                """
                _log("  [DEBUG] word.Documents.Open() — probe check...")

                try:
                    _ = word.Documents
                except Exception as _probe_exc:
                    _log(f"  [DEBUG] Guard A failed — proxy is stale: {_probe_exc}")
                    raise StaleWordInstanceError(
                        f"Word.Application COM proxy is stale before Open "
                        f"(Guard A): {_probe_exc}"
                    ) from _probe_exc

                try:
                    _log("  [DEBUG] Documents.Open() calling...")
                    d = word.Documents.Open(**optimised_open_params(doc_path))
                    _log("  [DEBUG] Documents.Open() returned OK")
                except StaleWordInstanceError:
                    raise  
                except Exception as _open_exc:
                    if _is_stale_com_error(_open_exc):
                        _log(f"  [DEBUG] Guard B — Word died during Open: {_open_exc}")
                        raise StaleWordInstanceError(
                            f"Word died during Documents.Open (Guard B): {_open_exc}"
                        ) from _open_exc
                    raise

                _log("  [DEBUG] fix_compatibility_flags()...")
                fix_compatibility_flags(d)
                _log("  [DEBUG] DOCX fully open and ready")
                return d

            doc = com.run(_open_doc, label="Documents.Open")

        # Step 3: Geometry + Save 
        with timing.step("Step 3  Geometry + Save"):
            if pdf_zones:
                _log("\n  [Step 3] fix_docx_layout...")
                com.run(lambda w, d=doc: fix_docx_layout(d, pdf_zones),
                        label="fix_docx_layout")

                _log("  [Step 3] apply_pdf_zones_to_docx...")
                com.run(lambda w, d=doc: apply_pdf_zones_to_docx(d, pdf_zones),
                        label="apply_pdf_zones_to_docx")

                _log("  [Step 3] rescue_first_page_footer...")
                com.run(lambda w, d=doc: rescue_first_page_footer(d, pdf_zones),
                        label="rescue_first_page_footer")

                def _save_no_repaginate(w, d=doc):
                    _log("  [DEBUG] Starting doc.Save()...")
                    d.Save()
                    _log("  [DEBUG] doc.Save() completed")

                com.run(_save_no_repaginate, label="doc.Save")
            else:
                _log("  [Step 3] No PDF zones — skipping geometry.")

        # Step 4: Layout metadata
        with timing.step("Step 4  Layout metadata"):
            _log("\n  [Step 4] extract_layout_metadata...")
            meta_path = com.run(
                lambda w, d=doc: extract_layout_metadata(
                    pdf_path if (pdf_path and os.path.isfile(pdf_path))
                    else "", d, output_folder, base_name,
                ),
                label="extract_layout_metadata",
            )
            if meta_path and os.path.isfile(meta_path):
                _tmp_meta = os.path.join(
                    output_folder, f"_tmp_{base_name}_layout_metadata.json")
                try:
                    os.replace(meta_path, _tmp_meta)
                    meta_path = _tmp_meta
                except Exception:
                    pass

        # Step 5: Tables
        with timing.step("Step 5  Table extraction"):
            total_tables = com.run(
                lambda w, d=doc: safe_com(lambda: d.Tables.Count, default=0),
                label="Tables.Count",
            )
            _log(f"\n  [Step 5] {total_tables} table(s) found")

            tbl_bar    = _ProgressBar(
                total=max(total_tables, 1), label="Tables")
            excel_path = ""

            tbl_bar.start()
            tables_data = com.run(
                lambda w, d=doc: _extract_tables_with_progress(
                    d, output_folder, pdf_path, pdf_zones,
                    extract_tables=extract_tables,
                    progress_cb=tbl_bar.update,
                ),
                label="extract_tables_full",
            )
            tbl_bar.finish()

        # Step 5.5: Footnotes
        footnotes_data: list = []
        if extract_footnote:
            with timing.step("Step 5.5 Footnotes"):
                _log("\n  [Step 5.5] Extracting footnotes...")
                footnotes_data = extract_footnotes_from_docx_xml(doc_path)
                _log(f"  [Step 5.5] {len(footnotes_data)} footnote(s) found")

        # Step 6: Document properties 
        with timing.step("Step 6  Fetch doc properties"):
            _log("\n  [Step 6] ComputeStatistics (total pages)...")
            total_pages, _doc_odd_even = com.run(
                lambda w, d=doc: (
                    d.Content.ComputeStatistics(2),
                    bool(safe_com(
                        lambda: d.PageSetup.OddAndEvenPagesHeaderFooter,
                        default=False)),
                ),
                label="ComputeStatistics + OddEven",
            )
            _log(f"  [Step 6] total_pages={total_pages}  "
                 f"odd_even={_doc_odd_even}")

        # Step 6.5: Semantic section header/footer pre-extract
        _semantic_hf_lookup: dict = {}
        if extract_header or extract_footer:
            with timing.step("Step 6.5 Semantic H/F"):
                _log("\n  [Step 6.5] extract_real_section_headers_footers...")
                _semantic_result = com.run(
                    lambda w, d=doc: extract_real_section_headers_footers(
                        d, img_folder,
                        pdf_zones=pdf_zones,
                        extract_images=extract_images,
                        odd_and_even=_doc_odd_even,
                    ),
                    label="extract_real_section_headers_footers",
                )
                _semantic_hf_lookup = _semantic_result.get("lookup", {})
                _log(f"  [Step 6.5] sections={_semantic_result.get('section_count', 0)}  "
                     f"lookup={len(_semantic_hf_lookup)}  "
                     f"rescue={_semantic_result.get('rescue_count', 0)}")
        else:
            _log("  [Step 6.5] Header/footer extraction disabled — skip.")

        # Step 7: Page-by-page loop
        _log(f"\n  [Step 7] Processing {total_pages} pages  "
             f"(chunk_size={CHUNK_SIZE})...")

        page_bar           = _ProgressBar(total=total_pages, label="Pages ")
        page_results: list[dict] = []
        _section_cache:    dict  = {}
        _diff_first_cache: dict  = {}
        _page_start_cache: dict[int, int] = {}
        pages_done = 0
        _global_img_idx    = 1
        _global_hl_counter = 1

        _doc_content_end_ref: dict[str, int] = {
            "value": com.run(
                lambda w, d=doc: get_doc_content_end(d),
                label="Content.End (page boundary cache)",
            ),
        }
        set_page_boundary_logger(_log)
        if _semantic_hf_lookup:
            com.run(
                lambda w, d=doc: refresh_content_end_after_mutation(
                    d, _doc_content_end_ref,
                    cache=_page_start_cache,
                    invalidate_from=1,
                    reason="step_6.5_semantic_hf",
                ),
                label="refresh Content.End after semantic H/F",
            )

        page_bar.start()

        for chunk_start in range(1, total_pages + 1, CHUNK_SIZE):
            chunk_end   = min(chunk_start + CHUNK_SIZE - 1, total_pages)
            chunk_label = f"Step 7  Pages {chunk_start:>3}-{chunk_end:<3}"

            with timing.step(chunk_label):
                chunk, _global_img_idx, _global_hl_counter = _process_page_chunk(
                    com=com, doc=doc,
                    page_start=chunk_start, page_end=chunk_end,
                    total_pages=total_pages,
                    _doc_odd_even=_doc_odd_even,
                    pdf_zones=pdf_zones, img_folder=img_folder,
                    extract_images=extract_images,
                    extract_hyperlinks=extract_hyperlinks,
                    extract_tables=extract_tables,
                    extract_header=extract_header,
                    extract_footer=extract_footer,
                    _section_cache=_section_cache,
                    _diff_first_cache=_diff_first_cache,
                    progress_bar=page_bar,
                    pages_done_so_far=pages_done,
                    start_img_idx=_global_img_idx,
                    start_hl_counter=_global_hl_counter,
                    pdf_path=pdf_path,
                    page_start_cache=_page_start_cache,
                    doc_content_end_ref=_doc_content_end_ref,
                    semantic_hf_lookup=_semantic_hf_lookup,
                )
                pages_done     += len(chunk)
                page_results.extend(chunk)
                _flush_chunk(chunk, output_folder, base_name,
                             chunk_start, chunk_end)

                del chunk

            gc.collect()
            n_batches = (total_pages + CHUNK_SIZE - 1) // CHUNK_SIZE
            cur_batch = (chunk_start - 1) // CHUNK_SIZE + 1
            _log(f"  [batch {cur_batch}/{n_batches}] done "
                 f"pages {chunk_start}-{chunk_end}  "
                 f"({pages_done}/{total_pages} total)")

        page_bar.finish()

        # Delete temp pages_partial file
        _tmp_partial = os.path.join(
            output_folder, f"_tmp_{base_name}_pages_partial.jsonl")
        try:
            if os.path.isfile(_tmp_partial):
                os.remove(_tmp_partial)
        except Exception:
            pass

        # Step 8: Save JSONs
        with timing.step("Step 8  Save all JSONs"):
            _log("\n  [Step 8] Writing JSON output files...")
            saved_files = _save_all_jsons(
                page_results=page_results, tables_data=tables_data,
                output_folder=output_folder, base_name=base_name,
                excel_path=excel_path, meta_path=meta_path,
                doc_path=doc_path, zones_path=zones_path,
                extract_header=extract_header,
                extract_footer=extract_footer,
                extract_hyperlinks=extract_hyperlinks,
                extract_tables=extract_tables,
                extract_images=extract_images,
                footnotes_data=footnotes_data,
                extract_footnote=extract_footnote,
            )

        # Step 9: Close Word 
        with timing.step("Step 9  Close Word"):
            _log("\n  [Step 9] Closing Word...")

            def _close_word(w, d=doc):
                _log("  [DEBUG] Final doc.Save()...")
                try:
                    d.Save()
                except Exception:
                    pass
                time.sleep(0.3)
                _log("  [DEBUG] doc.Close()...")
                _close_doc_safely(d)

            com.run(_close_word, label="final Save + Close")

        # Summary 

        _NOISE_CHARS = {'/', '\\', '\x07', '\r', '\n', '\t', ' '}
        _seen_blocks: set = set()
        _full_text_parts: list = []
        for r in page_results:
            _ft = r.get("full_text", "")
            if not _ft:
                continue
            if all(c in _NOISE_CHARS for c in _ft):
                continue
            _ft_key = _ft.strip()
            if _ft_key in _seen_blocks:
                continue
            _seen_blocks.add(_ft_key)
            _full_text_parts.append(_ft)

        full_text    = "\n\n".join(_full_text_parts)
        tables_count = len(tables_data)
        images_count = sum(r["images_count"] for r in page_results)

        _log(timing.summary())
        _log("  Saved files:")
        for lbl, path in saved_files.items():
            if os.path.isfile(str(path)):
                _log(f"    {lbl:<26}: {path}")
        _log()

        return {
            "total_pages":  total_pages,
            "full_text":    full_text,
            "tables_count": tables_count,
            "images_count": images_count,
            "saved_files":  saved_files,
            "page_results": page_results,
        }

    finally:
        for _tmp_name in [
            f"_tmp_{base_name}_pdf_zones.json",
            f"_tmp_{base_name}_pages_partial.jsonl",
            f"_tmp_{base_name}_layout_metadata.json",
        ]:
            _tmp_p = os.path.join(output_folder, _tmp_name)
            try:
                if os.path.isfile(_tmp_p):
                    os.remove(_tmp_p)
            except Exception:
                pass
        try:
            com.stop()
        except Exception:
            pass
        _stop_dismiss.set()
        _dismiss_thread.join(timeout=3)
        if pdf_path and os.path.isfile(pdf_path):
            try:
                unregister_pdf_cache(pdf_path)
            except Exception:
                pass
            _close_pdf_cache_entry(pdf_path)
        try:
            close_pdf_cache()
        except Exception:
            pass
        gc.collect()
        _log("  [pipeline] Cleanup complete.")



# TABLE EXTRACTION WITH PROGRESS CALLBACK

def _extract_tables_with_progress(
    doc, output_folder: str, pdf_path: str, pdf_zones: dict,
    extract_tables: bool, progress_cb,
) -> list:
    from src.services.extractors.table_extractor import FOLDER_TABLE_SCREENSHOTS

    if not extract_tables:
        progress_cb(1)
        return []

    screenshot_folder = ensure_dir(
        os.path.join(output_folder, FOLDER_TABLE_SCREENSHOTS))
    total_tables = safe_com(lambda: doc.Tables.Count, default=0)
    if total_tables == 0:
        progress_cb(1)
        return []

    _log(f"  [tables] {total_tables} table(s) found — processing one by one...")
    tables_data: list = []

    _tables_col = doc.Tables

    for i in range(1, total_tables + 1):
        _log(f"  [tables] table {i}/{total_tables} ...")
        table = None
        try:
            table  = _tables_col(i)
            record = _build_table_record(
                doc, table, i, pdf_path, pdf_zones, screenshot_folder)
            tables_data.append(record)
        except Exception as exc:
            _log(f"  [tables] ERROR table {i}: {exc}")
            tables_data.append({"table_index": i, "error": str(exc)})
        finally:
            del table
            gc.collect()

        progress_cb(i)

    return tables_data


# STEP 7 — PAGE BOUNDARY CACHE  (reduces GoTo from ~2N to ~N per document)
def _goto_page_start_with_retry(doc, page_num: int) -> int:
    """
    Return the character index where *page_num* begins (1-based).
    Uses Word GoTo once per uncached page; retries on RPC_E_CALL_REJECTED.
    """
    from src.utils.file_util import _is_com_busy

    attempts = 0
    delay    = 0.5
    while True:
        try:
            rng = doc.GoTo(WD_GO_TO_PAGE, WD_GO_TO_ABSOLUTE, page_num)
            return int(rng.Start)
        except Exception as exc:
            if attempts < 5 and _is_com_busy(exc):
                attempts += 1
                _log(f"    [COM busy] GoTo p{page_num} retry {attempts}/5 "
                     f"in {delay:.1f}s …")
                time.sleep(delay)
                delay = min(delay * 2, 5.0)
            else:
                raise

def _ensure_page_start_cache(
    doc,
    cache: dict[int, int],
    page_from: int,
    page_to: int,
    total_pages: int,
) -> int:
    """Populate *cache* via shared page_boundary GoTo helper."""
    return _ensure_page_starts(doc, cache, page_from, page_to, total_pages)

def _shallow_copy_hf_info(cached: dict) -> dict:
    """
    Copy header/footer analysis dict for per-page mutation (text overrides).
    Shallow copy is sufficient — only top-level 'text' is updated downstream.
    """
    out = dict(cached)
    imgs = out.get("images")
    if isinstance(imgs, dict):
        out["images"] = dict(imgs)
    return out

# PAGE CHUNK PROCESSOR

def _process_page_chunk(
    com, doc,
    page_start: int, page_end: int, total_pages: int,
    _doc_odd_even: bool, pdf_zones: dict, img_folder: str,
    extract_images: bool, extract_hyperlinks: bool,
    extract_tables: bool, extract_header: bool, extract_footer: bool,
    _section_cache: dict, _diff_first_cache: dict,
    progress_bar: _ProgressBar, pages_done_so_far: int,
    start_img_idx: int = 1,
    start_hl_counter: int = 1,
    pdf_path: str = "",
    page_start_cache: Optional[dict[int, int]] = None,
    doc_content_end_ref: Optional[dict[str, int]] = None,
    semantic_hf_lookup: Optional[dict] = None,
) -> tuple[list[dict], int, int]:
    """Process a chunk of pages. Returns (results, next_img_idx, next_hl_counter)."""

    results: list[dict] = []
    img_idx    = start_img_idx
    hl_counter = start_hl_counter

    _pdf_text_cache: dict = {}
    _total_pdf = len(pdf_zones) if pdf_zones else 0
    if pdf_zones and _total_pdf > 0 and pdf_path and os.path.isfile(pdf_path):
        if _total_pdf < total_pages:
            _pdf_start = max(1, round(page_start * _total_pdf / total_pages))
            _pdf_end   = min(_total_pdf, round(page_end * _total_pdf / total_pages))
        else:
            _pdf_start, _pdf_end = page_start, min(page_end, _total_pdf)
        try:
            import pdfplumber as _ppl
            with _ppl.open(pdf_path) as _ppdf:
                _n_pdf = len(_ppdf.pages)
                for _pi in range(max(0, _pdf_start - 1), min(_n_pdf, _pdf_end)):
                    _ppg = _ppdf.pages[_pi]
                    _pt  = _ppg.extract_text() or ""
                    _z   = pdf_zones.get(_pi + 1, {})
                    for _blk in (_z.get("header_block", ""), _z.get("footer_block", "")):
                        if _blk:
                            _pt = _pt.replace(_blk, "")
                    _pdf_text_cache[_pi + 1] = _pt.strip()
                    try:
                        _ppg.close()
                    except Exception:
                        pass
            _log(f"  [pdf_text_cache] built {len(_pdf_text_cache)} page(s) "
                 f"(PDF pp {_pdf_start}-{_pdf_end}) for DOCX chunk {page_start}-{page_end}")
        except Exception as _ppl_err:
            _log(f"  [pdf_text_cache] error (non-fatal): {_ppl_err}")

    if page_start_cache is None:
        page_start_cache = {}
    if doc_content_end_ref is None:
        doc_content_end_ref = {"value": 0}

    def _run_chunk(word,
                   _pstart=page_start, _pend=page_end, _total=total_pages,
                   _odd_even=_doc_odd_even,
                   _zones=pdf_zones, _img_folder=img_folder,
                   _ext_img=extract_images, _ext_hl=extract_hyperlinks,
                   _ext_tbl=extract_tables, _ext_hdr=extract_header,
                   _ext_ftr=extract_footer,
                   _sec_cache=_section_cache, _df_cache=_diff_first_cache,
                   _start_img=img_idx, _start_hl=hl_counter,
                   _pdf_path=pdf_path,
                   _ptcache=_pdf_text_cache,
                   _page_cache=page_start_cache,
                   _content_end_ref=doc_content_end_ref,
                   _semantic_lookup=semantic_hf_lookup or {}):

        chunk_results: list[dict] = []
        _img_idx    = _start_img
        _hl_counter = _start_hl

        refresh_content_end_after_mutation(
            doc, _content_end_ref, cache=_page_cache,
            invalidate_from=_pstart, reason=f"chunk_start_{_pstart}")

        _new_gotos = _ensure_page_start_cache(
            doc, _page_cache, _pstart, _pend, _total)
        if _new_gotos:
            _log(f"  [page_boundaries] {len(_page_cache)} cached, "
                 f"{_new_gotos} new GoTo(s) for pages {_pstart}-{_pend}")

        for pn in range(_pstart, _pend + 1):

            page_rng, _pb_diag = safe_page_range(
                doc, pn, _page_cache, _total, _content_end_ref)
            if _pb_diag.get("repagination_events") or _pb_diag.get("fallback"):
                _log(
                    f"  [page_boundaries] p{pn} "
                    f"start={_pb_diag.get('start')} end={_pb_diag.get('end')} "
                    f"content_end={_pb_diag.get('content_end')} "
                    f"source={_pb_diag.get('cache_source')} "
                    f"retries={_pb_diag.get('retry_count')} "
                    f"repag={_pb_diag.get('repagination_events')} "
                    f"fallback={_pb_diag.get('fallback')}"
                )
            if page_rng is None:
                _log(f"  [page] {pn} SKIP — could not build safe page range")
                continue

            # Fast blank check via character span (avoids Characters.Count COM hop)
            if page_rng.End - page_rng.Start <= 1:
                _log(f"  [page] {pn} BLANK — skipping extractors")
                del page_rng
                continue

            section  = page_rng.Sections(1)

            sec_start = safe_com(lambda s=section: s.Range.Start, default=-pn)
            if sec_start not in _df_cache:
                _df_cache[sec_start] = bool(safe_com(
                    lambda s=section: s.PageSetup.DifferentFirstPageHeaderFooter,
                    default=False))
            _diff_first = _df_cache[sec_start]

            if pn == 1 and _diff_first:
                h_type = 2  
            elif _odd_even and pn % 2 == 0:
                h_type = 3  
            else:
                h_type = 1  

            _page_parity = "even" if pn % 2 == 0 else "odd"

            _footer_rescued = False
            if pn > 1 and _zones:
                _zone_ftr = _zones.get(pn, {})
                if _zone_ftr.get("footer_block", "").strip():
                    _footer_rescued = rescue_page_footer(
                        doc, pn, section, h_type,
                        _zone_ftr, total_pages=_total,
                        page_start_cache=_page_cache,
                        doc_content_end_ref=_content_end_ref,
                    )
                    if _footer_rescued:
                        refresh_content_end_after_mutation(
                            doc, _content_end_ref, cache=_page_cache,
                            invalidate_from=pn,
                            reason=f"rescue_page_footer_p{pn}",
                        )

            zone      = _zones.get(pn, {})
            cache_key = (sec_start, h_type)

            if cache_key not in _sec_cache:
                ps = section.PageSetup
                try:
                    _ps_vals = safe_com(
                        lambda p=ps: (p.TopMargin, p.BottomMargin, p.HeaderDistance, p.FooterDistance),
                        default=None)
                    _tm, _bm, _hd, _fd = _ps_vals if _ps_vals else (72, 72, 36, 36)
                except Exception:
                    _tm, _bm, _hd, _fd = 72, 72, 36, 36
                cached_ps = {
                    "top_margin_inch":               round(pt_to_inch(_tm), 4),
                    "bottom_margin_inch":             round(pt_to_inch(_bm), 4),
                    "header_dist_from_top_inch":      round(pt_to_inch(_hd), 4),
                    "footer_dist_from_bottom_inch":   round(pt_to_inch(_fd), 4),
                }
                _z = _zones.get(pn) if _zones else None
                _lk_hdr = (sec_start, h_type, True)
                _lk_ftr = (sec_start, h_type, False)
                if (_lk_hdr in _semantic_lookup
                        and not _footer_rescued):
                    cached_header_info = _shallow_copy_hf_info(
                        _semantic_lookup[_lk_hdr])
                else:
                    cached_header_info = analyze_header_footer_range(
                        section.Headers(h_type), _img_folder, f"p{pn}_hdr",
                        extract_images=_ext_img, page_number=pn,
                        pdf_zone=_z, is_header=True,
                        section_index=pn, hf_type=h_type,
                    )
                if (_lk_ftr in _semantic_lookup
                        and not _footer_rescued):
                    cached_footer_info = _shallow_copy_hf_info(
                        _semantic_lookup[_lk_ftr])
                else:
                    cached_footer_info = analyze_header_footer_range(
                        section.Footers(h_type), _img_folder, f"p{pn}_ftr",
                        extract_images=_ext_img, page_number=pn,
                        pdf_zone=_z, is_header=False,
                        section_index=pn, hf_type=h_type,
                    )
                _sec_cache[cache_key] = {
                    "ps":          cached_ps,
                    "header_info": cached_header_info,
                    "footer_info": cached_footer_info,
                }
                del ps
            else:
                cached_ps          = _sec_cache[cache_key]["ps"]
                cached_header_info = _sec_cache[cache_key]["header_info"]
                cached_footer_info = _sec_cache[cache_key]["footer_info"]

            header_info = _shallow_copy_hf_info(cached_header_info)
            footer_info = _shallow_copy_hf_info(cached_footer_info)

            text_data   = extract_page_text(
                page_rng,
                extract_hyperlinks_flag=_ext_hl,
                hyperlink_counter=_hl_counter,
                page_number=pn,
                extract_tables=_ext_tbl,
            )

            if _ext_img:
                _has_images = False
                try:
                    _shape_counts = safe_com(
                        lambda r=page_rng: (
                            r.InlineShapes.Count,
                            r.ShapeRange.Count,
                        ),
                        default=None,
                    )
                    if _shape_counts is not None:
                        _has_images = _shape_counts[0] > 0 or _shape_counts[1] > 0
                    else:
                        _has_images = True
                except Exception:
                    _has_images = True
                body_images = (
                    extract_images_from_range(
                        page_rng, _img_folder, page_number=pn,
                        start_img_idx=_img_idx)
                    if _has_images
                    else {"total_count": 0, "details": [], "next_img_idx": _img_idx}
                )
            else:
                body_images = {"total_count": 0, "details": [], "next_img_idx": _img_idx}

            page_hdr_text = header_info["text"].strip()
            page_ftr_text = footer_info["text"].strip()
            if (footer_info.get("has_page_field") and
                    zone.get("footer_block", "").strip()):
                page_ftr_text = zone["footer_block"].strip()
                footer_info["text"] = page_ftr_text
            if (header_info.get("has_page_field") and
                    zone.get("header_block", "").strip()):
                page_hdr_text = zone["header_block"].strip()
                header_info["text"] = page_hdr_text

    
            _pdf_page_idx = pn  
            if _zones and _total > 0:
                _total_pdf = len(_zones)
                if _total_pdf < _total:
                    _pdf_page_idx = max(1, min(_total_pdf,
                                               round(pn * _total_pdf / _total)))
            _pdf_zone_for_text = _zones.get(_pdf_page_idx, {}) if _zones else {}
            _pdf_chars_text = "\n".join(
                l["text"] for l in _pdf_zone_for_text.get("header_lines", [])
                if False  
            )  
            _pdf_header_block = _pdf_zone_for_text.get("header_block", "")
            _pdf_footer_block = _pdf_zone_for_text.get("footer_block", "")
            _pdf_all_lines = _pdf_zone_for_text.get("header_lines", []) + \
                             _pdf_zone_for_text.get("footer_lines", [])
            _pdf_fallback_text = _ptcache.get(_pdf_page_idx, "")

            page_full_text = build_page_full_text(
                content_lines=text_data["content_lines"],
                page_hdr_text=page_hdr_text,
                page_ftr_text=page_ftr_text,
                extract_tables=_ext_tbl,
                extract_header=_ext_hdr,
                extract_footer=_ext_ftr,
                extract_images=_ext_img,
                extract_hyperlinks=_ext_hl,
                hyperlinks=text_data["hyperlinks"],
                pdf_page_text=_pdf_fallback_text,
            )

            _NOISE_ONLY = {'/', '\\', '\x07', '\r', '\n', '\t'}
            if page_full_text and all(c in _NOISE_ONLY for c in page_full_text.strip()):
                page_full_text = _pdf_fallback_text.strip() or ""

            pdf_compare = {
                "pdf_header_text":      zone.get("header_block", ""),
                "pdf_footer_text":      zone.get("footer_block", ""),
                "pdf_header_height_pt": zone.get("header_height_pt", 0),
                "pdf_footer_height_pt": zone.get("footer_height_pt", 0),
                "header_ok":  bool(header_info["text"].strip()),
                "footer_ok":  bool(footer_info["text"].strip()),
                "header_semantic_confidence": header_info.get(
                    "semantic_confidence", 0),
                "footer_semantic_confidence": footer_info.get(
                    "semantic_confidence", 0),
                "header_extraction_source": header_info.get(
                    "extraction_source", "semantic"),
                "footer_extraction_source": footer_info.get(
                    "extraction_source", "semantic"),
            }

            result = {
                "page_number":  pn,
                "page_type":    _page_parity,
                "full_text":    page_full_text,
                "header_text":  page_hdr_text if _ext_hdr else "",
                "footer_text":  page_ftr_text if _ext_ftr else "",
                "tables_count": (text_data["tables_count"] if _ext_tbl else 0),
                "images_count": body_images["total_count"],
                "top_margin_inch":              cached_ps["top_margin_inch"],
                "bottom_margin_inch":            cached_ps["bottom_margin_inch"],
                "header_dist_from_top_inch":     cached_ps["header_dist_from_top_inch"],
                "footer_dist_from_bottom_inch":  cached_ps["footer_dist_from_bottom_inch"],
                "tables_found":        text_data["tables_count"],
                "images_in_body":      body_images,
                "line_by_line_format": text_data["content_lines"],
                "body_hyperlinks":     text_data["hyperlinks"],
                "header_format":       header_info,
                "footer_format":       footer_info,
                "pdf_zone_compare":    pdf_compare,
                "_next_img_idx":       body_images["next_img_idx"],
                "_next_hl_counter":    text_data["next_hl_counter"],
            }

            _img_idx    = body_images["next_img_idx"]
            _hl_counter = text_data["next_hl_counter"]

            del page_rng, section, text_data, body_images

            chunk_results.append(result)

            if len(_sec_cache) > _SECTION_CACHE_MAX:
                keys = list(_sec_cache.keys())
                for k in keys[: len(keys) - _SECTION_CACHE_MAX // 2]:
                    del _sec_cache[k]

            if pn % _GC_PAGE_INTERVAL == 0:
                gc.collect()
                _log(f"  [gc] collected after page {pn}")

        return chunk_results, _img_idx, _hl_counter

    chunk_label = f"pages {page_start}-{page_end}"
    chunk_results, next_img, next_hl = com.run(
        _run_chunk, label=chunk_label)

    for i, page_result in enumerate(chunk_results):
        img_idx    = page_result.get("_next_img_idx",    img_idx)
        hl_counter = page_result.get("_next_hl_counter", hl_counter)
        results.append(page_result)
        _log(f"  [page] {page_start + i}/{total_pages}  "
             f"(batch {page_start}-{page_end})")
        progress_bar.update(pages_done_so_far + len(results))

    return results, img_idx, hl_counter


# HELPERS

def _flush_chunk(chunk: list, output_folder: str,
                  base_name: str, start: int, end: int) -> None:
    path = os.path.join(
        output_folder, f"_tmp_{base_name}_pages_partial.jsonl")
    try:
        with open(path, "a", encoding="utf-8") as f:
            for r in chunk:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    except Exception as e:
        _log(f"  [flush_chunk] {e}")


def _build_image_entry(img: dict, img_id: int = 0) -> dict:
    # tag        : <doc_ai type='image' id=N>
    # image_path : extracted_images\doc_ai type='image' id=N.png
    tag       = f"<doc_ai type='image' id={img_id}>" if img_id else img.get("tag", "")
    # strip angle brackets, append .png  →  used as the physical filename
    tag_inner = tag.lstrip("<").rstrip(">")          # doc_ai type="image" id=N
    img_path  = (FOLDER_EXTRACTED_IMAGES + "\\" + tag_inner + ".png") if tag_inner else ""
    return {
        "image_path":  img_path,
        "image_name":  img.get("filename", img.get("image_name", "")),
        "extension":   img.get("extension", "png"),
        "caption":     img.get("caption", ""),
        "width_px":    img.get("width_px", 0),
        "height_px":   img.get("height_px", 0),
        "file_size":   img.get("file_size", ""),
        "image_type":  img.get("image_type", ""),
        "tag":         tag,
    }

def _build_full_analysis(
    page_results:       list,
    tables_data:        list,
    extract_tables:     bool = True,
    extract_images:     bool = True,
    extract_header:     bool = True,
    extract_footer:     bool = True,
    extract_hyperlinks: bool = True,
    footnotes_data:     list = None,
    extract_footnote:   bool = False,
) -> list:
    tables_by_page: dict = {}
    for tbl in tables_data:
        pn = tbl.get("page_number", 0)
        tables_by_page.setdefault(pn, []).append(tbl)

    footnotes_by_page: dict = {}
    if extract_footnote and footnotes_data:
        last_pn = page_results[-1]["page_number"] if page_results else 1
        for fn in footnotes_data:
            pn = fn.get("page_number", 0)
            if not pn or pn < 1:
                fn["page_number"] = last_pn
                pn = last_pn
            footnotes_by_page.setdefault(pn, []).append(fn)
    _global_img_id = 1

    output = []
    for pg in page_results:
        pn = pg["page_number"]

        if extract_images:
            body_details = pg.get("images_in_body", {}).get("details", [])
            hdr_details  = pg.get("header_format",  {}).get("images", {}).get("details", [])
            ftr_details  = pg.get("footer_format",  {}).get("images", {}).get("details", [])
            # Fix 1: assign sequential image IDs matching DOCX tags
            body_images_out = []
            for img in body_details:
                body_images_out.append(_build_image_entry(img, img_id=_global_img_id))
                _global_img_id += 1
            hdr_images_out = []
            for img in hdr_details:
                hdr_images_out.append(_build_image_entry(img, img_id=_global_img_id))
                _global_img_id += 1
            ftr_images_out = []
            for img in ftr_details:
                ftr_images_out.append(_build_image_entry(img, img_id=_global_img_id))
                _global_img_id += 1
            images = {
                "body":   body_images_out,
                "header": hdr_images_out,
                "footer": ftr_images_out,
            }
        else:
            body_details = []
            images = {"body": [], "header": [], "footer": []}

        page_tables = []
        for tbl in tables_by_page.get(pn, []):
            if "error" in tbl:
                page_tables.append(tbl)
                continue
            tbl_id  = tbl["table_index"]
            tbl_tag    = f"<doc_ai type='table' id={tbl_id}>"
            scr_folder = tbl.get("screenshot_folder", "")

            tbl_inner  = tbl_tag.lstrip("<").rstrip(">")   # doc_ai type="table" id=N
            tbl_path   = (scr_folder + "\\" + tbl_inner + ".png") if scr_folder else (tbl_inner + ".png")
            page_tables.append({
                "table_index":       tbl_id,
                "page_number":       tbl.get("page_number", pn),
                "rows":              tbl.get("rows", 0),
                "columns":           tbl.get("columns", 0),
                "caption":           tbl.get("caption", ""),
                "caption_position":  tbl.get("caption_position"),
                "caption_style":     tbl.get("caption_style", ""),
                "coordinates":       tbl.get("coordinates", {}),
                "screenshot_file":   tbl.get("screenshot_file"),
                "screenshot_folder": scr_folder,
                "table_path":        tbl_path,
                "tag":               tbl_tag,
            })

        if extract_header:
            hdr_fmt     = pg.get("header_format", {})
            header_text = hdr_fmt.get("text", "").strip()
            if not header_text or hdr_fmt.get("has_page_field"):
                header_text = (
                    pg.get("pdf_zone_compare", {})
                      .get("pdf_header_text", "")
                      .strip()
                )
        else:
            header_text = ""

        if extract_footer:
            ftr_fmt     = pg.get("footer_format", {})
            footer_text = ftr_fmt.get("text", "").strip()
            if not footer_text or ftr_fmt.get("has_page_field"):
                footer_text = (
                    pg.get("pdf_zone_compare", {})
                      .get("pdf_footer_text", "")
                      .strip()
                )
        else:
            footer_text = ""

        footnote_blocks = []
        if extract_footnote:
            for fn in footnotes_by_page.get(pn, []):
                footnote_blocks.append({
                    "type":   "footnote",
                    "text":   fn.get("text", ""),
                    "marker": fn.get("reference_text", ""),
                })

        page_entry = {
            "page_number": pn,
            "page_type":   pg["page_type"],
            "header":      header_text,
            "footer":      footer_text,
            "image":       images,
            "table":       page_tables,
        }
        if footnote_blocks:
            page_entry["footnotes"] = footnote_blocks

        output.append(page_entry)

    return output


def _save_all_jsons(
    page_results, tables_data, output_folder, base_name,
    excel_path, meta_path, doc_path, zones_path,
    extract_header, extract_footer, extract_hyperlinks,
    extract_tables=True, extract_images=True,
    footnotes_data=None, extract_footnote=False,
) -> dict:
    full_analysis = _build_full_analysis(
        page_results       = page_results,
        tables_data        = tables_data,
        extract_tables     = extract_tables,
        extract_images     = extract_images,
        extract_header     = extract_header,
        extract_footer     = extract_footer,
        extract_hyperlinks = extract_hyperlinks,
        footnotes_data     = footnotes_data,
        extract_footnote   = extract_footnote,
    )
    full_path = os.path.join(
        output_folder, f"{base_name}{SUFFIX_FULL_ANALYSIS}")
    raw = json.dumps(full_analysis, indent=2, ensure_ascii=False)
    raw = raw.replace('\\"', '"')
    with open(full_path, "w", encoding="utf-8") as f:
        f.write(raw)
    _log(f"  [json] full_analysis -> {os.path.basename(full_path)}")

    saved = {
        "full_analysis_json": full_path,
        "converted_docx":     doc_path,
    }

    return saved