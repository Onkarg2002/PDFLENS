"""
suppress_pdf_reflow_popup.py
────────────────────────────
One-shot utility: call suppress_word_pdf_reflow_popup() once at service
startup (before any Word instance is launched).  It writes the single
registry value that permanently eliminates the "Word will now convert your
PDF…" information dialog.

Run standalone to verify / apply:
    python suppress_pdf_reflow_popup.py
"""

import sys
import winreg


# ── Registry constants ────────────────────────────────────────────────────────
# The value lives under the user hive so it follows whichever Windows account
# the service runs as.  For a service account use HKEY_LOCAL_MACHINE instead
# (see _suppress_for_all_users() below).

_HIVE            = winreg.HKEY_CURRENT_USER
_OFFICE_BASE     = r"SOFTWARE\Microsoft\Office"
_WORD_SUBKEY     = r"Word\Options"
_VALUE_NAME      = "DontWarnPDFToWord"   # DWORD, 1 = never show the dialog
_VALUE_DATA      = 1
_VALUE_TYPE      = winreg.REG_DWORD

# Office version tokens to try, newest-first.
# The helper iterates them and writes to every version that exists.
_OFFICE_VERSIONS = (
    "16.0",   # Office 2016 / 2019 / 2021 / Microsoft 365
    "15.0",   # Office 2013
    "14.0",   # Office 2010
)


def _write_value(hive, subkey: str) -> None:
    """Open (or create) *subkey* under *hive* and write the suppression DWORD."""
    with winreg.CreateKeyEx(hive, subkey, 0, winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key, _VALUE_NAME, 0, _VALUE_TYPE, _VALUE_DATA)


def _read_value(hive, subkey: str):
    """Return (data, type) or None if the key / value is absent."""
    try:
        with winreg.OpenKey(hive, subkey, 0, winreg.KEY_READ) as key:
            return winreg.QueryValueEx(key, _VALUE_NAME)
    except FileNotFoundError:
        return None


def suppress_word_pdf_reflow_popup() -> list[str]:
    """
    Write DontWarnPDFToWord=1 under every Office/*/Word/Options key that
    belongs to the current user account.

    Returns a list of registry paths that were written.
    Raises nothing — all errors are printed and skipped so the service
    can still start even on locked-down machines.
    """
    written = []
    for ver in _OFFICE_VERSIONS:
        subkey = rf"{_OFFICE_BASE}\{ver}\{_WORD_SUBKEY}"
        try:
            _write_value(_HIVE, subkey)
            written.append(subkey)
        except PermissionError as exc:
            print(f"[suppress_popup] WARN  permission denied: {subkey} — {exc}",
                  file=sys.stderr)
        except Exception as exc:
            print(f"[suppress_popup] WARN  failed to write {subkey} — {exc}",
                  file=sys.stderr)
    return written


def verify_suppression() -> dict[str, object]:
    """Return a dict with one entry per Office version showing current state."""
    result = {}
    for ver in _OFFICE_VERSIONS:
        subkey = rf"{_OFFICE_BASE}\{ver}\{_WORD_SUBKEY}"
        val = _read_value(_HIVE, subkey)
        if val is None:
            result[ver] = "MISSING"
        else:
            data, _ = val
            result[ver] = "OK (suppressed)" if data == 1 else f"WRONG value={data}"
    return result


# ── Optional: for system-wide service accounts ───────────────────────────────

def suppress_for_all_users() -> list[str]:
    """
    Write under HKEY_LOCAL_MACHINE so the setting applies to every user on
    the machine (useful when the service runs as LocalSystem or a dedicated
    service account that has no interactive profile).

    Requires elevation (Administrator).
    """
    written = []
    for ver in _OFFICE_VERSIONS:
        subkey = rf"{_OFFICE_BASE}\{ver}\{_WORD_SUBKEY}"
        try:
            _write_value(winreg.HKEY_LOCAL_MACHINE, subkey)
            written.append(f"HKLM\\{subkey}")
        except PermissionError as exc:
            print(f"[suppress_popup] WARN  HKLM permission denied: {subkey} — {exc}",
                  file=sys.stderr)
        except Exception as exc:
            print(f"[suppress_popup] WARN  HKLM failed: {subkey} — {exc}",
                  file=sys.stderr)
    return written


# ── CLI / self-test ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Applying DontWarnPDFToWord registry fix …")
    written = suppress_word_pdf_reflow_popup()
    if written:
        print(f"  Written to: {len(written)} key(s)")
        for p in written:
            print(f"    HKCU\\{p}")
    else:
        print("  No keys written (all failed or Office not installed).")

    print("\nVerification:")
    for ver, state in verify_suppression().items():
        print(f"  Office {ver}: {state}")
