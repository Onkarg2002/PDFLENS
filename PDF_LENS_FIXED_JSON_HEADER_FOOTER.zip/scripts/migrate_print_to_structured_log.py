from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "src"

HEADER = '''from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("{logger_name}")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)


'''

SKIP = {
    "utils/structured_log.py",
}


def logger_name_for(path: Path) -> str:
    rel = path.relative_to(ROOT).with_suffix("")
    return "pdf_lens." + ".".join(rel.parts)


def migrate_file(path: Path) -> bool:
    rel = str(path.relative_to(ROOT)).replace("\\", "/")
    if rel in SKIP or "migrate_print" in rel:
        return False
    text = path.read_text(encoding="utf-8")
    if "print(" not in text:
        return False
    if "_slog" in text and "def _slog" in text:
        new_text = text.replace("print(", "_slog(")
        if new_text != text:
            path.write_text(new_text, encoding="utf-8")
            return True
        return False
    logger = logger_name_for(path)
    # insert after first block of imports / docstring
    lines = text.splitlines(keepends=True)
    insert_at = 0
    for i, line in enumerate(lines):
        if line.startswith("import ") or line.startswith("from "):
            insert_at = i + 1
    lines.insert(insert_at, "\n" + HEADER.format(logger_name=logger) + "\n")
    text = "".join(lines).replace("print(", "_slog(")
    path.write_text(text, encoding="utf-8")
    return True


def main() -> None:
    changed = []
    for path in sorted(ROOT.rglob("*.py")):
        if migrate_file(path):
            changed.append(path)
    print(f"migrated {len(changed)} files")


if __name__ == "__main__":
    main()
