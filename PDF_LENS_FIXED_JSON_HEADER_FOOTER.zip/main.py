"""
main.py — FastAPI entry + ProcessPoolExecutor lifecycle (COM worker pool).

Reliability:
  • Structured JSON logging for startup/shutdown
  • Health endpoint with executor readiness (/api/v1/health)
  • Graceful executor drain with configurable timeout
  • Forced worker termination if drain times out (crash-safe shutdown)
  • Shutdown flag blocks new /convert jobs during drain
"""
from __future__ import annotations

import asyncio
import multiprocessing
import os
import signal
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, TimeoutError as FuturesTimeout
from contextlib import asynccontextmanager
from typing import Any, Optional
from fastapi. openapi.docs import  get_swagger_ui_html
from fastapi.staticfiles import StaticFiles
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.routes.convert_route import router as convert_router
from src.utils.file_util import get_config, ensure_dir
from src.utils.structured_log import (
    LogTimer,
    bind_context,
    clear_context,
    configure_logging,
    get_logger,
    log_event,
    new_request_id,
)

configure_logging()
_LOG = get_logger("pdf_lens.main")

_MAX_JOBS_PER_WORKER: int = 8   # keep in sync with worker._MAX_JOBS_PER_WORKER
_MAX_POOL_WORKERS: int = 3
_DEFAULT_DRAIN_TIMEOUT_S: float = 120.0
_DEFAULT_FORCE_KILL_TIMEOUT_S: float = 30.0



# Structured logging


def _log(event: str, msg: str = "", **fields: Any) -> None:
    log_event(_LOG, event, msg=msg, component="main", **fields)



# Config helpers


def _pool_worker_count(cfg) -> int:
    configured = int(cfg.get("app", "workers", fallback=str(_MAX_POOL_WORKERS)))
    return max(1, min(configured, 4))


def _shutdown_drain_timeout_s(cfg) -> float:
    raw = cfg.get("app", "shutdown_drain_timeout_s",
                   fallback=str(_DEFAULT_DRAIN_TIMEOUT_S))
    try:
        return max(5.0, float(raw))
    except (TypeError, ValueError):
        return _DEFAULT_DRAIN_TIMEOUT_S


def _shutdown_force_timeout_s(cfg) -> float:
    raw = cfg.get("app", "shutdown_force_timeout_s",
                   fallback=str(_DEFAULT_FORCE_KILL_TIMEOUT_S))
    try:
        return max(5.0, float(raw))
    except (TypeError, ValueError):
        return _DEFAULT_FORCE_KILL_TIMEOUT_S



# Process pool shutdown (graceful drain → forced terminate)


def _iter_pool_processes(executor: ProcessPoolExecutor) -> list:
    """Return live child processes owned by the executor (CPython internal)."""
    procs = []
    processes_map = getattr(executor, "_processes", None)
    if not processes_map:
        return procs
    try:
        for p in processes_map.values():
            if p is not None and p.is_alive():
                procs.append(p)
    except Exception:
        pass
    return procs


def _terminate_pool_processes(
    executor: ProcessPoolExecutor,
    join_timeout_s: float,
    reason: str,
) -> int:
    """SIGTERM/SIGKILL pool worker processes that did not drain in time."""
    killed = 0
    for proc in _iter_pool_processes(executor):
        pid = proc.pid
        try:
            _log("pool_process_terminate", reason=reason, worker_pid=pid)
            proc.terminate()
            proc.join(timeout=join_timeout_s)
            if proc.is_alive():
                _log("pool_process_kill", reason=reason, worker_pid=pid)
                try:
                    proc.kill()
                except AttributeError:
                    pass
                proc.join(timeout=5.0)
            killed += 1
        except Exception as exc:
            _log("pool_process_terminate_failed", worker_pid=pid, error=str(exc))
    return killed


def _shutdown_executor_sync(
    executor: ProcessPoolExecutor,
    drain_timeout_s: float,
    force_timeout_s: float,
) -> dict:
    """
    Phase 1: shutdown(wait=True, cancel_futures=True) with drain timeout.
    Phase 2: shutdown(wait=False) + terminate surviving worker PIDs.
    """
    stats = {
        "drain_completed": False,
        "drain_timed_out": False,
        "processes_terminated": 0,
    }

    def _graceful_shutdown() -> None:
        try:
            executor.shutdown(wait=True, cancel_futures=True)
        except TypeError:
            executor.shutdown(wait=True)

    _log("executor_shutdown_start", drain_timeout_s=drain_timeout_s)

    with ThreadPoolExecutor(max_workers=1, thread_name_prefix="pool-drain") as helper:
        fut = helper.submit(_graceful_shutdown)
        try:
            fut.result(timeout=drain_timeout_s)
            stats["drain_completed"] = True
            _log("executor_drain_complete")
            return stats
        except FuturesTimeout:
            stats["drain_timed_out"] = True
            _log("executor_drain_timeout", drain_timeout_s=drain_timeout_s)

    try:
        executor.shutdown(wait=False, cancel_futures=True)
    except TypeError:
        try:
            executor.shutdown(wait=False)
        except Exception as exc:
            _log("executor_shutdown_abort_failed", error=str(exc))

    stats["processes_terminated"] = _terminate_pool_processes(
        executor, force_timeout_s, reason="shutdown_force",
    )
    _log("executor_shutdown_forced", **stats)
    return stats


async def _shutdown_executor_async(
    executor: ProcessPoolExecutor,
    drain_timeout_s: float,
    force_timeout_s: float,
) -> dict:
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(
        None,
        _shutdown_executor_sync,
        executor,
        drain_timeout_s,
        force_timeout_s,
    )


def _create_process_pool(max_workers: int) -> ProcessPoolExecutor:
    pool_kwargs: dict = {
        "max_workers": max_workers,
        "mp_context": multiprocessing.get_context("spawn"),
    }
    try:
        pool_kwargs["max_tasks_per_child"] = _MAX_JOBS_PER_WORKER
    except TypeError:
        pass
    return ProcessPoolExecutor(**pool_kwargs)


def _init_app_state(app: FastAPI, executor: ProcessPoolExecutor, max_workers: int) -> None:
    app.state.executor = executor
    app.state.executor_ready = True
    app.state.shutting_down = False
    app.state.pool_max_workers = max_workers
    app.state.started_at = time.time()
    app.state.shutdown_stats = None


def _mark_shutting_down(app: FastAPI) -> None:
    app.state.shutting_down = True
    app.state.executor_ready = False


def _clear_executor(app: FastAPI) -> None:
    app.state.executor = None
    app.state.executor_ready = False



# FastAPI lifespan


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Startup: spawn ProcessPoolExecutor and mark ready for /health + /convert.
    Shutdown: reject new jobs, drain in-flight work, force-kill if needed.
    """
    cfg = get_config()
    max_workers = _pool_worker_count(cfg)
    drain_timeout_s = _shutdown_drain_timeout_s(cfg)
    force_timeout_s = _shutdown_force_timeout_s(cfg)

    executor: Optional[ProcessPoolExecutor] = None
    try:
        executor = _create_process_pool(max_workers)
        _init_app_state(app, executor, max_workers)
        _log(
            "startup_complete",
            max_workers=max_workers,
            max_tasks_per_child=_MAX_JOBS_PER_WORKER,
            mp_start_method="spawn",
        )
    except Exception as exc:
        _log("startup_failed", error=str(exc))
        _clear_executor(app)
        raise

    try:
        yield
    finally:
        _mark_shutting_down(app)
        _log("shutdown_begin", drain_timeout_s=drain_timeout_s)

        if executor is not None:
            try:
                stats = await _shutdown_executor_async(
                    executor, drain_timeout_s, force_timeout_s,
                )
                app.state.shutdown_stats = stats
            except Exception as exc:
                _log("shutdown_error", error=str(exc))
                try:
                    _terminate_pool_processes(
                        executor, force_timeout_s, reason="shutdown_exception",
                    )
                except Exception as exc2:
                    _log("shutdown_force_failed", error=str(exc2))
            finally:
                _clear_executor(app)

        _log("shutdown_complete")



# App factory


def create_app() -> FastAPI:
    cfg = get_config()

    app = FastAPI(
        title=cfg.get("app", "title", fallback="DOC-AI"),
        description=cfg.get("app", "description", fallback=""),
        version=cfg.get("app", "version", fallback="1.0.0"),
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan,
    )
     
    # app.mount("/static",StaticFiles(directory="static"),name="static")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # @app.get("/",include_in_schema=False)
    # async def custom_swagger_ui_html():
    #     return get_swagger_ui_html(
    #         openapi_url=app.openapi_url,
    #         oauth2_redirect_url=app.swagger_ui_oauth2_redirect_url,
    #         swagger_js_url="/static/swagger-ui-bundle.js",
    #         swagger_css_url="/static/swagger-ui-css",
    #     )

    @app.middleware("http")
    async def structured_request_logging(request: Request, call_next):
        rid = request.headers.get("X-Request-ID") or new_request_id()
        bind_context(request_id=rid, component="api")
        t0 = time.perf_counter()
        try:
            response = await call_next(request)
            log_event(
                _LOG,
                "http_request",
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                request_id=rid,
                duration_ms=(time.perf_counter() - t0) * 1000.0,
            )
            response.headers["X-Request-ID"] = rid
            return response
        except Exception as exc:
            log_event(
                _LOG,
                "http_request_error",
                method=request.method,
                path=request.url.path,
                request_id=rid,
                duration_ms=(time.perf_counter() - t0) * 1000.0,
                error=str(exc),
                level=40,
            )
            raise
        finally:
            clear_context()

    ensure_dir(cfg.get("paths", "data_dir", fallback="./data"))
    ensure_dir(cfg.get("paths", "output_dir", fallback="./data/outputs"))
    ensure_dir(cfg.get("paths", "upload_dir", fallback="./data/uploads"))

    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        return JSONResponse(
            status_code=500,
            content={"status": "error", "message": str(exc)},
        )

    app.include_router(convert_router)

    @app.get("/", include_in_schema=False)
    async def root():
        return {
            "message": "DOC-AI",
            "docs": "/docs",
            "health": "/api/v1/health",
        }

    @app.get("/api/v1/health", tags=["PDF-LENS"], include_in_schema=True)
    async def health(request: Request):
        """
        Liveness/readiness probe.
        503 while starting, shutting down, or if the worker pool is unavailable.
        """
        shutting_down = bool(getattr(request.app.state, "shutting_down", False))
        executor_ready = bool(getattr(request.app.state, "executor_ready", False))
        executor = getattr(request.app.state, "executor", None)
        started_at = getattr(request.app.state, "started_at", None)
        uptime_s = round(time.time() - started_at, 1) if started_at else 0.0

        body = {
            "status": "ok",
            "service": cfg.get("app", "title", fallback="DOC-AI"),
            "version": cfg.get("app", "version", fallback="1.0.0"),
            "pid": os.getpid(),
            "executor_ready": executor_ready and executor is not None,
            "shutting_down": shutting_down,
            "pool_max_workers": getattr(request.app.state, "pool_max_workers", 0),
            "uptime_s": uptime_s,
        }

        if shutting_down:
            body["status"] = "shutting_down"
            return JSONResponse(status_code=503, content=body)

        if not executor_ready or executor is None:
            body["status"] = "starting"
            return JSONResponse(status_code=503, content=body)

        return body

    return app



# Application instance


app = create_app()



# Signal logging (best-effort — uvicorn owns the main loop)


def _install_signal_loggers() -> None:
    def _handler(signum, _frame):
        _log("signal_received", signal=signum)

    for sig in (getattr(signal, "SIGINT", None), getattr(signal, "SIGTERM", None)):
        if sig is None:
            continue
        try:
            signal.signal(sig, _handler)
        except (OSError, ValueError):
            pass



# Entry-point


if __name__ == "__main__":
    multiprocessing.freeze_support()
    _install_signal_loggers()

    cfg = get_config()
    title = cfg.get("app", "title", fallback="DOC-AI")
    version = cfg.get("app", "version", fallback="1.0.0")
    host = cfg.get("app", "host", fallback="0.0.0.0")
    port = int(cfg.get("app", "port", fallback="8000"))
    debug = cfg.getboolean("app", "debug", fallback=False)
    max_workers = _pool_worker_count(cfg)

    log_event(
        _LOG,
        "uvicorn_start",
        title=title,
        version=version,
        host=host,
        port=port,
        com_workers=max_workers,
        max_tasks_per_child=_MAX_JOBS_PER_WORKER,
        reload=debug,
        msg=(
            f"{title} v{version} — http://{host}:{port} "
            f"docs=/docs health=/api/v1/health "
            f"workers={max_workers}×{_MAX_JOBS_PER_WORKER}"
        ),
    )

    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=debug,
        workers=1,
        timeout_graceful_shutdown=_shutdown_drain_timeout_s(cfg) + _shutdown_force_timeout_s(cfg) + 30,
    )
