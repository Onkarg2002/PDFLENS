"""
tests/test_rc3_footnote_pagination.py
--------------------------------------
Regression tests for RC-3: footnote page-number extraction from
<w:lastRenderedPageBreak> markers in document.xml.

What these tests verify:
  1. Correct page assignment when markers exist and are fresh (post-repagination).
  2. That the staleness-check warning fires when implied_pages << expected_pages.
  3. That the extractor assigns page numbers according to marker positions,
     not paragraph ordinal — i.e. a layout mutation that shifts markers
     changes the extracted page numbers accordingly.

We exercise the pure-XML path (no Word COM) by building minimal DOCX ZIP
archives in memory with python-docx / lxml and injecting synthetic
<w:lastRenderedPageBreak> elements.

Run with:  python -m pytest tests/test_rc3_footnote_pagination.py -v
"""
import io
import sys
import types
import unittest
import zipfile
from unittest.mock import patch

# ---------------------------------------------------------------------------
# Minimal stubs so extractors import without COM dependencies
# ---------------------------------------------------------------------------
def _make_stub(name):
    m = types.ModuleType(name)
    sys.modules.setdefault(name, m)
    return m

for _mod in (
    "pdfplumber",
    "win32com", "win32com.client",
    "win32gui", "win32con",
    "pythoncom",
    "pypdfium2",
):
    _make_stub(_mod)

# ---------------------------------------------------------------------------
# Imports under test
# ---------------------------------------------------------------------------
from src.services.extractors.footnote_extractor import (   # noqa: E402
    extract_footnotes_from_docx_xml,
    _parse_document_xml,
)

# ---------------------------------------------------------------------------
# XML helpers
# ---------------------------------------------------------------------------
_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_NS_MAP = {"w": _W}

import xml.etree.ElementTree as ET  # noqa: E402


def _w(tag: str) -> str:
    return f"{{{_W}}}{tag}"


def _make_docx_xml(para_specs: list) -> bytes:
    """
    Build a minimal document.xml (bytes) containing exactly the paragraphs
    described by *para_specs*.

    Each entry in para_specs is a dict:
        {
            "page_break_before": bool,   # insert lastRenderedPageBreak at start
            "footnote_ids": [str, ...],  # footnoteReference ids in this para
            "text": str,                 # plain text content
        }

    Returns raw XML bytes suitable for embedding in a DOCX ZIP.
    """
    W = _W
    doc = ET.Element(_w("document"))
    body = ET.SubElement(doc, _w("body"))

    for spec in para_specs:
        p = ET.SubElement(body, _w("p"))

        if spec.get("page_break_before"):
            # Word puts lastRenderedPageBreak inside the first run
            r_pb = ET.SubElement(p, _w("r"))
            ET.SubElement(r_pb, _w("lastRenderedPageBreak"))

        # Footnote references (before text run, matching real DOCX structure)
        for fid in spec.get("footnote_ids", []):
            r_ref = ET.SubElement(p, _w("r"))
            ref = ET.SubElement(r_ref, _w("footnoteReference"))
            ref.attrib[_w("id")] = fid

        # Text content
        if spec.get("text"):
            r_txt = ET.SubElement(p, _w("r"))
            t = ET.SubElement(r_txt, _w("t"))
            t.text = spec["text"]

    return ET.tostring(doc, encoding="unicode").encode("utf-8")


def _make_footnotes_xml(footnote_map: dict) -> bytes:
    """
    Build a minimal footnotes.xml.
    *footnote_map*: {id_str: text_str}
    """
    root = ET.Element(_w("footnotes"))
    for fid, text in footnote_map.items():
        fn = ET.SubElement(root, _w("footnote"))
        fn.attrib[_w("id")] = fid
        p = ET.SubElement(fn, _w("p"))
        r = ET.SubElement(p, _w("r"))
        t = ET.SubElement(r, _w("t"))
        t.text = text
    return ET.tostring(root, encoding="unicode").encode("utf-8")


def _make_docx_zip(para_specs: list, footnote_map: dict) -> bytes:
    """Build a minimal DOCX (ZIP) in memory and return raw bytes."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("word/document.xml", _make_docx_xml(para_specs))
        zf.writestr("word/footnotes.xml", _make_footnotes_xml(footnote_map))
        zf.writestr("[Content_Types].xml",
                    '<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"></Types>')
    return buf.getvalue()


# ===========================================================================
# 1. Correct page assignment from fresh markers
# ===========================================================================
class TestCorrectPageAssignment(unittest.TestCase):
    """
    Build a DOCX where page breaks occur at known paragraph indices.
    Assert the extracted footnote page numbers match exactly.
    """

    def _para_specs_two_footnotes(self):
        """
        Simulates a 7-page document with footnotes on pages 3 and 7.

        Structure:
          p0  page 1  (no break, paragraph on page 1)
          p1  page 2  (lastRenderedPageBreak)
          p2  page 3  (lastRenderedPageBreak) ← footnote "1" on page 3
          p3  page 4  (lastRenderedPageBreak)
          p4  page 5  (lastRenderedPageBreak)
          p5  page 6  (lastRenderedPageBreak)
          p6  page 7  (lastRenderedPageBreak) ← footnote "2" on page 7
        """
        return [
            {"text": "Page 1 content"},
            {"page_break_before": True, "text": "Page 2 content"},
            {"page_break_before": True, "footnote_ids": ["1"], "text": "Page 3 content"},
            {"page_break_before": True, "text": "Page 4 content"},
            {"page_break_before": True, "text": "Page 5 content"},
            {"page_break_before": True, "text": "Page 6 content"},
            {"page_break_before": True, "footnote_ids": ["2"], "text": "Page 7 content"},
        ]

    def test_footnote_on_page_3_and_7(self):
        """Footnote refs on pages 3 and 7 must be extracted with those page numbers."""
        specs = self._para_specs_two_footnotes()
        footnote_map = {"1": "First footnote text.", "2": "Second footnote text."}
        docx_bytes = _make_docx_zip(specs, footnote_map)

        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
            tmp.write(docx_bytes)
            tmp_path = tmp.name

        try:
            result = extract_footnotes_from_docx_xml(tmp_path)
        finally:
            os.unlink(tmp_path)

        self.assertEqual(len(result), 2)
        by_id = {r["reference_text"]: r for r in result}

        self.assertEqual(by_id["1"]["page_number"], 3,
                         f"Footnote 1 expected on page 3, got {by_id['1']['page_number']}")
        self.assertEqual(by_id["2"]["page_number"], 7,
                         f"Footnote 2 expected on page 7, got {by_id['2']['page_number']}")

    def test_layout_mutation_shifts_page_assignment(self):
        """
        Simulates a layout mutation by constructing TWO docx versions:
        - Pre-mutation:  footnote "1" on page 3, footnote "2" on page 7.
        - Post-mutation: an extra page break inserted before page 3 pushes
                         footnote "1" to page 4, footnote "2" to page 8.

        The extractor should read page 4 and 8 in the post-mutation version
        (not the pre-mutation pages 3 and 7), demonstrating that when markers
        are refreshed after repagination, the correct post-layout pages are used.
        """
        footnote_map = {"1": "First footnote text.", "2": "Second footnote text."}

        # Pre-mutation layout: fn1 on p3, fn2 on p7
        pre_specs = [
            {"text": "Page 1"},
            {"page_break_before": True, "text": "Page 2"},
            {"page_break_before": True, "footnote_ids": ["1"], "text": "Page 3"},
            {"page_break_before": True, "text": "Page 4"},
            {"page_break_before": True, "text": "Page 5"},
            {"page_break_before": True, "text": "Page 6"},
            {"page_break_before": True, "footnote_ids": ["2"], "text": "Page 7"},
        ]
        # Post-mutation layout: extra page added before fn1, pushing both down by 1
        post_specs = [
            {"text": "Page 1"},
            {"page_break_before": True, "text": "Page 2"},
            {"page_break_before": True, "text": "Page 3 (new extra page from reflow)"},
            {"page_break_before": True, "footnote_ids": ["1"], "text": "Page 4"},
            {"page_break_before": True, "text": "Page 5"},
            {"page_break_before": True, "text": "Page 6"},
            {"page_break_before": True, "text": "Page 7"},
            {"page_break_before": True, "footnote_ids": ["2"], "text": "Page 8"},
        ]

        import tempfile, os

        # Extract pre-mutation
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
            tmp.write(_make_docx_zip(pre_specs, footnote_map))
            pre_path = tmp.name
        try:
            pre_result = extract_footnotes_from_docx_xml(pre_path)
        finally:
            os.unlink(pre_path)

        # Extract post-mutation
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp:
            tmp.write(_make_docx_zip(post_specs, footnote_map))
            post_path = tmp.name
        try:
            post_result = extract_footnotes_from_docx_xml(post_path)
        finally:
            os.unlink(post_path)

        pre_by_id  = {r["reference_text"]: r for r in pre_result}
        post_by_id = {r["reference_text"]: r for r in post_result}

        # Pre-mutation: pages 3 and 7
        self.assertEqual(pre_by_id["1"]["page_number"], 3)
        self.assertEqual(pre_by_id["2"]["page_number"], 7)

        # Post-mutation (fresh markers after repagination): pages 4 and 8
        self.assertEqual(post_by_id["1"]["page_number"], 4,
                         "After layout mutation footnote 1 should be on page 4")
        self.assertEqual(post_by_id["2"]["page_number"], 8,
                         "After layout mutation footnote 2 should be on page 8")

        # Critical regression assertion: post != pre
        self.assertNotEqual(pre_by_id["1"]["page_number"],
                            post_by_id["1"]["page_number"],
                            "Post-mutation page must differ from pre-mutation page")


# ===========================================================================
# 2. Stale-marker warning check
# ===========================================================================
class TestStaleMarkerWarning(unittest.TestCase):
    """
    If lastRenderedPageBreak markers imply far fewer pages than expected_pages,
    _parse_document_xml must log a LOUD STALE MARKER WARNING.
    """

    def _archive_with_n_breaks(self, n_breaks: int):
        """Build an archive with n_breaks page-break paragraphs."""
        para_specs = [{"text": "P1"}]
        for _ in range(n_breaks):
            para_specs.append({"page_break_before": True, "text": "P"})
        zip_bytes = _make_docx_zip(para_specs, {})
        buf = io.BytesIO(zip_bytes)
        return zipfile.ZipFile(buf, "r")

    def test_stale_marker_warning_fires(self):
        """
        Markers imply 3 pages but Word reports 20 → stale warning must be logged.
        """
        archive = self._archive_with_n_breaks(2)  # implies 3 pages (1 + 2 breaks)

        warnings = []
        import src.services.extractors.footnote_extractor as fe_mod
        orig_slog = fe_mod._slog

        def capturing_slog(msg="", event="log", **kw):
            warnings.append(str(msg))
            orig_slog(msg, event, **kw)

        fe_mod._slog = capturing_slog
        try:
            _parse_document_xml(archive, expected_pages=20)
        finally:
            fe_mod._slog = orig_slog

        stale_warnings = [w for w in warnings if "STALE MARKER WARNING" in w]
        self.assertTrue(
            stale_warnings,
            f"Expected a STALE MARKER WARNING, got log lines: {warnings}"
        )
        self.assertIn("3", stale_warnings[0])
        self.assertIn("20", stale_warnings[0])

    def test_no_stale_warning_when_pages_match(self):
        """When markers match expected_pages, no stale warning should appear."""
        archive = self._archive_with_n_breaks(6)  # implies 7 pages

        warnings = []
        import src.services.extractors.footnote_extractor as fe_mod
        orig_slog = fe_mod._slog

        def capturing_slog(msg="", event="log", **kw):
            warnings.append(str(msg))
            orig_slog(msg, event, **kw)

        fe_mod._slog = capturing_slog
        try:
            _parse_document_xml(archive, expected_pages=7)
        finally:
            fe_mod._slog = orig_slog

        stale_warnings = [w for w in warnings if "STALE MARKER WARNING" in w]
        self.assertFalse(stale_warnings,
                         f"Unexpected stale warning: {stale_warnings}")

    def test_no_stale_warning_when_expected_pages_zero(self):
        """When expected_pages=0 (not provided), no stale check is performed."""
        archive = self._archive_with_n_breaks(1)  # implies 2 pages

        warnings = []
        import src.services.extractors.footnote_extractor as fe_mod
        orig_slog = fe_mod._slog

        def capturing_slog(msg="", event="log", **kw):
            warnings.append(str(msg))
            orig_slog(msg, event, **kw)

        fe_mod._slog = capturing_slog
        try:
            _parse_document_xml(archive, expected_pages=0)
        finally:
            fe_mod._slog = orig_slog

        stale_warnings = [w for w in warnings if "STALE MARKER WARNING" in w]
        self.assertFalse(stale_warnings)


if __name__ == "__main__":
    unittest.main()
