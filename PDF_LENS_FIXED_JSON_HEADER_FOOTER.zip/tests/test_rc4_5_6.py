"""
tests/test_rc4_5_6.py
---------------------
Regression tests for:
  RC-4a — table split across pages (Information(3) on first cell)
  RC-4b — table caption scanning limits
  RC-5  — vertical line aspect ratio guard
  RC-6  — page skip placeholder
"""
import sys, types
import unittest
from unittest.mock import patch, MagicMock

# ---------------------------------------------------------------------------
# Minimal stubs so extractors import without COM dependencies
# ---------------------------------------------------------------------------
def _make_stub(name):
    m = types.ModuleType(name)
    sys.modules.setdefault(name, m)
    return m

for _mod in (
    "pdfplumber",
    "win32com", "win32com.client",
    "win32gui", "win32con",
    "pythoncom",
    "pypdfium2",
):
    _make_stub(_mod)

from src.services.extractors.table_extractor import _table_start_page_num, detect_table_caption
from src.services.extractors.image_extractor import extract_and_save_image
from src.services.pipeline.document_pipeline import _build_full_analysis
import src.services.extractors.table_extractor as te_mod

# ===========================================================================
# RC-4a: Table Start Page Number
# ===========================================================================
class TestTableStartPageNum(unittest.TestCase):
    def test_table_start_page_num_first_cell(self):
        """Should use the first cell's range if available."""
        mock_table = MagicMock()
        mock_table.Cell(1, 1).Range.Information.return_value = 5
        mock_table.Cell(1, 1).Range.Start = 100
        
        orig_safe_com = te_mod.safe_com
        try:
            def _passthrough(fn, default=None, **kw):
                try:
                    return fn()
                except Exception:
                    return default
            te_mod.safe_com = _passthrough
            
            page = _table_start_page_num(mock_table)
            self.assertEqual(page, 5)
        finally:
            te_mod.safe_com = orig_safe_com

# ===========================================================================
# RC-4b: Table Caption Clamping & Distribution
# ===========================================================================
class TestTableCaptionAndDistribution(unittest.TestCase):
    
    def test_caption_clamping_prevents_neighbor_steal(self):
        """
        Two tables 150 chars apart. If we don't clamp the 200-char window, 
        Table 1's search below might hit Table 2's caption.
        """
        doc = MagicMock()
        
        # Table 1: chars 100-200
        # Caption for Table 1: "Table 1: Foo" at char 210
        # Table 2: chars 350-450
        # Caption for Table 2: "Table 2: Bar" at char 340
        
        t1 = MagicMock()
        t2 = MagicMock()
        
        all_bounds = [(100, 200), (350, 450)]
        
        # Mock safe_doc_range to simulate paragraphs
        orig_safe_doc_range = te_mod.safe_doc_range
        
        def _mock_safe_doc_range(d, start, end, context=""):
            rng = MagicMock()
            rng.Paragraphs.Count = 1
            p = MagicMock()
            
            # If we are probing below Table 1
            if context == "caption_probe_below" and start == 200:
                # With clamping, end is min(350, 200+200=400) = 350.
                # So we search 200-350.
                if end <= 350:
                    p.Range.Text = "Table 1: First Caption\r"
                else:
                    # Without clamping, we search 200-400 and might hit Table 2's caption 
                    # if it was at 340, but since Table 2 is at 350, let's say the unclamped
                    # search just hits "Table 2: Bar" because it extends too far.
                    p.Range.Text = "Table 2: Bar\r"
            # If we are probing above Table 2
            elif context == "caption_probe_above" and end == 350:
                # With clamping, start is max(200, 350-200=150) = 200
                if start >= 200:
                    p.Range.Text = "Table 2: Second Caption\r"
                else:
                    p.Range.Text = "Table 1: First Caption\r"
            else:
                p.Range.Text = ""
                
            p.Range.Style.NameLocal = "Normal"
            rng.Paragraphs.First = p
            rng.Paragraphs.Last = p
            
            # Helper iterator
            def _mock_iter(*args):
                yield p
            rng.Paragraphs.__iter__ = _mock_iter
            rng.Paragraphs.__call__ = lambda x: p
            return rng
            
        te_mod.safe_doc_range = _mock_safe_doc_range
        
        try:
            # Test Table 1
            res1 = detect_table_caption(doc, t1, 100, 200, all_table_bounds=all_bounds)
            self.assertIn("Table 1", res1["caption_text"])
            self.assertNotIn("Table 2", res1["caption_text"])
            
            # Test Table 2
            res2 = detect_table_caption(doc, t2, 350, 450, all_table_bounds=all_bounds)
            self.assertIn("Table 2", res2["caption_text"])
            self.assertNotIn("Table 1", res2["caption_text"])
        finally:
            te_mod.safe_doc_range = orig_safe_doc_range

    def test_multi_page_table_distribution(self):
        """
        A table spanning pages 2 to 4 should be mapped to pages 2, 3, and 4
        in tables_by_page.
        """
        # _build_full_analysis expects specific structures
        page_results = [{"page_number": p, "page_type": "odd"} for p in range(1, 6)]
        tables_data = [
            {
                "table_index": 1,
                "page_number": 2,          # start page
                "page_number_end": 4,      # end page
                "text": "Huge table"
            }
        ]
        
        result = _build_full_analysis(page_results, tables_data)
        
        tables_by_page = {r["page_number"]: r["table"] for r in result}
        
        self.assertEqual(len(tables_by_page[1]), 0)
        self.assertEqual(len(tables_by_page[2]), 1)
        self.assertEqual(len(tables_by_page[3]), 1)
        self.assertEqual(len(tables_by_page[4]), 1)
        self.assertEqual(len(tables_by_page[5]), 0)
        self.assertEqual(tables_by_page[3][0]["table_index"], 1)


# ===========================================================================
# RC-5: Vertical Line Aspect Ratio Guard
# ===========================================================================
class TestVerticalLineGuard(unittest.TestCase):
    def test_vertical_line_skipped(self):
        """A vertical line (h/w > 20) should be skipped and return {}."""
        mock_shape = MagicMock()
        mock_shape.Type = 1 # Not a line type explicitly
        mock_shape.Width = 2.0
        mock_shape.Height = 100.0 # h/w = 50 > 20
        
        import src.services.extractors.image_extractor as ie_mod
        orig_safe_com = ie_mod.safe_com
        try:
            def _passthrough(fn, default=None, **kw):
                try:
                    return fn()
                except Exception:
                    return default
            ie_mod.safe_com = _passthrough
            
            result = extract_and_save_image(mock_shape, output_folder="/tmp")
            self.assertEqual(result, {}, "Vertical line should return empty dict")
        finally:
            ie_mod.safe_com = orig_safe_com

    def test_horizontal_line_skipped(self):
        """A horizontal line (w/h > 20) should be skipped and return {}."""
        mock_shape = MagicMock()
        mock_shape.Type = 1
        mock_shape.Width = 100.0
        mock_shape.Height = 2.0 # w/h = 50 > 20
        
        import src.services.extractors.image_extractor as ie_mod
        orig_safe_com = ie_mod.safe_com
        try:
            def _passthrough(fn, default=None, **kw):
                try:
                    return fn()
                except Exception:
                    return default
            ie_mod.safe_com = _passthrough
            
            result = extract_and_save_image(mock_shape, output_folder="/tmp")
            self.assertEqual(result, {}, "Horizontal line should return empty dict")
        finally:
            ie_mod.safe_com = orig_safe_com

from src.services.extractors.hf_region_classifier import _cluster_vector_graphics

# ===========================================================================
# RC-5: Vector Graphic Clustering
# ===========================================================================
class TestVectorGraphicsClustering(unittest.TestCase):
    def test_cluster_ignores_standalone_rules(self):
        """Should ignore elements with an aspect ratio > 20:1."""
        elements = [
            {"top": 10, "bottom": 11, "x0": 10, "x1": 310},  # horizontal rule (300:1)
            {"top": 10, "bottom": 310, "x0": 10, "x1": 11},  # vertical rule (1:300)
        ]
        clusters = _cluster_vector_graphics(elements)
        self.assertEqual(len(clusters), 0)

    def test_cluster_groups_dense_elements(self):
        """Should group overlapping/close elements into a single pseudo-image."""
        elements = [
            # 3 close elements representing a flowchart node
            {"top": 50, "bottom": 100, "x0": 50, "x1": 100},
            {"top": 55, "bottom": 95, "x0": 55, "x1": 95},
            {"top": 60, "bottom": 90, "x0": 60, "x1": 90},
            # A completely separate large diagram piece
            {"top": 400, "bottom": 500, "x0": 100, "x1": 200}, 
            {"top": 410, "bottom": 490, "x0": 110, "x1": 190},
            {"top": 420, "bottom": 480, "x0": 120, "x1": 180},
        ]
        clusters = _cluster_vector_graphics(elements)
        self.assertEqual(len(clusters), 2)
        
        # Verify bounding box of the first cluster
        c1 = clusters[0]
        self.assertEqual(c1["top"], 50)
        self.assertEqual(c1["bottom"], 100)
        self.assertEqual(c1["width"], 50)
        self.assertEqual(c1["name"], "vector_graphic_cluster")

if __name__ == "__main__":
    unittest.main()
