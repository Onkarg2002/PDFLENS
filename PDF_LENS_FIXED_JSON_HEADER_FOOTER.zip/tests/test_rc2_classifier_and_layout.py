"""
tests/test_rc2_classifier_and_layout.py
----------------------------------------
Regression tests for:
  RC-2  — body text misclassified as footer (hf_region_classifier.py)
  RC-2b — layout drift from global line spacing (layout_fixer.py)

Run with:  python -m pytest tests/test_rc2_classifier_and_layout.py -v
"""
import sys
import types
import unittest

# ---------------------------------------------------------------------------
# Minimal stubs for COM-heavy imports
# ---------------------------------------------------------------------------
def _make_stub(name):
    m = types.ModuleType(name)
    sys.modules.setdefault(name, m)
    return m

for _mod in (
    "pdfplumber",
    "win32com", "win32com.client",
    "win32gui", "win32con",
    "pythoncom",
    "pypdfium2",
):
    _make_stub(_mod)


# ---------------------------------------------------------------------------
# Imports under test
# ---------------------------------------------------------------------------
from src.services.extractors.hf_region_classifier import (   # noqa: E402
    build_text_blocks,
    compute_header_footer_score,
    CrossPageContext,
    TextBlock,
    _CONFIDENCE_THRESHOLD,
)
from src.services.layout_fixer import (                       # noqa: E402
    _sample_style_font_sizes,
    _clamp_pt,
    EXACT_SPACING_MULTIPLIER,
    _MIN_LINE_SPACING_PT,
    _MAX_LINE_SPACING_PT,
    _FALLBACK_FONT_PT,
)

# A4 page height in points (used throughout)
_A4_H = 841.7


# ===========================================================================
# RC-2a  Dual-guard region_hint
# ===========================================================================
class TestDualGuardRegionHint(unittest.TestCase):
    """
    A block whose midpoint is past 62% of page height should only receive
    region_hint='bottom' if its physical bottom is also within 100pt of the
    page bottom.  On a sparse page, body text ending at ~65% must stay 'body'.
    """

    def _make_line(self, top, bottom, text="Some text."):
        return {"text": text, "top_pt": top, "bottom_pt": bottom,
                "x0_pt": 72.0, "x1_pt": 400.0, "font_size": 11.0}

    def test_sparse_page_final_para_stays_body(self):
        """
        Midpoint at ~66% but bottom only at ~65% (well above 100pt-from-bottom).
        Even though mid > 0.62*page_height, the block must be classified 'body'.
        """
        # top=540, bottom=552 → mid=546, which is 64.9% of 841.7
        # bottom=552 → distance from page bottom = 841.7-552 = 289.7 pt (>100)
        lines = [self._make_line(540.0, 552.0, "This concludes the section.")]
        blocks = build_text_blocks(lines, page_num=1, page_height=_A4_H)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].region_hint, "body",
                         f"Got {blocks[0].region_hint!r} instead of 'body'")

    def test_genuine_footer_zone_gets_bottom_hint(self):
        """
        Block that is both past 62% AND within 100pt of the page bottom
        should receive region_hint='bottom'.
        """
        # top=760, bottom=772 → mid=766, which is 91% of 841.7
        # distance from page bottom = 841.7-772 = 69.7 pt (<100) ✓
        lines = [self._make_line(760.0, 772.0, "Page 5 of 20")]
        blocks = build_text_blocks(lines, page_num=1, page_height=_A4_H)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].region_hint, "bottom",
                         f"Got {blocks[0].region_hint!r} instead of 'bottom'")

    def test_top_block_still_top(self):
        """Blocks in the top 38% are unaffected by the new guard."""
        lines = [self._make_line(20.0, 32.0, "Chapter 1")]
        blocks = build_text_blocks(lines, page_num=1, page_height=_A4_H)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].region_hint, "top")

    def test_midpage_body_stays_body(self):
        """Classic mid-page body text is unaffected."""
        lines = [self._make_line(400.0, 412.0, "Body paragraph content here.")]
        blocks = build_text_blocks(lines, page_num=1, page_height=_A4_H)
        self.assertEqual(len(blocks), 1)
        self.assertEqual(blocks[0].region_hint, "body")


# ===========================================================================
# RC-2a  Short-block repetition gate
# ===========================================================================
class TestShortBlockRepetitionGate(unittest.TestCase):
    """
    A block with < 15 words that does NOT have cross-page repetition (rep < 0.5)
    AND is NOT a page-number field must be held below _CONFIDENCE_THRESHOLD,
    even if position + typography scores look good.
    """

    def _make_ctx(self):
        ctx = CrossPageContext(total_pages=10)
        ctx.body_top_band    = {1: 80.0}
        ctx.body_bottom_band = {1: 700.0}
        ctx.median_line_height = 12.0
        return ctx

    def _make_short_block(self, text, top=760.0, bottom=775.0, wc=None):
        wc = wc or len(text.split())
        return TextBlock(
            lines=[], text=text,
            top_pt=top, bottom_pt=bottom,
            x0_pt=72.0, x1_pt=400.0,
            font_size=11.0, line_count=1,
            word_count=wc, page_num=1,
            region_hint="bottom",
        )

    def test_short_non_repeating_block_blocked(self):
        """
        A perfectly punctuated 6-word sentence at the bottom of a sparse page
        must NOT pass the confidence threshold without repetition.
        """
        ctx = self._make_ctx()
        block = self._make_short_block("This concludes the introductory chapter.", wc=6)
        sc = compute_header_footer_score(block, False, ctx, [block])
        self.assertLess(sc["confidence"], _CONFIDENCE_THRESHOLD,
                        f"confidence={sc['confidence']} should be below {_CONFIDENCE_THRESHOLD}")

    def test_short_repeating_block_passes(self):
        """
        A short block (< 15 words) that genuinely repeats across many pages
        (rep >= 0.5) should still be allowed through.
        """
        ctx = self._make_ctx()
        fp_text = "ministry of housing urban affairs"
        # Seed the fingerprint to simulate repetition on 8/10 pages
        import re
        from src.services.extractors.hf_region_classifier import normalize_fingerprint
        fp = normalize_fingerprint(fp_text)
        ctx.fingerprint_pages[fp] = set(range(1, 9))  # pages 1-8
        block = self._make_short_block(fp_text, wc=5)
        sc = compute_header_footer_score(block, False, ctx, [block])
        # rep should be >= 0.5 with 8/10 pages, so gate should not suppress it
        self.assertGreaterEqual(sc["repetition_score"], 0.5)

    def test_page_number_field_not_blocked(self):
        """
        A short page-number field ('Page 5 of 20') must not be blocked
        even without cross-page repetition — pnum > 0 exempts it.
        """
        ctx = self._make_ctx()
        block = self._make_short_block("Page 5 of 20", wc=4)
        sc = compute_header_footer_score(block, False, ctx, [block])
        # page_number_score must be > 0 for this to be valid
        # The gate condition is: word_count<15 AND pnum==0 AND rep<0.5
        # Since pnum>0, gate does not apply — we just check it isn't erroneously hard-capped
        self.assertGreater(sc.get("position_score", 0), 0,
                           "Page-number block should have non-zero position score")


# ===========================================================================
# RC-2b  Per-style line spacing
# ===========================================================================
class TestPerStyleLineSpacing(unittest.TestCase):
    """
    Verify that _sample_style_font_sizes produces distinct entries for each
    unique style, and that the resulting AtLeast values scale with each
    style's own font size — NOT uniformly.
    """

    def _mock_doc(self, style_font_map):
        """
        Build a minimal mock 'doc' object whose story range has paragraphs
        with the given {style_name: font_pt} mapping.
        Each style appears exactly once in paragraph order.
        """
        class _Font:
            def __init__(self, size):
                self.Size = size

        class _Run:
            def __init__(self, font):
                self.Font = font

        class _Runs:
            def __init__(self, runs):
                self._runs = runs
                self.Count = len(runs)
            def __call__(self, idx):
                return self._runs[idx - 1]

        class _Style:
            def __init__(self, name, font_pt):
                self.NameLocal = name
                self.Font = _Font(font_pt)

        class _Para:
            def __init__(self, sname, font_pt):
                self.Style = _Style(sname, font_pt)
                run = _Run(_Font(font_pt))
                self.Runs = _Runs([run])

        class _Paras:
            def __init__(self, paras):
                self._paras = paras
                self.Count = len(paras)
            def __call__(self, idx):
                return self._paras[idx - 1]

        class _Story:
            def __init__(self, paras):
                self.Paragraphs = _Paras(paras)

        paras = [_Para(sname, fpt) for sname, fpt in style_font_map.items()]
        story = _Story(paras)

        class _Styles:
            def __call__(self, name):
                fpt = style_font_map.get(name, 12.0)
                class _S:
                    Font = _Font(fpt)
                return _S()

        class _Doc:
            Styles = _Styles()

        return _Doc(), story

    def test_distinct_styles_produce_distinct_sizes(self):
        """
        A document with Heading 1 (24pt), Normal (11pt), Caption (8pt) must
        produce three different AtLeast values, NOT a single uniform value.
        """
        style_font_map = {
            "Heading 1": 24.0,
            "Normal":    11.0,
            "Caption":    8.0,
        }
        doc, story = self._mock_doc(style_font_map)

        # Monkeypatch safe_com to be a direct call (no COM needed)
        import src.services.layout_fixer as lf_mod
        orig_safe_com = lf_mod.safe_com

        def _passthrough(fn, default=None, **kw):
            try:
                return fn()
            except Exception:
                return default

        lf_mod.safe_com = _passthrough
        try:
            sizes = _sample_style_font_sizes(doc, story)
        finally:
            lf_mod.safe_com = orig_safe_com

        self.assertIn("Heading 1", sizes)
        self.assertIn("Normal",    sizes)
        self.assertIn("Caption",   sizes)

        # AtLeast values must differ between styles
        at_least = {
            sn: _clamp_pt(
                sizes[sn] * EXACT_SPACING_MULTIPLIER,
                _MIN_LINE_SPACING_PT,
                _MAX_LINE_SPACING_PT,
                _FALLBACK_FONT_PT * EXACT_SPACING_MULTIPLIER,
            )
            for sn in sizes
        }

        self.assertNotEqual(at_least["Heading 1"], at_least["Normal"],
                            "Heading 1 and Normal must have different AtLeast values")
        self.assertNotEqual(at_least["Normal"], at_least["Caption"],
                            "Normal and Caption must have different AtLeast values")

        # Larger fonts → larger AtLeast floor
        self.assertGreater(at_least["Heading 1"], at_least["Normal"])
        self.assertGreater(at_least["Normal"],    at_least["Caption"])

    def test_single_style_produces_correct_multiplier(self):
        """The AtLeast value for Normal 12pt must be 12 * 1.05 = 12.6pt."""
        style_font_map = {"Normal": 12.0}
        doc, story = self._mock_doc(style_font_map)

        import src.services.layout_fixer as lf_mod
        orig_safe_com = lf_mod.safe_com

        def _passthrough(fn, default=None, **kw):
            try:
                return fn()
            except Exception:
                return default

        lf_mod.safe_com = _passthrough
        try:
            sizes = _sample_style_font_sizes(doc, story)
        finally:
            lf_mod.safe_com = orig_safe_com

        expected = 12.0 * EXACT_SPACING_MULTIPLIER
        actual = _clamp_pt(
            sizes["Normal"] * EXACT_SPACING_MULTIPLIER,
            _MIN_LINE_SPACING_PT, _MAX_LINE_SPACING_PT,
            _FALLBACK_FONT_PT * EXACT_SPACING_MULTIPLIER,
        )
        self.assertAlmostEqual(actual, expected, places=2)


if __name__ == "__main__":
    unittest.main()
