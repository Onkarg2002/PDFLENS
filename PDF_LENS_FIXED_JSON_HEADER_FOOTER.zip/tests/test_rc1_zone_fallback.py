"""
tests/test_rc1_zone_fallback.py
--------------------------------
Unit tests for the RC-1 fix:
  - Wrong-page fallback removal in extract_real_section_headers_footers
    (header_footer_extractor.py line ~846)
  - _resolve_pdf_page_idx helper correctness
    (document_pipeline.py)
  - _footer_is_consistent_across_pages gate
    (header_footer_extractor.py)

Run with:  python -m pytest tests/test_rc1_zone_fallback.py -v
"""
import sys
import types
import unittest


# ---------------------------------------------------------------------------
# Minimal stubs so we can import without Word / pdfplumber installed
# ---------------------------------------------------------------------------
def _make_stub(name):
    m = types.ModuleType(name)
    sys.modules.setdefault(name, m)
    return m


for _mod in (
    "pdfplumber",
    "win32com", "win32com.client",
    "win32gui", "win32con",
    "pythoncom",
    "pypdfium2",
):
    _make_stub(_mod)


# ---------------------------------------------------------------------------
# Imports under test
# ---------------------------------------------------------------------------
from src.services.pipeline.document_pipeline import _resolve_pdf_page_idx  # noqa: E402
from src.services.extractors.header_footer_extractor import (               # noqa: E402
    _footer_is_consistent_across_pages,
    _visual_confidence,
    _needs_visual_rescue,
    _merge_semantic_with_visual,
)


# ===========================================================================
# 1.  _resolve_pdf_page_idx
# ===========================================================================
class TestResolvePdfPageIdx(unittest.TestCase):

    def test_equal_page_counts_identity(self):
        """When PDF and DOCX have the same number of pages, mapping is 1:1."""
        for pn in (1, 5, 20):
            self.assertEqual(_resolve_pdf_page_idx(pn, 20, 20), pn)

    def test_pdf_shorter_than_docx(self):
        """PDF has 40 pages; DOCX has 50 — common outcome after reflow."""
        # DOCX page 1  => PDF page 1
        self.assertEqual(_resolve_pdf_page_idx(1,  40, 50), 1)
        # DOCX page 25 => PDF page round(25*40/50) = round(20.0) = 20
        self.assertEqual(_resolve_pdf_page_idx(25, 40, 50), 20)
        # DOCX page 50 => PDF page 40 (clamped to total_pdf)
        self.assertEqual(_resolve_pdf_page_idx(50, 40, 50), 40)

    def test_docx_shorter_than_pdf(self):
        """DOCX has 35 pages; PDF has 40."""
        # DOCX page 1  => PDF page 1
        self.assertEqual(_resolve_pdf_page_idx(1,  40, 35), 1)
        # DOCX page 17 => PDF page round(17*40/35) = round(19.43) = 19
        self.assertEqual(_resolve_pdf_page_idx(17, 40, 35), 19)
        # DOCX page 35 => PDF page 40
        self.assertEqual(_resolve_pdf_page_idx(35, 40, 35), 40)

    def test_clamp_never_below_1(self):
        """Result must always be >= 1."""
        self.assertGreaterEqual(_resolve_pdf_page_idx(1, 10, 1000), 1)

    def test_zero_totals_safe(self):
        """Degenerate zero inputs must not raise; result >= 1."""
        self.assertGreaterEqual(_resolve_pdf_page_idx(5, 0, 50), 1)
        self.assertGreaterEqual(_resolve_pdf_page_idx(5, 10, 0), 1)


# ===========================================================================
# 2.  None-zone safety — downstream visual pipeline
# ===========================================================================
class TestNullZoneHandling(unittest.TestCase):
    """
    With the fallback removed, sections with no matching PDF zone now receive
    pdf_zone=None.  The downstream helpers must handle this without activating
    rescue or injecting any text.
    """

    def test_visual_confidence_none_zone_returns_zero(self):
        self.assertEqual(_visual_confidence(None, is_header=True),  0.0)
        self.assertEqual(_visual_confidence(None, is_header=False), 0.0)

    def test_visual_confidence_empty_zone_returns_zero(self):
        self.assertEqual(_visual_confidence({}, is_header=True), 0.0)

    def test_needs_visual_rescue_none_zone_is_false(self):
        """Rescue must never fire when pdf_zone is None."""
        weak_info = {"text": "", "shape_text_found": False,
                     "images": {"count": 0}}
        self.assertFalse(
            _needs_visual_rescue(0.0, weak_info, None, is_header=True))
        self.assertFalse(
            _needs_visual_rescue(0.0, weak_info, None, is_header=False))

    def test_merge_semantic_with_visual_none_zone_no_rescue(self):
        """_merge_semantic_with_visual must not activate rescue for None zone."""
        info = {
            "text": "", "shape_text_found": False,
            "images": {"count": 0}, "hyperlinks": [],
            "has_page_field": False, "table_count": 0,
        }
        result = _merge_semantic_with_visual(
            info, pdf_zone=None, is_header=True)
        self.assertFalse(result.get("rescue_activated"))
        self.assertFalse(result.get("used_pdf_fallback"))
        self.assertIn(result.get("extraction_source"), ("semantic", "empty"))


# ===========================================================================
# 3.  _footer_is_consistent_across_pages
# ===========================================================================
class TestFooterConsistencyGate(unittest.TestCase):
    """
    Build a mocked pdf_zones dict with fewer entries than total DOCX pages
    and assert that page-1-only text (document title) is blocked while
    genuinely recurring footer text is allowed through.
    """

    # 5 PDF zone entries; DOCX may have 30+ pages — footer only on page 1
    PAGE_1_ONLY_ZONES = {
        1: {"footer_block": "Affordable Housing in India", "header_block": ""},
        2: {"footer_block": "",                            "header_block": ""},
        3: {"footer_block": "",                            "header_block": ""},
        4: {"footer_block": "",                            "header_block": ""},
        5: {"footer_block": "",                            "header_block": ""},
    }

    # Footer appears on 3 of 5 sample pages — genuine recurring footer
    RECURRING_FOOTER_ZONES = {
        1: {"footer_block": "Page | Ministry of Housing", "header_block": ""},
        2: {"footer_block": "Page | Ministry of Housing", "header_block": ""},
        3: {"footer_block": "",                           "header_block": ""},
        4: {"footer_block": "Page | Ministry of Housing", "header_block": ""},
        5: {"footer_block": "",                           "header_block": ""},
    }

    def test_page1_only_text_blocked(self):
        """Title text that only appears on page 1 must be blocked."""
        self.assertFalse(
            _footer_is_consistent_across_pages(
                self.PAGE_1_ONLY_ZONES,
                "Affordable Housing in India",
                min_pages=2,
            )
        )

    def test_page1_only_text_blocked_even_with_sparse_zones(self):
        """
        Even when pdf_zones has far fewer entries than DOCX pages,
        page-1-only text must still be blocked (zones dict is the truth source).
        """
        sparse = {1: {"footer_block": "Affordable Housing in India",
                      "header_block": ""}}
        self.assertFalse(
            _footer_is_consistent_across_pages(
                sparse,
                "Affordable Housing in India",
                min_pages=2,
            )
        )

    def test_recurring_footer_passes(self):
        """Recurring footer text (>= min_pages) must pass the gate."""
        self.assertTrue(
            _footer_is_consistent_across_pages(
                self.RECURRING_FOOTER_ZONES,
                "Page | Ministry of Housing",
                min_pages=2,
            )
        )

    def test_empty_footer_blocked(self):
        """An empty string must never pass the gate."""
        self.assertFalse(
            _footer_is_consistent_across_pages(
                self.RECURRING_FOOTER_ZONES, "", min_pages=2)
        )

    def test_single_occurrence_with_min_2_blocked(self):
        """Footer appearing only once must be blocked when min_pages=2."""
        zones = {1: {"footer_block": "Only Here", "header_block": ""},
                 2: {"footer_block": "",           "header_block": ""}}
        self.assertFalse(
            _footer_is_consistent_across_pages(zones, "Only Here", min_pages=2)
        )


if __name__ == "__main__":
    unittest.main()
