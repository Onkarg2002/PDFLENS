"""
worker.py — Process-pool COM worker (Windows Word automation).

Reliability features:
  • STA COM on process main thread (no COM from thread pool)
  • Persistent Word.Application with orphan-PID tracking
  • Background dialog dismisser (all Word modal HWNDs during each job)
  • COM hang watchdog with forced WINWORD recovery
  • Expanded stale-RPC detection (RPC_E_* / disconnected / server died)
  • Safe recycle, forced taskkill fallback, structured diagnostics
"""
from __future__ import annotations

import gc
import os
import subprocess
import threading
import time
import traceback
from typing import Any, Callable, Optional, Set

# ── tunables ─────────────────────────────────────────────────────────────────
_MAX_JOBS_PER_WORKER: int      = 8
_WORD_RESTART_COOLDOWN: float   = 3.0
_WORD_READY_TIMEOUT: float     = 120.0
_WORD_READY_POLL: float        = 0.5
_MAX_STALE_RETRIES: int        = 1
_DOC_CLOSE_RETRIES: int        = 8
_GC_EVERY_N_JOBS: int          = 2
_DISMISS_INTERVAL_S: float     = 0.12
_COM_HANG_TIMEOUT_S: float     = 600.0   # no heartbeat → force recovery
_WATCHDOG_POLL_S: float         = 2.0
_QUIT_TIMEOUT_S: float         = 15.0
_FORCE_KILL_WAIT_S: float       = 2.0

# HRESULTs — keep in sync with document_pipeline / winerror
_RPC_E_CALL_REJECTED: int      = -2147418111   # 0x80010001
_RPC_E_SERVER_UNAVAILABLE: int = -2147023174  # 0x800706BA
_RPC_E_DISCONNECTED: int       = -2147417848   # 0x8001000C
_RPC_E_SERVER_DIED: int        = -2147418105
_RPC_E_CALL_CANCELED: int      = -2147418110
_STALE_HRESULTS: frozenset[int] = frozenset({
    _RPC_E_CALL_REJECTED,
    _RPC_E_SERVER_UNAVAILABLE,
    _RPC_E_DISCONNECTED,
    _RPC_E_SERVER_DIED,
    _RPC_E_CALL_CANCELED,
})
_STALE_MSG_TOKENS: tuple[str, ...] = (
    "80010001", "800706ba", "8001000c", "80010005", "80010004",
    "rpc_e_", "server is unavailable", "disconnected",
    "call was rejected", "callee", "server died", "invalid class string",
)

# wdAlertsNone / msoAutomationSecurityLow
_WD_ALERTS_NONE: int = 0
_MSO_AUTOMATION_SECURITY_LOW: int = 1

from src.utils.structured_log import (
    bind_context,
    configure_logging,
    get_logger,
    log_event,
    log_timeout,
    register_worker_diagnostics_provider,
)

configure_logging()
_LOG = get_logger("pdf_lens.worker")
bind_context(component="worker")

# ── per-process state (not shared across ProcessPool workers) ────────────────
_word: Any = None
_com_initialised: bool = False
_jobs_processed: int = 0
_tracked_winword_pids: Set[int] = set()
_dismiss_stats: dict[str, int] = {"windows": 0, "clicks": 0}
_diagnostics: dict[str, Any] = {
    "pid": os.getpid(),
    "jobs_ok": 0,
    "jobs_failed": 0,
    "word_launches": 0,
    "word_restarts": 0,
    "forced_kills": 0,
    "stale_com_events": 0,
    "hang_recoveries": 0,
    "dismiss_clicks": 0,
    "cancelled_jobs": 0,
    "last_error": None,
}

# job-scoped watchdog / heartbeat (main thread only)
_heartbeat_ts: float = 0.0
_watchdog_stop: Optional[threading.Event] = None
_watchdog_thread: Optional[threading.Thread] = None
_job_active: bool = False
_cancel_flag_path: Optional[str] = None


# ═════════════════════════════════════════════════════════════════════════════
# Structured logging
# ═════════════════════════════════════════════════════════════════════════════

def _log(event: str, msg: str = "", **fields: Any) -> None:
    include_diag = event in (
        "job_done", "job_error", "job_cancelled", "job_timeout",
        "stale_com", "hang_recovery", "word_recycle", "batch_limit",
        "forced_kill", "job_start",
    )
    log_event(
        _LOG,
        event,
        msg=msg,
        component="worker",
        worker_id=os.getpid(),
        include_worker_diagnostics=include_diag,
        **fields,
    )


def get_diagnostics() -> dict:
    """Snapshot for ops / debugging (safe to serialize)."""
    out = dict(_diagnostics)
    out["jobs_in_batch"] = _jobs_processed
    out["tracked_winword_pids"] = sorted(_tracked_winword_pids)
    out["word_proxy_alive"] = _probe_word(_word) if _word else False
    out["dismiss"] = dict(_dismiss_stats)
    return out


register_worker_diagnostics_provider(get_diagnostics)


# ═════════════════════════════════════════════════════════════════════════════
# COM error classification (no pipeline import at module load)
# ═════════════════════════════════════════════════════════════════════════════

def _hresult_from_exc(exc: BaseException) -> Optional[int]:
    try:
        if hasattr(exc, "hresult") and exc.hresult is not None:
            return int(exc.hresult)
    except (TypeError, ValueError):
        pass
    try:
        if hasattr(exc, "excepinfo") and exc.excepinfo and len(exc.excepinfo) > 5:
            return int(exc.excepinfo[5])
    except (TypeError, ValueError, IndexError):
        pass
    return None


def _is_stale_com_error(exc: BaseException) -> bool:
    hr = _hresult_from_exc(exc)
    if hr is not None and hr in _STALE_HRESULTS:
        return True
    msg = str(exc).lower()
    if any(tok in msg for tok in _STALE_MSG_TOKENS):
        return True
    try:
        from src.services.pipeline.document_pipeline import (
            _is_stale_com_error as _pipeline_is_stale,
        )
        return _pipeline_is_stale(exc)
    except Exception:
        return False


def _is_com_busy(exc: BaseException) -> bool:
    if _hresult_from_exc(exc) == _RPC_E_CALL_REJECTED:
        return True
    err = str(exc).lower()
    return any(k in err for k in ("rejected", "callee", "busy", "call was"))


class WorkerCancelledError(RuntimeError):
    """Raised when parent sets cancel_flag_path (best-effort cooperative cancel)."""


# ═════════════════════════════════════════════════════════════════════════════
# WINWORD process tracking & forced cleanup
# ═════════════════════════════════════════════════════════════════════════════

def _snapshot_winword_pids() -> Set[int]:
    pids: Set[int] = set()
    try:
        import psutil
        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if (proc.info.get("name") or "").lower() == "winword.exe":
                    pids.add(int(proc.info["pid"]))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return pids
    except ImportError:
        pass

    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq WINWORD.EXE", "/FO", "CSV", "/NH"],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        for line in (out.stdout or "").splitlines():
            parts = line.strip().split(",")
            if len(parts) >= 2:
                try:
                    pids.add(int(parts[1].strip('"')))
                except ValueError:
                    continue
    except Exception as exc:
        _log("winword_enum_failed", str(exc))
    return pids


def _kill_pids(pids: Set[int], reason: str) -> int:
    killed = 0
    for pid in pids:
        if pid <= 0:
            continue
        try:
            subprocess.run(
                ["taskkill", "/PID", str(pid), "/F", "/T"],
                capture_output=True,
                timeout=15,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            killed += 1
            _log("winword_killed", reason=reason, target_pid=pid)
        except Exception as exc:
            _log("winword_kill_failed", str(exc), target_pid=pid)
    if killed:
        _diagnostics["forced_kills"] = int(_diagnostics.get("forced_kills", 0)) + killed
        time.sleep(_FORCE_KILL_WAIT_S)
    return killed


def _force_kill_tracked_winword(reason: str) -> int:
    global _tracked_winword_pids
    pids = set(_tracked_winword_pids)
    _tracked_winword_pids = set()
    if not pids:
        return 0
    return _kill_pids(pids, reason)


def _detect_orphan_winword() -> Set[int]:
    """WINWORD PIDs not in our tracked set (extra instances in this worker)."""
    all_pids = _snapshot_winword_pids()
    return all_pids - _tracked_winword_pids


def _register_new_winword_pids(before: Set[int], after: Set[int]) -> None:
    global _tracked_winword_pids
    new_pids = after - before
    if new_pids:
        _tracked_winword_pids.update(new_pids)
        _log("winword_tracked", pids=sorted(new_pids))


# ═════════════════════════════════════════════════════════════════════════════
# Dialog auto-dismiss (worker-level — covers pdf_converter + pipeline Word)
# ═════════════════════════════════════════════════════════════════════════════

_DIALOG_CLASS = "#32770"
_WORD_TITLE_MARKERS = (
    "microsoft word", "word", "document", "compatibility",
    "repair", "macro", "trust", "protected", "recovery", "normal.dot",
)
# Office 365 / 2019 / 2021 use NUIDialog instead of #32770 for some popups
_WORD_DIALOG_CLASSES = {
    "#32770",
    "nuidialog",
    "netuilwnd",
    "msocommandbar",
}


def _click_dialog_button(parent_hwnd: int, want_texts: list[str]) -> bool:
    clicked = [False]

    def _cb(hwnd: int, _: Any) -> bool:
        if clicked[0]:
            return True
        try:
            if "button" not in win32gui.GetClassName(hwnd).lower():
                return True
            label = win32gui.GetWindowText(hwnd).strip().lower().replace("&", "")
            for w in want_texts:
                if w in label:
                    win32gui.SendMessage(hwnd, win32con.BM_CLICK, 0, 0)
                    clicked[0] = True
                    return False
        except Exception:
            pass
        return True

    try:
        import win32gui
        import win32con
        win32gui.EnumChildWindows(parent_hwnd, _cb, None)
    except Exception:
        pass
    return clicked[0]


def _is_word_related_window(hwnd: int) -> bool:
    try:
        import win32gui
        if not win32gui.IsWindowVisible(hwnd):
            return False
        title = win32gui.GetWindowText(hwnd).strip().lower()
        cls   = win32gui.GetClassName(hwnd).strip().lower()
        # Match by class — catches NUIDialog on Office 365/2019/2021
        if cls in _WORD_DIALOG_CLASSES:
            return True
        if title and any(m in title for m in _WORD_TITLE_MARKERS):
            return True
        if title in ("microsoft word", "word"):
            return True
    except Exception:
        return False
    return False


def _dismiss_one_window(hwnd: int) -> bool:
    try:
        import win32gui
        import win32con
    except ImportError:
        return False

    if not _is_word_related_window(hwnd):
        return False

    _dismiss_stats["windows"] = _dismiss_stats.get("windows", 0) + 1

    # Never click Save first — avoids persisting bad state on repair/save dialogs
    for labels in (
        ["don't save", "dont save", "no"],
        ["ok"],
        ["yes"],
        ["cancel"],
        ["close"],
    ):
        if _click_dialog_button(hwnd, labels):
            _dismiss_stats["clicks"] = _dismiss_stats.get("clicks", 0) + 1
            _diagnostics["dismiss_clicks"] = int(_diagnostics.get("dismiss_clicks", 0)) + 1
            _log("dismiss_click", labels=labels[0], hwnd=hwnd)
            return True

    try:
        win32gui.PostMessage(hwnd, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)
        win32gui.PostMessage(hwnd, win32con.WM_KEYUP, win32con.VK_RETURN, 0)
        return True
    except Exception:
        return False


def _dismiss_all_word_dialogs() -> None:
    try:
        import win32gui
    except ImportError:
        return

    def _enum(hwnd: int, _: Any) -> bool:
        _dismiss_one_window(hwnd)
        return True

    try:
        win32gui.EnumWindows(_enum, None)
    except Exception:
        pass


def _auto_dismiss_loop(stop_event: threading.Event) -> None:
    while not stop_event.is_set():
        _dismiss_all_word_dialogs()
        stop_event.wait(_DISMISS_INTERVAL_S)


def _start_dismiss_thread() -> tuple[threading.Event, threading.Thread]:
    stop = threading.Event()
    t = threading.Thread(
        target=_auto_dismiss_loop,
        args=(stop,),
        name="WorkerWordDismiss",
        daemon=True,
    )
    t.start()
    return stop, t


# ═════════════════════════════════════════════════════════════════════════════
# Watchdog — detects COM hang (no heartbeat during active job)
# ═════════════════════════════════════════════════════════════════════════════

def _touch_heartbeat() -> None:
    global _heartbeat_ts
    _heartbeat_ts = time.monotonic()


def _watchdog_loop(stop_event: threading.Event) -> None:
    while not stop_event.wait(_WATCHDOG_POLL_S):
        if not _job_active:
            continue
        elapsed = time.monotonic() - _heartbeat_ts
        if _heartbeat_ts <= 0 or elapsed < _COM_HANG_TIMEOUT_S:
            continue
        log_timeout(
            _LOG,
            kind="com_hang_watchdog",
            timeout_s=_COM_HANG_TIMEOUT_S,
            elapsed_s=elapsed,
            detail=f"no COM heartbeat for {elapsed:.0f}s — forcing recovery",
            include_worker_diagnostics=True,
        )
        _diagnostics["hang_recoveries"] = int(_diagnostics.get("hang_recoveries", 0)) + 1
        try:
            _force_recover_word("watchdog_hang")
        except Exception as exc:
            _log("watchdog_recover_failed", str(exc))


def _start_watchdog() -> tuple[threading.Event, threading.Thread]:
    stop = threading.Event()
    t = threading.Thread(
        target=_watchdog_loop,
        args=(stop,),
        name="WorkerCOMWatchdog",
        daemon=True,
    )
    t.start()
    return stop, t


def _stop_helper(stop: Optional[threading.Event],
                 thread: Optional[threading.Thread],
                 label: str) -> None:
    if stop is not None:
        stop.set()
    if thread is not None:
        thread.join(timeout=3)
        if thread.is_alive():
            log_timeout(
                _LOG,
                kind="thread_join",
                timeout_s=3.0,
                label=label,
            )


# ═════════════════════════════════════════════════════════════════════════════
# COM apartment lifecycle
# ═════════════════════════════════════════════════════════════════════════════

def _suppress_pdf_reflow_popup() -> None:
    """
    Write HKCU\\...\\Word\\Options\\DontWarnPDFToWord = 1 for every Office
    version.  Must be called BEFORE Word.Application is launched.

    This is the only permanent fix for the "Word will now convert your PDF…"
    information dialog.  DisplayAlerts=0 does NOT suppress it because the
    dialog is raised by Word's PDF-reflow engine, which runs outside the
    COM alert framework.
    """
    try:
        import winreg
        hive = winreg.HKEY_CURRENT_USER
        base = r"SOFTWARE\Microsoft\Office"
        for ver in ("16.0", "15.0", "14.0"):
            path = rf"{base}\{ver}\Word\Options"
            try:
                with winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE) as k:
                    winreg.SetValueEx(k, "DontWarnPDFToWord", 0, winreg.REG_DWORD, 1)
            except Exception:
                pass
    except Exception as exc:
        _log("suppress_popup_warn", str(exc))


def _com_init() -> None:
    global _com_initialised
    if _com_initialised:
        return
    _suppress_pdf_reflow_popup()   # must run before Word.Application is created
    try:
        import pythoncom
        try:
            pythoncom.CoInitializeEx(pythoncom.COINIT_APARTMENTTHREADED)
        except Exception:
            pythoncom.CoInitialize()
        _com_initialised = True
        _log("com_init", "CoInitialize OK")
    except ImportError:
        _log("com_init_skipped", "pythoncom not available")


def _com_uninit() -> None:
    global _com_initialised
    if not _com_initialised:
        return
    try:
        import pythoncom
        try:
            pythoncom.CoFreeUnusedLibraries()
        except Exception:
            pass
        pythoncom.CoUninitialize()
        _log("com_uninit", "CoUninitialize OK")
    except Exception:
        pass
    _com_initialised = False


def _release_com_proxy(obj: Any) -> None:
    try:
        del obj
    except Exception:
        pass


def _clear_cross_job_caches() -> None:
    try:
        from src.services.extractors.header_footer_extractor import (
            clear_rescue_page_cache,
        )
        clear_rescue_page_cache()
    except Exception as exc:
        _log("cache_clear_warn", "rescue_page_cache", error=str(exc))
    try:
        from src.services.extractors.table_screenshot import close_pdf_cache
        close_pdf_cache()
    except Exception as exc:
        _log("cache_clear_warn", "pdf_cache", error=str(exc))


def _release_memory(deep: bool = False) -> None:
    gc.collect(0)
    if deep:
        gc.collect(1)
        gc.collect(2)
    try:
        import pythoncom
        pythoncom.CoFreeUnusedLibraries()
    except Exception:
        pass


def _check_cancelled() -> None:
    path = _cancel_flag_path
    if path and os.path.isfile(path):
        _diagnostics["cancelled_jobs"] = int(_diagnostics.get("cancelled_jobs", 0)) + 1
        raise WorkerCancelledError(f"Job cancelled via flag file: {path}")


# ═════════════════════════════════════════════════════════════════════════════
# Word.Application lifecycle
# ═════════════════════════════════════════════════════════════════════════════

def _apply_word_silent_mode(word: Any) -> None:
    word.Visible = False
    word.DisplayAlerts = _WD_ALERTS_NONE
    word.ScreenUpdating = False
    for attr, val in (("DisplayStatusBar", False),):
        try:
            setattr(word, attr, val)
        except Exception:
            pass
    try:
        word.AutomationSecurity = _MSO_AUTOMATION_SECURITY_LOW
    except Exception:
        pass
    for opt, val in (
        ("DoNotPromptForConvert",            True),   # suppress PDF reflow popup
        ("ConfirmConversions",               False),  # no format-conversion prompts
        ("Pagination",                       False),
        ("CheckSpellingAsYouType",           False),
        ("CheckGrammarAsYouType",            False),
        ("CheckGrammarWithSpelling",         False),
        ("ShowReadabilityStatistics",        False),
        ("AutoFormatAsYouTypeApplyHeadings", False),
        ("AutoFormatAsYouTypeApplyBullets",  False),
    ):
        try:
            setattr(word.Options, opt, val)
        except Exception:
            pass


def _probe_word(word: Any) -> bool:
    if word is None:
        return False
    try:
        _ = word.Version
        _ = word.Documents.Count
        return True
    except Exception as exc:
        if _is_stale_com_error(exc):
            return False
        if _is_com_busy(exc):
            _dismiss_all_word_dialogs()
            return True
        return False


def _close_all_open_documents(word: Any) -> int:
    closed = 0
    try:
        docs = word.Documents
    except Exception:
        return 0

    for attempt in range(_DOC_CLOSE_RETRIES):
        _dismiss_all_word_dialogs()
        try:
            n = int(docs.Count)
        except Exception:
            break
        if n <= 0:
            break
        try:
            docs(1).Close(SaveChanges=0)
            closed += 1
        except Exception:
            try:
                docs.Item(1).Close(SaveChanges=0)
                closed += 1
            except Exception:
                if attempt < _DOC_CLOSE_RETRIES - 1:
                    time.sleep(0.8)
                else:
                    break
    return closed


def _launch_word() -> Any:
    global _word
    import win32com.client

    before = _snapshot_winword_pids()
    _log("word_launch", "DispatchEx Word.Application")
    _word = win32com.client.DispatchEx("Word.Application")
    after = _snapshot_winword_pids()
    _register_new_winword_pids(before, after)
    _diagnostics["word_launches"] = int(_diagnostics.get("word_launches", 0)) + 1

    deadline = time.perf_counter() + _WORD_READY_TIMEOUT
    while True:
        _dismiss_all_word_dialogs()
        try:
            _ = _word.Version
            break
        except Exception as exc:
            if time.perf_counter() >= deadline:
                raise TimeoutError(
                    f"Word not ready within {_WORD_READY_TIMEOUT:.0f}s: {exc}"
                ) from exc
            if _is_stale_com_error(exc):
                raise
            time.sleep(_WORD_READY_POLL)

    _apply_word_silent_mode(_word)
    _log("word_ready", version=str(_word.Version))
    _touch_heartbeat()
    return _word


def _quit_word(force: bool = False) -> None:
    global _word
    if _word is not None:
        try:
            n = _close_all_open_documents(_word)
            if n:
                _log("docs_closed", count=n)
        except Exception as exc:
            _log("docs_close_error", str(exc))

        quit_ok = False
        if not force:
            try:
                _dismiss_all_word_dialogs()
                _word.Quit(SaveChanges=0)
                quit_ok = True
                _log("word_quit", "OK")
            except Exception as exc:
                _log("word_quit_failed", str(exc))

        if not quit_ok:
            force = True

        _release_com_proxy(_word)
        _word = None

    if force:
        _force_kill_tracked_winword("quit_failed_or_forced")

    orphans = _detect_orphan_winword()
    if orphans:
        _log("orphan_winword", pids=sorted(orphans))
        _kill_pids(orphans, "orphan_cleanup")

    _clear_cross_job_caches()
    _release_memory(deep=True)


def _force_recover_word(reason: str) -> None:
    """Hard recovery: kill tracked WINWORD, reset COM, relaunch."""
    global _jobs_processed
    _log("force_recover", reason=reason)
    _quit_word(force=True)
    time.sleep(_WORD_RESTART_COOLDOWN)
    _com_uninit()
    _com_init()
    _launch_word()
    _diagnostics["word_restarts"] = int(_diagnostics.get("word_restarts", 0)) + 1


def _ensure_word() -> Any:
    global _word
    _com_init()

    if _word is not None and not _probe_word(_word):
        _log("word_stale_proxy", "recycling")
        _diagnostics["stale_com_events"] = int(_diagnostics.get("stale_com_events", 0)) + 1
        _force_recover_word("stale_proxy")

    if _word is None:
        _launch_word()
    return _word


def _recycle_word() -> None:
    global _jobs_processed
    _log("word_recycle", jobs_in_batch=_jobs_processed)
    _force_recover_word("scheduled_recycle")
    _jobs_processed = 0


# ═════════════════════════════════════════════════════════════════════════════
# Pipeline adapter
# ═════════════════════════════════════════════════════════════════════════════

class _WordInstanceAdapter:
    """
    Bridges run_docx_pipeline() to the persistent worker Word instance.
    All COM runs on the process main thread; heartbeat updated per call.
    """

    def start(self) -> None:
        pass

    def stop(self) -> None:
        pass

    def run(self, fn: Callable, label: str = "COM call", timeout: float = 1800.0):
        from src.services.pipeline.document_pipeline import StaleWordInstanceError

        _check_cancelled()
        _dismiss_all_word_dialogs()

        if _word is None or not _probe_word(_word):
            _diagnostics["stale_com_events"] = int(_diagnostics.get("stale_com_events", 0)) + 1
            raise StaleWordInstanceError(
                f"Word COM proxy failed pre-flight before '{label}'"
            )

        t0 = time.perf_counter()
        _touch_heartbeat()
        try:
            result = fn(_word)
            return result
        except WorkerCancelledError:
            raise
        except Exception as exc:
            _dismiss_all_word_dialogs()
            if _is_stale_com_error(exc):
                _diagnostics["stale_com_events"] = int(_diagnostics.get("stale_com_events", 0)) + 1
                raise StaleWordInstanceError(
                    f"Stale Word COM during '{label}': {exc}"
                ) from exc
            raise
        finally:
            _touch_heartbeat()
            elapsed = time.perf_counter() - t0
            if elapsed >= timeout:
                log_timeout(
                    _LOG,
                    kind="com_call",
                    timeout_s=timeout,
                    elapsed_s=elapsed,
                    label=label,
                    include_worker_diagnostics=True,
                )
            elif elapsed >= timeout * 0.75:
                _log(
                    "com_call_slow",
                    label=label,
                    elapsed_s=round(elapsed, 1),
                    limit_s=timeout,
                )


_adapter = _WordInstanceAdapter()


# ═════════════════════════════════════════════════════════════════════════════
# ProcessPool entry point
# ═════════════════════════════════════════════════════════════════════════════

def worker_task(payload: dict) -> dict:
    """
    Process one document in an isolated worker process.

    Parent timeout (convert_controller) does not kill this process; optional
    payload['cancel_flag_path'] enables cooperative cancellation when the
    parent creates that file on timeout.
    """
    global _jobs_processed, _job_active, _cancel_flag_path
    global _watchdog_stop, _watchdog_thread

    from src.services.document_service import process_document
    from src.services.pipeline.document_pipeline import StaleWordInstanceError

    job_id = payload.get("job_id", "unknown")
    request_id = payload.get("request_id")
    bind_context(job_id=job_id, component="worker")
    if request_id:
        bind_context(request_id=request_id)
    _cancel_flag_path = payload.get("cancel_flag_path")
    _job_active = True
    _touch_heartbeat()

    dismiss_stop, dismiss_thread = _start_dismiss_thread()
    _watchdog_stop, _watchdog_thread = _start_watchdog()

    _log(
        "job_start",
        job_id=job_id,
        file=payload.get("filename"),
        batch_job=_jobs_processed + 1,
        batch_max=_MAX_JOBS_PER_WORKER,
    )

    try:
        _ensure_word()
    except Exception as exc:
        _diagnostics["jobs_failed"] = int(_diagnostics.get("jobs_failed", 0)) + 1
        _diagnostics["last_error"] = str(exc)
        _log("job_error", "Word launch failed", job_id=job_id, error=str(exc))
        return {
            "job_id": job_id,
            "status": "error",
            "result": None,
            "error": str(exc),
            "diagnostics": get_diagnostics(),
        }

    t0 = time.perf_counter()
    result = None

    try:
        for attempt in range(_MAX_STALE_RETRIES + 1):
            _check_cancelled()
            try:
                result = process_document(
                    file_path=payload["file_path"],
                    filename=payload["filename"],
                    output_folder=payload["output_folder"],
                    extract_tables=payload["extract_tables"],
                    extract_images=payload["extract_images"],
                    extract_header=payload["extract_header"],
                    extract_footer=payload["extract_footer"],
                    extract_hyperlinks=payload["extract_hyperlinks"],
                    extract_footnote=payload["extract_footnote"],
                    _word_instance=_adapter,
                )
                break

            except WorkerCancelledError as exc:
                _diagnostics["jobs_failed"] = int(_diagnostics.get("jobs_failed", 0)) + 1
                _diagnostics["last_error"] = str(exc)
                _log("job_cancelled", job_id=job_id, error=str(exc))
                try:
                    _recycle_word()
                except Exception as exc_r:
                    _log("recycle_after_cancel_failed", str(exc_r))
                return {
                    "job_id": job_id,
                    "status": "error",
                    "result": None,
                    "error": str(exc),
                    "diagnostics": get_diagnostics(),
                }

            except StaleWordInstanceError as exc:
                elapsed = time.perf_counter() - t0
                _log(
                    "stale_com",
                    job_id=job_id,
                    attempt=attempt + 1,
                    elapsed_s=round(elapsed, 1),
                    error=str(exc),
                )
                if attempt >= _MAX_STALE_RETRIES:
                    try:
                        _recycle_word()
                    except Exception as exc_r:
                        _log("recycle_after_stale_failed", str(exc_r))
                    _diagnostics["jobs_failed"] = int(_diagnostics.get("jobs_failed", 0)) + 1
                    _diagnostics["last_error"] = str(exc)
                    return {
                        "job_id": job_id,
                        "status": "error",
                        "result": None,
                        "error": str(exc),
                        "diagnostics": get_diagnostics(),
                    }
                try:
                    _recycle_word()
                except Exception as exc_r:
                    _diagnostics["jobs_failed"] = int(_diagnostics.get("jobs_failed", 0)) + 1
                    _diagnostics["last_error"] = f"Word recycle failed: {exc_r}"
                    return {
                        "job_id": job_id,
                        "status": "error",
                        "result": None,
                        "error": _diagnostics["last_error"],
                        "diagnostics": get_diagnostics(),
                    }
                _log("job_retry", job_id=job_id, attempt=attempt + 2)

            except Exception as exc:
                elapsed = time.perf_counter() - t0
                _diagnostics["jobs_failed"] = int(_diagnostics.get("jobs_failed", 0)) + 1
                _diagnostics["last_error"] = str(exc)
                _log(
                    "job_error",
                    job_id=job_id,
                    elapsed_s=round(elapsed, 1),
                    error=str(exc),
                    traceback=traceback.format_exc(),
                )
                _jobs_processed += 1
                try:
                    _recycle_word()
                except Exception as exc_r:
                    _log("recycle_after_error_failed", str(exc_r))
                return {
                    "job_id": job_id,
                    "status": "error",
                    "result": None,
                    "error": str(exc),
                    "diagnostics": get_diagnostics(),
                }

        elapsed = time.perf_counter() - t0
        _jobs_processed += 1
        _diagnostics["jobs_ok"] = int(_diagnostics.get("jobs_ok", 0)) + 1

        if _jobs_processed % _GC_EVERY_N_JOBS == 0:
            _release_memory(deep=False)

        if _jobs_processed >= _MAX_JOBS_PER_WORKER:
            _log("batch_limit", limit=_MAX_JOBS_PER_WORKER)
            try:
                _recycle_word()
            except Exception as exc_r:
                _log("batch_recycle_failed", str(exc_r))

        _log(
            "job_done",
            job_id=job_id,
            elapsed_s=round(elapsed, 1),
            duration_ms=round(elapsed * 1000.0, 2),
            total_pages=(result or {}).get("total_pages") if isinstance(result, dict) else None,
        )
        return {
            "job_id": job_id,
            "status": "success",
            "result": result,
            "error": None,
            "diagnostics": get_diagnostics(),
        }

    finally:
        _job_active = False
        _cancel_flag_path = None
        _touch_heartbeat()
        _stop_helper(dismiss_stop, dismiss_thread, "dismiss")
        _stop_helper(_watchdog_stop, _watchdog_thread, "watchdog")
        _dismiss_all_word_dialogs()
        _release_memory(deep=False)


# Optional: recycle Word when worker process is about to exit (Py 3.11+ pool)
def _worker_shutdown_hook() -> None:
    try:
        _quit_word(force=True)
    except Exception:
        pass
    _com_uninit()
