WD_HEADER_FOOTER_PRIMARY    = 1
WD_HEADER_FOOTER_FIRST_PAGE = 2
WD_HEADER_FOOTER_EVEN_PAGES = 3
WD_GO_TO_PAGE               = 1
WD_GO_TO_ABSOLUTE           = 1
WD_VERT_POS_REL_PAGE        = 10
WD_IS_IN_TABLE              = 12

RPC_E_CALL_REJECTED   = -2147418111
WD_PERMISSION_ERROR   = -2146823167
WD_CORRUPTED_ERROR    = -2147352567 

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc"}
ALLOWED_MIME_TYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword",
}

FOLDER_TABLE_SCREENSHOTS  = "table_screenshots"
FOLDER_EXTRACTED_IMAGES   = "extracted_images"

SUFFIX_FULL_ANALYSIS  = "_meta.json"
SUFFIX_HEADER_FOOTER  = "_header_footer.json"
SUFFIX_PDF_ZONES      = "_pdf_zones.json"
SUFFIX_LAYOUT_META    = "_layout_metadata.json"
SUFFIX_FOOTNOTES = "_footnote.json"
