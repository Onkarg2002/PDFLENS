import os
import re
from typing import Optional
import pdfplumber
import pypdfium2 as pdfium
from PIL import Image
from src.constants.constant import (MATH_UNICODE_RANGES, MATH_FONT_FRAGMENTS,WD_VERT_POS_REL_PAGE,)
from src.utils.file_util import safe_com
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.core.core")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)

def count_math_chars(text: str) -> int:
    count = 0
    for ch in text:
        cp = ord(ch)
        for lo, hi in MATH_UNICODE_RANGES:
            if lo <= cp <= hi:
                count += 1
                break
    return count

def is_math_font(fontname: str) -> bool:
    if not fontname:
        return False
    fn = fontname.lower()
    return any(frag in fn for frag in MATH_FONT_FRAGMENTS)

# pypdfium2 render helpers 
def pdf_page_to_pil(pdf_path: str, page_num: int,
                    dpi: int = 150) -> Optional[Image.Image]:
    """Render an entire PDF page to a PIL Image."""
    try:
        doc   = pdfium.PdfDocument(pdf_path)
        page  = doc[page_num - 1]
        scale = dpi / 72.0
        bm    = page.render(scale=scale, rotation=0)
        img   = bm.to_pil()
        page.close(); doc.close()
        return img
    except Exception as e:
        _slog(f"    [pdf_render] page {page_num}: {e}")
        return None

def pdf_region_to_pil(pdf_path: str, page_num: int,
                       x0_pt: float, y0_pt: float,
                       x1_pt: float, y1_pt: float,
                       dpi: int = 200) -> Optional[Image.Image]:
    """
    Render a rectangular region (PDF points, top-left origin) to PIL Image.
    """
    try:
        doc   = pdfium.PdfDocument(pdf_path)
        page  = doc[page_num - 1]
        scale = dpi / 72.0
        bm    = page.render(scale=scale, rotation=0,
                             fill_color=(255, 255, 255, 255))
        full  = bm.to_pil()

        px0 = int(x0_pt * scale);  py0 = int(y0_pt * scale)
        px1 = int(x1_pt * scale);  py1 = int(y1_pt * scale)

        W, H = full.size
        px0, py0 = max(0, px0), max(0, py0)
        px1, py1 = min(W, px1), min(H, py1)

        if px1 <= px0 or py1 <= py0:
            page.close(); doc.close()
            return None

        cropped = full.crop((px0, py0, px1, py1))
        page.close(); doc.close()
        return cropped
    except Exception as e:
        _slog(f"    [pdf_region] page {page_num}: {e}")
        return None

def extract_pdf_header_footer_zones(pdf_path: str,
                                     header_ratio: float = 0.15,
                                     footer_ratio: float = 0.15) -> dict:
    """
    Returns per-page dict with header/footer text, sizes and coordinates.
    """
    zones = {}
    with pdfplumber.open(pdf_path) as pdf:
        for page_idx, page in enumerate(pdf.pages):
            pn = page_idx + 1
            pw = float(page.width)
            ph = float(page.height)
            hdr_thresh = ph * header_ratio
            ftr_thresh = ph * (1.0 - footer_ratio)

            def chars_to_lines(chars_list):
                buckets = {}
                for c in chars_list:
                    key = round(float(c["top"]), 0)
                    buckets.setdefault(key, []).append(c)
                lines = []
                for key in sorted(buckets):
                    cs   = buckets[key]
                    text = "".join(
                        c["text"] for c in sorted(cs, key=lambda x: x["x0"])
                    ).strip()
                    if not text:
                        continue
                    sizes = [float(c["size"]) for c in cs if c.get("size")]
                    lines.append({
                        "text":      text,
                        "font_size": round(sum(sizes)/len(sizes), 2) if sizes else 0,
                        "top_pt":    round(float(cs[0]["top"]),    3),
                        "bottom_pt": round(float(cs[0]["bottom"]), 3),
                    })
                return lines

            all_chars = page.chars
            hdr_lines = chars_to_lines(
                [c for c in all_chars if float(c["top"]) <= hdr_thresh])
            ftr_lines = chars_to_lines(
                [c for c in all_chars if float(c["top"]) >= ftr_thresh])

            def bbox(lines):
                if not lines: return 0.0, 0.0
                return (min(l["top_pt"] for l in lines),
                        max(l["bottom_pt"] for l in lines))

            hdr_top, hdr_bot = bbox(hdr_lines)
            ftr_top, ftr_bot = bbox(ftr_lines)

            zones[pn] = {
                "header_lines": hdr_lines,
                "footer_lines": ftr_lines,
                "header_block": "\n".join(l["text"] for l in hdr_lines),
                "footer_block": "\n".join(l["text"] for l in ftr_lines),
                "header_top_pt":    hdr_top,
                "header_bottom_pt": hdr_bot,
                "header_height_pt": round(hdr_bot - hdr_top, 3) if hdr_lines else 0.0,
                "footer_top_pt":    ftr_top,
                "footer_bottom_pt": ftr_bot,
                "footer_height_pt": round(ftr_bot - ftr_top, 3) if ftr_lines else 0.0,
                "footer_dist_from_bottom_pt": round(ph - ftr_bot, 3) if ftr_lines else 0.0,
                "page_width_pt":  pw,
                "page_height_pt": ph,
            }
    return zones

def word_table_bbox_in_pdf(table_obj, section_page_setup,
                            pdf_zone: dict) -> Optional[tuple]:
    """
    Estimate bounding box of a Word table in PDF coords (pt, top-left origin).
    Returns (page_num, x0, y0, x1, y1) or None.
    """
    try:
        t_rng    = table_obj.Range
        page_num = safe_com(lambda: int(t_rng.Information(3)), default=1)
        top_pt   = safe_com(lambda: float(t_rng.Information(10)), default=None)
        left_pt  = safe_com(lambda: float(t_rng.Information(6)),  default=None)

        if top_pt is None or left_pt is None:
            return None

        rows   = safe_com(lambda: table_obj.Rows.Count,    default=4)
        cols   = safe_com(lambda: table_obj.Columns.Count, default=2)
        page_w = pdf_zone.get("page_width_pt",  595.0)
        page_h = pdf_zone.get("page_height_pt", 842.0)

        left_margin  = safe_com(lambda: float(section_page_setup.LeftMargin),  default=72.0)
        right_margin = safe_com(lambda: float(section_page_setup.RightMargin), default=72.0)
        text_width   = page_w - left_margin - right_margin
        est_col_w    = text_width / max(cols, 1)
        est_width    = min(text_width, est_col_w * cols)
        est_height   = rows * 14.0 + 10.0

        x0 = max(0.0, left_pt - 4)
        y0 = max(0.0, top_pt  - 4)
        x1 = min(page_w, x0 + est_width  + 8)
        y1 = min(page_h, y0 + est_height + 8)

        return page_num, x0, y0, x1, y1
    except Exception as e:
        _slog(f"    [table bbox] {e}")
        return None