from __future__ import annotations

import bisect
import os
import re
from collections import defaultdict
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from typing import Any, Optional

import pdfplumber


_WORD_ACTIVE_END_PAGE_NUMBER = 3
_MIN_TEXT_LEN = 12
_LCS_WINDOW = 3000
_LCS_OVERLAP = 600
_PDF_SEARCH_PAD = 9000


def _norm_text(text: str) -> str:
    text = text or ""
    text = text.replace("\u00ad", "")
    text = re.sub(r"[\r\n\t]+", " ", text)
    text = re.sub(r"[^\w\s]+", " ", text, flags=re.UNICODE)
    text = re.sub(r"\s+", " ", text)
    return text.lower().strip()


def _lcs_matching_blocks(a: str, b: str) -> list[tuple[int, int, int]]:
    """
    Return LCS-like matching blocks.

    SequenceMatcher is used as a practical sliding-window LCS engine: it gives
    ordered non-overlapping matching blocks and scales better than a full
    dynamic-programming LCS matrix for long documents.
    """
    if not a or not b:
        return []
    matcher = SequenceMatcher(None, a, b, autojunk=False)
    return [
        (m.a, m.b, m.size)
        for m in matcher.get_matching_blocks()
        if m.size > 0
    ]


@dataclass
class PDFBlock:
    page: int
    text: str
    x0: float = 0.0
    top: float = 0.0
    x1: float = 0.0
    bottom: float = 0.0
    norm: str = ""
    start: int = 0
    end: int = 0


@dataclass
class WordRun:
    word_page: int
    text: str
    paragraph_index: int = 0
    run_index: int = 0
    norm: str = ""
    start: int = 0
    end: int = 0
    matched_chars_by_pdf_page: dict[int, int] = field(default_factory=dict)
    fallback_pdf_page: int = 0
    fallback_score: float = 0.0


class PageMapper:
    """
    Map Word page numbers back to original PDF page numbers using text alignment.

    The mapper extracts PDF text blocks with coordinates, extracts Word text
    runs/paragraphs with Word page numbers, aligns normalized full-document text,
    and aggregates character overlap per Word page.
    """

    def __init__(self, pdf_path: str, docx_path: str):
        self.pdf_path = os.path.abspath(pdf_path)
        self.docx_path = os.path.abspath(docx_path)

        self.pdf_blocks: list[PDFBlock] = []
        self.word_runs: list[WordRun] = []
        self.pdf_text = ""
        self.word_text = ""
        self._pdf_page_starts: list[tuple[int, int]] = []
        self._word_run_starts: list[int] = []
        self._mapping: dict[int, dict] = {}
        self._built = False

        self._extract_pdf_blocks()
        self._extract_word_runs()

    # ------------------------------------------------------------------
    # Extraction
    # ------------------------------------------------------------------

    def _append_pdf_block(self, block: PDFBlock) -> None:
        block.norm = _norm_text(block.text)
        if len(block.norm) < _MIN_TEXT_LEN:
            return
        if self.pdf_text:
            self.pdf_text += " "
        block.start = len(self.pdf_text)
        self.pdf_text += block.norm
        block.end = len(self.pdf_text)
        self.pdf_blocks.append(block)

    def _extract_pdf_blocks(self) -> None:
        with pdfplumber.open(self.pdf_path) as pdf:
            for page_idx, page in enumerate(pdf.pages, 1):
                try:
                    words = page.extract_words(
                        x_tolerance=2,
                        y_tolerance=3,
                        keep_blank_chars=False,
                        use_text_flow=True,
                    )
                except Exception:
                    words = []

                if words:
                    lines: dict[float, list[dict]] = defaultdict(list)
                    for word in words:
                        key = round(float(word.get("top", 0.0)), 1)
                        lines[key].append(word)
                    for key in sorted(lines):
                        line_words = sorted(lines[key], key=lambda w: float(w.get("x0", 0.0)))
                        text = " ".join(w.get("text", "") for w in line_words).strip()
                        if not text:
                            continue
                        self._append_pdf_block(PDFBlock(
                            page=page_idx,
                            text=text,
                            x0=min(float(w.get("x0", 0.0)) for w in line_words),
                            top=min(float(w.get("top", 0.0)) for w in line_words),
                            x1=max(float(w.get("x1", 0.0)) for w in line_words),
                            bottom=max(float(w.get("bottom", 0.0)) for w in line_words),
                        ))
                else:
                    text = page.extract_text() or ""
                    for line in text.splitlines():
                        self._append_pdf_block(PDFBlock(page=page_idx, text=line))

                try:
                    page.close()
                except Exception:
                    pass

        self._pdf_page_starts = []
        seen: set[int] = set()
        for block in self.pdf_blocks:
            if block.page not in seen:
                self._pdf_page_starts.append((block.start, block.page))
                seen.add(block.page)

    def _extract_word_runs(self) -> None:
        try:
            self._extract_word_runs_com()
        except Exception:
            self._extract_word_runs_docx_fallback()

        self._word_run_starts = [run.start for run in self.word_runs]

    def _append_word_run(self, run: WordRun) -> None:
        run.norm = _norm_text(run.text)
        if len(run.norm) < _MIN_TEXT_LEN:
            return
        if self.word_text:
            self.word_text += " "
        run.start = len(self.word_text)
        self.word_text += run.norm
        run.end = len(self.word_text)
        self.word_runs.append(run)

    def _extract_word_runs_com(self) -> None:
        import pythoncom
        import win32com.client

        pythoncom.CoInitialize()
        word = None
        doc = None
        try:
            word = win32com.client.DispatchEx("Word.Application")
            word.Visible = False
            word.DisplayAlerts = 0
            doc = word.Documents.Open(
                self.docx_path,
                ReadOnly=True,
                AddToRecentFiles=False,
                ConfirmConversions=False,
                Visible=False,
            )
            paragraphs = doc.Paragraphs
            para_count = int(paragraphs.Count)
            for para_idx in range(1, para_count + 1):
                para = paragraphs(para_idx)
                para_range = para.Range
                word_page = int(para_range.Information(_WORD_ACTIVE_END_PAGE_NUMBER) or 1)
                runs = para_range.Words
                run_count = int(runs.Count or 0)
                if run_count:
                    buf: list[str] = []
                    for run_idx in range(1, run_count + 1):
                        txt = str(runs(run_idx).Text or "")
                        if txt.strip():
                            buf.append(txt)
                    text = " ".join(buf)
                else:
                    text = str(para_range.Text or "")
                self._append_word_run(WordRun(
                    word_page=word_page,
                    text=text,
                    paragraph_index=para_idx,
                    run_index=0,
                ))
        finally:
            if doc is not None:
                try:
                    doc.Close(False)
                except Exception:
                    pass
            if word is not None:
                try:
                    word.Quit()
                except Exception:
                    pass
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass

    def _extract_word_runs_docx_fallback(self) -> None:
        """
        Fallback for non-Windows/headless environments.

        python-docx has no rendered page model, so this estimates Word pages by
        proportional character position. Confidence will reflect alignment
        quality, but page-number confidence is naturally weaker than COM.
        """
        from docx import Document

        document = Document(self.docx_path)
        paragraphs = [p.text for p in document.paragraphs if p.text and p.text.strip()]
        total_norm_len = sum(len(_norm_text(p)) + 1 for p in paragraphs) or 1
        estimated_pdf_pages = max([b.page for b in self.pdf_blocks] or [1])

        cursor = 0
        for para_idx, text in enumerate(paragraphs, 1):
            n = len(_norm_text(text)) + 1
            word_page = max(
                1,
                min(
                    estimated_pdf_pages,
                    round((cursor / total_norm_len) * estimated_pdf_pages) + 1,
                ),
            )
            cursor += n
            self._append_word_run(WordRun(
                word_page=word_page,
                text=text,
                paragraph_index=para_idx,
                run_index=0,
            ))

    # ------------------------------------------------------------------
    # Alignment
    # ------------------------------------------------------------------

    def build_mapping(self) -> dict[int, Any]:
        if self._built:
            return {wp: data["pdf_pages"] for wp, data in self._mapping.items()}

        self._align_with_sliding_lcs()
        self._fallback_unmatched_runs()
        self._aggregate_word_pages()
        self._built = True
        return {wp: data["pdf_pages"] for wp, data in self._mapping.items()}

    def _align_with_sliding_lcs(self) -> None:
        if not self.pdf_text or not self.word_text:
            return

        word_len = len(self.word_text)
        pdf_len = len(self.pdf_text)
        step = max(1, _LCS_WINDOW - _LCS_OVERLAP)

        for word_start in range(0, word_len, step):
            word_end = min(word_len, word_start + _LCS_WINDOW)
            word_window = self.word_text[word_start:word_end]
            if len(word_window) < _MIN_TEXT_LEN:
                continue

            ratio_start = word_start / max(word_len, 1)
            ratio_end = word_end / max(word_len, 1)
            pdf_start = max(0, int(ratio_start * pdf_len) - _PDF_SEARCH_PAD)
            pdf_end = min(pdf_len, int(ratio_end * pdf_len) + _PDF_SEARCH_PAD)
            pdf_window = self.pdf_text[pdf_start:pdf_end]

            for wa, pb, size in _lcs_matching_blocks(word_window, pdf_window):
                if size < _MIN_TEXT_LEN:
                    continue
                abs_word_start = word_start + wa
                abs_word_end = abs_word_start + size
                abs_pdf_start = pdf_start + pb
                abs_pdf_end = abs_pdf_start + size
                self._assign_match(abs_word_start, abs_word_end, abs_pdf_start, abs_pdf_end)

    def _assign_match(
        self,
        word_start: int,
        word_end: int,
        pdf_start: int,
        pdf_end: int,
    ) -> None:
        first_idx = max(0, bisect.bisect_right(self._word_run_starts, word_start) - 1)
        idx = first_idx
        while idx < len(self.word_runs):
            run = self.word_runs[idx]
            if run.start >= word_end:
                break
            overlap_start = max(run.start, word_start)
            overlap_end = min(run.end, word_end)
            if overlap_end <= overlap_start:
                idx += 1
                continue

            rel = overlap_start - word_start
            pdf_pos = pdf_start + rel
            overlap_len = overlap_end - overlap_start
            page = self._pdf_page_at_pos(pdf_pos)
            run.matched_chars_by_pdf_page[page] = (
                run.matched_chars_by_pdf_page.get(page, 0) + overlap_len
            )
            idx += 1

    def _pdf_page_at_pos(self, pos: int) -> int:
        if not self._pdf_page_starts:
            return 1
        starts = [s for s, _ in self._pdf_page_starts]
        idx = max(0, bisect.bisect_right(starts, pos) - 1)
        return self._pdf_page_starts[idx][1]

    def _fallback_unmatched_runs(self) -> None:
        pdf_candidates = [
            (block.norm, block.page)
            for block in self.pdf_blocks
            if len(block.norm) >= _MIN_TEXT_LEN
        ]
        if not pdf_candidates:
            return

        candidate_texts = [c[0] for c in pdf_candidates]
        for run in self.word_runs:
            if run.matched_chars_by_pdf_page:
                continue
            if len(run.norm) < _MIN_TEXT_LEN:
                continue

            best_page = 0
            best_score = 0.0
            for match in difflib_close_matches(run.norm, candidate_texts, n=3):
                idx = candidate_texts.index(match)
                score = SequenceMatcher(None, run.norm, match, autojunk=False).ratio()
                if score > best_score:
                    best_score = score
                    best_page = pdf_candidates[idx][1]

            if best_page and best_score >= 0.55:
                run.fallback_pdf_page = best_page
                run.fallback_score = best_score
                run.matched_chars_by_pdf_page[best_page] = max(1, int(len(run.norm) * best_score))

    def _aggregate_word_pages(self) -> None:
        by_word_page: dict[int, dict[int, int]] = defaultdict(lambda: defaultdict(int))
        totals: dict[int, int] = defaultdict(int)

        for run in self.word_runs:
            totals[run.word_page] += max(1, len(run.norm))
            for pdf_page, chars in run.matched_chars_by_pdf_page.items():
                by_word_page[run.word_page][pdf_page] += int(chars)

        self._mapping = {}
        for word_page, total_chars in sorted(totals.items()):
            page_counts = dict(by_word_page.get(word_page, {}))
            matched = sum(page_counts.values())
            if not page_counts:
                fallback = self._proportional_page_fallback(word_page)
                page_counts = {fallback: 0}
                matched = 0

            ordered = sorted(page_counts.items(), key=lambda kv: (-kv[1], kv[0]))
            dominant_page, dominant_chars = ordered[0]
            overlap_pages = [
                page for page, chars in sorted(page_counts.items())
                if chars > 0 and chars / max(matched, 1) >= 0.10
            ]
            if not overlap_pages:
                overlap_pages = [dominant_page]

            pdf_pages: int | list[int]
            if len(overlap_pages) == 1 or dominant_chars / max(matched, 1) >= 0.75:
                pdf_pages = dominant_page
            else:
                pdf_pages = overlap_pages

            confidence = 0.0
            if total_chars > 0:
                coverage = min(1.0, matched / total_chars)
                dominance = dominant_chars / max(matched, 1)
                confidence = round(max(0.0, min(1.0, coverage * (0.5 + 0.5 * dominance))), 4)

            self._mapping[word_page] = {
                "pdf_pages": pdf_pages,
                "page_counts": page_counts,
                "matched_chars": matched,
                "total_chars": total_chars,
                "confidence": confidence,
            }

    def _proportional_page_fallback(self, word_page: int) -> int:
        max_word_page = max([r.word_page for r in self.word_runs] or [1])
        max_pdf_page = max([b.page for b in self.pdf_blocks] or [1])
        return max(1, min(max_pdf_page, round(word_page * max_pdf_page / max_word_page)))

    # ------------------------------------------------------------------
    # Public lookup API
    # ------------------------------------------------------------------

    def map_word_page(self, word_page_num: int) -> int | list[int]:
        if not self._built:
            self.build_mapping()
        word_page = int(word_page_num or 1)
        if word_page in self._mapping:
            return self._mapping[word_page]["pdf_pages"]
        return self._proportional_page_fallback(word_page)

    def get_confidence(self, word_page_num: int) -> float:
        if not self._built:
            self.build_mapping()
        word_page = int(word_page_num or 1)
        if word_page in self._mapping:
            return float(self._mapping[word_page].get("confidence", 0.0))
        return 0.0

    def get_debug_info(self, word_page_num: Optional[int] = None) -> dict:
        if not self._built:
            self.build_mapping()
        if word_page_num is not None:
            return dict(self._mapping.get(int(word_page_num), {}))
        return {
            "pdf_blocks": len(self.pdf_blocks),
            "word_runs": len(self.word_runs),
            "pdf_text_chars": len(self.pdf_text),
            "word_text_chars": len(self.word_text),
            "mapping": self._mapping,
        }


def difflib_close_matches(word: str, possibilities: list[str], n: int = 3) -> list[str]:
    """
    Small wrapper so fallback matching remains easy to replace/tune.
    """
    from difflib import get_close_matches

    return get_close_matches(word, possibilities, n=n, cutoff=0.45)
