from __future__ import annotations

import time
from typing import Any, Callable, Optional
from src.constants.constant import WD_GO_TO_PAGE, WD_GO_TO_ABSOLUTE
from src.utils.file_util import safe_com, _is_com_busy
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.pipeline.page_boundary")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)

_WD_ACTIVE_END_PAGE_NUMBER = 3

_LOG_FN: Optional[Callable[[str], None]] = None


def set_page_boundary_logger(log_fn: Callable[[str], None]) -> None:
    """Install pipeline logger (e.g. document_pipeline._log)."""
    global _LOG_FN
    _LOG_FN = log_fn


def _log(msg: str) -> None:
    if _LOG_FN is not None:
        try:
            _LOG_FN(msg)
            return
        except Exception:
            pass
    _slog(msg, event="page_boundary")


def is_com_range_error(exc: BaseException) -> bool:
    """True when exc is typical Word Range / pagination bounds failure."""
    msg = str(exc).lower()
    tokens = (
        "value out of range",
        "out of range",
        "invalid argument",
        "parameter is incorrect",
        "800a1066",
    )
    return any(t in msg for t in tokens)


def get_doc_content_end(doc) -> int:
    """Current document story end (1-based last character index)."""
    end = safe_com(lambda: int(doc.Content.End), default=0)
    return max(1, int(end or 1))


def invalidate_page_boundary_cache(
    cache: dict[int, int],
    from_page: int = 1,
    reason: str = "",
) -> int:
    """
    Drop cached page-start positions from *from_page* upward (or entire cache).
    Returns number of entries removed.
    """
    if from_page <= 1:
        n = len(cache)
        cache.clear()
        if n and reason:
            _log(f"  [page_boundaries] invalidated ALL ({n} entries): {reason}")
        return n
    removed = 0
    for key in list(cache.keys()):
        if key >= from_page:
            del cache[key]
            removed += 1
    if removed and reason:
        _log(f"  [page_boundaries] invalidated from p{from_page} "
             f"({removed} entries): {reason}")
    return removed


def _cache_monotonic_ok(
    cache: dict[int, int],
    page_from: int,
    page_to: int,
    content_end: int,
) -> tuple[bool, str]:
    """Verify cached starts are ordered and within [0, content_end]."""
    keys = sorted(k for k in cache if page_from <= k <= page_to + 1)
    if not keys:
        return True, ""
    prev = -1
    for k in keys:
        start = cache[k]
        if start < 0 or start > content_end:
            return False, f"p{k} start={start} outside [0,{content_end}]"
        if start < prev:
            return False, f"p{k} start={start} < previous={prev} (non-monotonic)"
        prev = start
    return True, ""


def clamp_range_bounds(start: int, end: int, content_end: int) -> tuple[int, int]:
    """
    Clamp start/end into valid Word Range indices.
    Word requires 0 <= start < end <= Content.End (last char index).
    """
    content_end = max(1, int(content_end))
    start = int(start)
    end = int(end)
    start = max(0, min(start, content_end - 1))
    end = max(start + 1, min(end, content_end))
    if end <= start:
        end = min(content_end, start + 1)
    return start, end


def _goto_page_start(doc, page_num: int) -> int:
    """GoTo page start; retries on RPC_E_CALL_REJECTED."""
    attempts = 0
    delay = 0.5
    while True:
        try:
            rng = doc.GoTo(WD_GO_TO_PAGE, WD_GO_TO_ABSOLUTE, page_num)
            return int(rng.Start)
        except Exception as exc:
            if attempts < 5 and _is_com_busy(exc):
                attempts += 1
                _log(f"    [COM busy] GoTo p{page_num} retry {attempts}/5 "
                     f"in {delay:.1f}s …")
                time.sleep(delay)
                delay = min(delay * 2, 5.0)
            else:
                raise


def _ensure_page_starts(
    doc,
    cache: dict[int, int],
    page_from: int,
    page_to: int,
    total_pages: int,
) -> int:
    """Populate cache[pn] via GoTo for pages page_from … page_to (+ delimiter)."""
    last_needed = page_to + 1 if page_to < total_pages else page_to
    new_gotos = 0
    for pn in range(page_from, last_needed + 1):
        if pn in cache:
            continue
        cache[pn] = _goto_page_start(doc, pn)
        new_gotos += 1
    return new_gotos


def _page_number_at_position(doc, char_index: int) -> Optional[int]:
    """Fallback: page number at character index via Information()."""
    try:
        rng = doc.Range(max(0, char_index), max(0, char_index))
        pn = int(rng.Information(_WD_ACTIVE_END_PAGE_NUMBER))
        return pn if pn > 0 else None
    except Exception:
        return None


def safe_doc_range(
    doc,
    start: int,
    end: int,
    *,
    page_num: int = 0,
    content_end: int = 0,
    cache_source: str = "",
    retry_count: int = 0,
):
    """
    Create doc.Range(start, end) with clamping and COM error handling.
    Returns Range or None on unrecoverable failure.
    """
    if content_end <= 0:
        content_end = get_doc_content_end(doc)
    start, end = clamp_range_bounds(start, end, content_end)

    if start >= end:
        _log(
            f"  [page_range] SKIP invalid span p{page_num}: "
            f"start={start} end={end} content_end={content_end} "
            f"source={cache_source} retry={retry_count}"
        )
        return None

    try:
        return doc.Range(start, end)
    except Exception as exc:
        if is_com_range_error(exc) or _is_com_busy(exc):
            _log(
                f"  [page_range] COM range failed p{page_num}: {exc} | "
                f"start={start} end={end} content_end={content_end} "
                f"source={cache_source} retry={retry_count}"
            )
        else:
            raise
    return None


def safe_page_range(
    doc,
    page_num: int,
    cache: dict[int, int],
    total_pages: int,
    content_end_ref: dict[str, int],
    *,
    max_attempts: int = 4,
):
    """
    Build a page body Range with validated cache + GoTo fallback.

    *content_end_ref* is mutated: {"value": int} — refreshed on repagination.

    Returns (range_or_none, diagnostics_dict).
    """
    diag: dict[str, Any] = {
        "page_num": page_num,
        "total_pages": total_pages,
        "cache_source": "cache",
        "retry_count": 0,
        "repagination_events": 0,
        "fallback": None,
    }

    for attempt in range(max_attempts):
        diag["retry_count"] = attempt
        content_end = content_end_ref.get("value") or 0
        if content_end <= 0:
            content_end = get_doc_content_end(doc)
        content_end_ref["value"] = content_end
        diag["content_end"] = content_end

        _ensure_page_starts(doc, cache, page_num, page_num, total_pages)

        ok, reason = _cache_monotonic_ok(
            cache, page_num, page_num, content_end)
        if not ok:
            diag["repagination_events"] += 1
            invalidate_page_boundary_cache(
                cache, from_page=page_num, reason=f"stale_cache:{reason}")
            content_end_ref["value"] = get_doc_content_end(doc)
            continue

        start = cache.get(page_num)
        if start is None:
            invalidate_page_boundary_cache(
                cache, from_page=page_num, reason="cache_miss")
            continue

        if page_num < total_pages:
            end = cache.get(page_num + 1)
            if end is None:
                invalidate_page_boundary_cache(
                    cache, from_page=page_num + 1, reason="delimiter_miss")
                continue
        else:
            end = content_end

        diag["start"] = start
        diag["end"] = end

        if end > content_end or start >= content_end or start >= end:
            diag["repagination_events"] += 1
            _log(
                f"  [page_boundaries] stale offsets p{page_num}: "
                f"start={start} end={end} content_end={content_end} "
                f"attempt={attempt + 1}/{max_attempts}"
            )
            invalidate_page_boundary_cache(
                cache, from_page=page_num,
                reason="bounds_mismatch")
            content_end_ref["value"] = get_doc_content_end(doc)
            _ensure_page_starts(doc, cache, page_num, page_num, total_pages)
            continue

        rng = safe_doc_range(
            doc, start, end,
            page_num=page_num,
            content_end=content_end,
            cache_source="cache",
            retry_count=attempt,
        )
        if rng is not None:
            reported = safe_com(
                lambda r=rng: int(r.Information(_WD_ACTIVE_END_PAGE_NUMBER)),
                default=None,
            )
            if reported is not None and reported != page_num:
                _log(
                    f"  [page_boundaries] page drift p{page_num}: "
                    f"Information reports p{reported} "
                    f"(start={start} end={end}) — invalidating"
                )
                diag["repagination_events"] += 1
                invalidate_page_boundary_cache(
                    cache, from_page=page_num, reason="page_drift")
                try:
                    del rng
                except Exception:
                    pass
                content_end_ref["value"] = get_doc_content_end(doc)
                continue
            diag["start"] = start
            diag["end"] = end
            return rng, diag

        diag["repagination_events"] += 1
        invalidate_page_boundary_cache(
            cache, from_page=page_num, reason="range_com_error")

    diag["cache_source"] = "goto_fallback"
    diag["fallback"] = "goto"
    try:
        content_end = get_doc_content_end(doc)
        content_end_ref["value"] = content_end
        start = _goto_page_start(doc, page_num)
        cache[page_num] = start
        if page_num < total_pages:
            end = _goto_page_start(doc, page_num + 1)
            cache[page_num + 1] = end
        else:
            end = content_end
        diag["start"] = start
        diag["end"] = end
        diag["content_end"] = content_end
        rng = safe_doc_range(
            doc, start, end,
            page_num=page_num,
            content_end=content_end,
            cache_source="goto_fallback",
            retry_count=max_attempts,
        )
        if rng is not None:
            return rng, diag
    except Exception as exc:
        _log(f"  [page_boundaries] GoTo fallback failed p{page_num}: {exc}")

    diag["fallback"] = "minimal"
    try:
        content_end = get_doc_content_end(doc)
        content_end_ref["value"] = content_end
        start = _goto_page_start(doc, page_num)
        start, end = clamp_range_bounds(start, min(start + 1, content_end), content_end)
        rng = safe_doc_range(
            doc, start, end,
            page_num=page_num,
            content_end=content_end,
            cache_source="minimal",
            retry_count=max_attempts,
        )
        return rng, diag
    except Exception as exc:
        _log(f"  [page_boundaries] minimal fallback failed p{page_num}: {exc}")
        diag["error"] = str(exc)
        return None, diag


def refresh_content_end_after_mutation(
    doc,
    content_end_ref: dict[str, int],
    cache: Optional[dict[int, int]] = None,
    invalidate_from: int = 1,
    reason: str = "",
) -> int:
    """
    Call after layout/HF/body edits that may repaginate.
    Updates content_end_ref and optionally invalidates page-start cache.
    """
    new_end = get_doc_content_end(doc)
    old_end = content_end_ref.get("value", 0)
    content_end_ref["value"] = new_end
    if cache is not None and (old_end != new_end or invalidate_from > 1 or reason):
        invalidate_page_boundary_cache(
            cache, from_page=max(1, invalidate_from), reason=reason)
    if reason and old_end != new_end:
        _log(
            f"  [page_boundaries] Content.End {old_end} -> {new_end} ({reason})"
        )
    return new_end
