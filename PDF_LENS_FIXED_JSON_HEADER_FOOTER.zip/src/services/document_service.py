"""
document_service.py — orchestrates PDF→DOCX conversion, extraction pipeline, modifier.

Safety:
  • Input validation (size, PDF magic, DOCX OPC structure)
  • Temp-then-rename for converted DOCX (atomic publish)
  • Guaranteed cleanup of temps and partial outputs on failure
  • Structured JSON logging
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import traceback
import uuid
import zipfile
from dataclasses import dataclass, field

from src.utils.file_util import (
    atomic_replace,
    ensure_dir,
    get_file_extension,
    is_allowed_file,
    safe_unlink,
    validate_docx_package,
    validate_input_file,
)
from src.services.extractors.pdf_converter import convert_pdf_to_docx
from src.services.pipeline.document_pipeline import run_docx_pipeline
from src.services.docx_modifier import modify_docx_copy

from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.document_service")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)




_LOG = logging.getLogger("pdf_lens.document_service")


def _log(event: str, msg: str = "", **fields) -> None:
    payload = {"event": event, **fields}
    if msg:
        payload["msg"] = msg
    line = json.dumps(payload, default=str)
    _LOG.info(line)
    _slog(f"[service] {line}")


@dataclass
class _WorkSession:
    """Tracks intermediate files for cleanup on success/failure."""
    output_folder: str
    temp_paths: list[str] = field(default_factory=list)
    partial_outputs: list[str] = field(default_factory=list)
    succeeded: bool = False

    def track_temp(self, path: str) -> str:
        path = os.path.abspath(path)
        self.temp_paths.append(path)
        return path

    def track_partial(self, path: str) -> str:
        path = os.path.abspath(path)
        self.partial_outputs.append(path)
        return path

    def cleanup(self) -> None:
        if self.succeeded:
            for path in self.temp_paths:
                safe_unlink(path)
        else:
            for path in self.temp_paths + self.partial_outputs:
                safe_unlink(path)
            _log("cleanup_failure", paths_removed=len(self.temp_paths) + len(self.partial_outputs))


def _resolve_word_instance(explicit_instance):
    """Use caller-supplied adapter, else worker persistent adapter, else None."""
    if explicit_instance is not None:
        return explicit_instance
    try:
        from worker import _adapter as worker_adapter  # noqa: PLC0415
        return worker_adapter
    except (ImportError, AttributeError):
        return None


def _sanitize_base_name(filename: str) -> str:
    stem = os.path.splitext(os.path.basename(filename))[0]
    safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in stem)
    return (safe or "document")[:80]


# def _convert_pdf_atomic(
#     pdf_path: str,
#     output_folder: str,
#     base_name: str,
#     session: _WorkSession,
# ) -> str:
#     """
#     Convert PDF to DOCX via Word into a temp file, validate OPC package,
#     then atomically publish as {base}_converted.docx.
#     """
#     final_docx = os.path.join(output_folder, f"{base_name}_converted.docx")
#     tmp_docx = session.track_temp(
#         os.path.join(output_folder, f"_tmp_{uuid.uuid4().hex[:8]}_{base_name}_converted.docx")
#     )
#     session.track_partial(final_docx)

#     _log("pdf_convert_start", src=pdf_path, tmp=tmp_docx)
#     convert_pdf_to_docx(pdf_path, tmp_docx)
#     validate_docx_package(tmp_docx)
#     atomic_replace(tmp_docx, final_docx)

#     if tmp_docx in session.temp_paths:
#         session.temp_paths.remove(tmp_docx)
#     _log("pdf_convert_done", dest=final_docx, size_bytes=os.path.getsize(final_docx))
#     return final_docx

def _convert_pdf_atomic(
    pdf_path: str,
    output_folder: str,
    base_name: str,
    session: _WorkSession,
) -> str:
    """
    Convert PDF to DOCX via Word into a temp file, validate OPC package.
    Converted file is kept as temp only (not saved to output folder).
    """
    # final_docx = os.path.join(output_folder, f"{base_name}_converted.docx")
    tmp_docx = session.track_temp(
        os.path.join(output_folder, f"_tmp_{uuid.uuid4().hex[:8]}_{base_name}_converted.docx")
    )
    # session.track_partial(final_docx)

    _log("pdf_convert_start", src=pdf_path, tmp=tmp_docx)
    convert_pdf_to_docx(pdf_path, tmp_docx)
    validate_docx_package(tmp_docx)
    # atomic_replace(tmp_docx, final_docx)

    # if tmp_docx in session.temp_paths:
    #     session.temp_paths.remove(tmp_docx)
    # _log("pdf_convert_done", dest=final_docx, size_bytes=os.path.getsize(final_docx))
    return tmp_docx


def _prepare_docx_input(
    file_path: str,
    output_folder: str,
    base_name: str,
    session: _WorkSession,
) -> str:
    """
    Validate native DOCX upload. If the file lives outside the job folder,
    atomically copy into the job dir before pipeline mutation.
    """
    validate_docx_package(file_path)

    job_resolved = os.path.abspath(output_folder)
    src_resolved = os.path.abspath(file_path)
    if os.path.commonpath([job_resolved, src_resolved]) == job_resolved:
        _log("docx_input_in_job_dir", path=src_resolved)
        return src_resolved

    # canonical = session.track_temp(
    #     os.path.join(output_folder, f"_tmp_{uuid.uuid4().hex[:8]}_{base_name}_source.docx")
    # )
    # final_canonical = os.path.join(output_folder, f"{base_name}_source.docx")
    # session.track_partial(final_canonical)

    # shutil.copy2(src_resolved, canonical)
    # validate_docx_package(canonical)
    # atomic_replace(canonical, final_canonical)
    # if canonical in session.temp_paths:
    #     session.temp_paths.remove(canonical)
    # _log("docx_copied_to_job", src=src_resolved, dest=final_canonical)
    # return final_canonical
    canonical = session.track_temp(
        os.path.join(output_folder, f"_tmp_{uuid.uuid4().hex[:8]}_{base_name}_source.docx")
    )
    # final_canonical = os.path.join(output_folder, f"{base_name}_source.docx")
    # session.track_partial(final_canonical)

    shutil.copy2(src_resolved, canonical)
    validate_docx_package(canonical)
    # atomic_replace(canonical, final_canonical)
    # if canonical in session.temp_paths:
    #     session.temp_paths.remove(canonical)
    _log("docx_copied_to_job", src=src_resolved, dest=canonical)
    return canonical


def process_document(
    file_path: str,
    filename: str,
    output_folder: str,
    extract_tables: bool = True,
    extract_images: bool = True,
    extract_header: bool = True,
    extract_footer: bool = True,
    extract_hyperlinks: bool = True,
    extract_footnote: bool = False,
    _word_instance=None,
) -> dict:
    """
    End-to-end document processing for one job.

    Returns the pipeline result dict (same schema as before).
    Raises on fatal validation/conversion/pipeline errors; modifier errors are
    logged and omitted from result paths (non-fatal, unchanged behaviour).
    """
    file_path = os.path.abspath(file_path)
    output_folder = os.path.abspath(output_folder)
    ensure_dir(output_folder)

    safe_filename = os.path.basename(filename) if filename else os.path.basename(file_path)
    if not is_allowed_file(safe_filename):
        raise ValueError(f"Unsupported file type: {safe_filename!r}")

    ext = get_file_extension(safe_filename) or get_file_extension(file_path)
    base_name = _sanitize_base_name(safe_filename)
    session = _WorkSession(output_folder=output_folder)

    _log(
        "process_start",
        file=file_path,
        filename=safe_filename,
        ext=ext,
        output_folder=output_folder,
    )

    try:
        input_size = validate_input_file(file_path, ext)
        _log("input_validated", size_bytes=input_size)

        if ext == ".pdf":
            docx_path = _convert_pdf_atomic(file_path, output_folder, base_name, session)
            pdf_path = file_path
        elif ext == ".docx":
            docx_path = _prepare_docx_input(file_path, output_folder, base_name, session)
            pdf_path = ""
        elif ext == ".doc":
            validate_input_file(file_path, ext)
            docx_path = file_path
            pdf_path = ""
        else:
            raise ValueError(f"Unsupported extension: {ext!r}")

        word_instance = _resolve_word_instance(_word_instance)

        if ext == ".pdf":
            from src.pipeline.layout_guided_pipeline import LayoutGuidedPipeline
            pipeline = LayoutGuidedPipeline(
                pdf_path=pdf_path,
                output_folder=output_folder,
                temp_docx_path=docx_path,
                extract_tables=extract_tables,
                extract_images=extract_images,
                extract_header=extract_header,
                extract_footer=extract_footer,
                extract_hyperlinks=extract_hyperlinks,
                extract_footnote=extract_footnote,
                word_instance=word_instance
            )
            result = pipeline.run_full_pipeline()
            # Update docx_path to point to the repaired docx for modifier
            docx_path = result.get("doc_path", docx_path)
        else:
            result = run_docx_pipeline(
                pdf_path=pdf_path,
                doc_path=docx_path,
                output_folder=output_folder,
                base_name=base_name,
                extract_tables=extract_tables,
                extract_images=extract_images,
                extract_header=extract_header,
                extract_footer=extract_footer,
                extract_hyperlinks=extract_hyperlinks,
                extract_footnote=extract_footnote,
                _word_instance=word_instance,
            )

        post_pipeline_validate = docx_path
        if os.path.isfile(post_pipeline_validate):
            try:
                validate_docx_package(post_pipeline_validate)
            except ValueError as exc:
                _log("docx_post_pipeline_invalid", path=post_pipeline_validate, error=str(exc))
                raise

        try:
            _log("modifier_start", docx=docx_path)
            modifier_result = modify_docx_copy(
                original_docx=docx_path,
                output_folder=output_folder,
                extract_images=extract_images,
                extract_tables=extract_tables,
                extract_header=extract_header,
                extract_footer=extract_footer,
                extract_hyperlink=extract_hyperlinks,
                extract_footnote=extract_footnote,
                base_name_override=base_name,
            )
            modified_path = modifier_result.get("modified_docx")
            if modified_path and os.path.isfile(modified_path):
                validate_docx_package(modified_path)

            saved_files = result.get("saved_files") or {}
            saved_files["original_docx"] = modifier_result.get("original_docx")
            saved_files["modified_docx"] = modifier_result.get("modified_docx")
            result["saved_files"] = saved_files
            result["original_docx"] = modifier_result.get("original_docx")
            result["modified_docx"] = modifier_result.get("modified_docx")
            _log("modifier_done", modified=modified_path)
        except Exception as exc:
            _log(
                "modifier_error",
                error=str(exc),
                traceback=traceback.format_exc(),
            )

        result["filename"] = safe_filename
        result["extract_tables"] = extract_tables
        result["extract_images"] = extract_images
        result["extract_header"] = extract_header
        result["extract_footer"] = extract_footer
        result["extract_hyperlinks"] = extract_hyperlinks
        result["extract_footnote"] = extract_footnote

        # --- ZIP the output folder (saved next to the folder, not inside it) ---
        base_output_dir = os.path.dirname(output_folder)
        folder_name = os.path.basename(output_folder)
        zip_path = os.path.join(base_output_dir, f"{folder_name}.zip")
        try:
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for root, dirs, files in os.walk(output_folder):
                    for file in files:
                        abs_path = os.path.join(root, file)
                        arcname = os.path.relpath(abs_path, base_output_dir)
                        zf.write(abs_path, arcname)
            _log("zip_created", path=zip_path)
        except Exception as exc:
            zip_path = None
            _log("zip_failed", error=str(exc))

        # --- Build clean saved_files for response ---
        saved_files = result.get("saved_files") or {}
        result["saved_files"] = {
            "processed_docx": saved_files.get("modified_docx"),
            "meta_json":      next(
                (v for k, v in saved_files.items() if "analysis" in k or "meta" in k),
                result.get("full_analysis_json"),
            ),
            "zip_location":   zip_path,
        }

        session.succeeded = True
        _log("process_done", total_pages=result.get("total_pages", 0))
        return result

    except Exception as exc:
        _log("process_failed", error=str(exc), traceback=traceback.format_exc())
        raise

    finally:
        session.cleanup()