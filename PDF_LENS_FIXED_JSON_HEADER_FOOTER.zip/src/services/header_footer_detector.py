import re
from collections import defaultdict
from src.schema.layout_schema import DocumentLayout, HeaderCandidate, FooterCandidate

class HeaderFooterDetector:
    """
    Detects dynamic headers and footers across a DocumentLayout
    using cross-page repetition and relative positioning.
    """
    
    def __init__(self, layout: DocumentLayout):
        self.layout = layout
        self.header_zone_ratio = 0.15  # Top 15%
        self.footer_zone_ratio = 0.85  # Bottom 15%

    def _normalize_text(self, text: str) -> str:
        """Removes numbers (like page numbers) and whitespace to find repeating patterns."""
        # Strip digits and extra whitespace
        text = re.sub(r'\d+', '', text)
        return " ".join(text.split()).strip().lower()

    def detect_and_extract(self):
        """Runs the detection algorithm and modifies the DocumentLayout in place."""
        if not self.layout.pages:
            return

        total_pages = len(self.layout.pages)
        if total_pages < 2:
            return # Hard to find cross-page repetition on a single page

        header_freq = defaultdict(int)
        footer_freq = defaultdict(int)

        # Pass 1: Build frequency map of candidates in the zones
        for page in self.layout.pages:
            header_limit = page.height * self.header_zone_ratio
            footer_limit = page.height * self.footer_zone_ratio

            for p in page.paragraphs:
                if not p.bbox:
                    continue
                
                norm_text = self._normalize_text(p.text)
                if not norm_text: # Might just be a page number, which is common. We'll count the raw structure later or rely on position.
                    continue
                
                if p.bbox.y0 <= header_limit:
                    header_freq[norm_text] += 1
                elif p.bbox.y0 >= footer_limit:
                    footer_freq[norm_text] += 1

        # Calculate frequency thresholds (e.g., appears on at least 30% of pages)
        freq_threshold = max(2, int(total_pages * 0.3))

        strong_headers = {text for text, count in header_freq.items() if count >= freq_threshold}
        strong_footers = {text for text, count in footer_freq.items() if count >= freq_threshold}

        # Pass 2: Extract and move paragraphs
        for page in self.layout.pages:
            header_limit = page.height * self.header_zone_ratio
            footer_limit = page.height * self.footer_zone_ratio
            
            remaining_paragraphs = []
            
            for p in page.paragraphs:
                if not p.bbox:
                    remaining_paragraphs.append(p)
                    continue

                norm_text = self._normalize_text(p.text)
                is_header = False
                is_footer = False

                if p.bbox.y0 <= header_limit:
                    # It's in the header zone.
                    # Either it matches a strong repeating pattern, OR it's just a raw number (page number) in the header zone.
                    if norm_text in strong_headers or (not norm_text and p.text.strip().isdigit()):
                        page.headers.append(HeaderCandidate(
                            text=p.text, bbox=p.bbox, confidence=0.9 if norm_text in strong_headers else 0.5
                        ))
                        is_header = True

                elif p.bbox.y0 >= footer_limit:
                    if norm_text in strong_footers or (not norm_text and p.text.strip().isdigit()):
                        page.footers.append(FooterCandidate(
                            text=p.text, bbox=p.bbox, confidence=0.9 if norm_text in strong_footers else 0.5
                        ))
                        is_footer = True
                
                if not is_header and not is_footer:
                    remaining_paragraphs.append(p)
            
            # Update the page paragraphs, effectively removing headers/footers from the body
            page.paragraphs = remaining_paragraphs
