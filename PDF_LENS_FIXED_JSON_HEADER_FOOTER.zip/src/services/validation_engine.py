import json
import logging
from pathlib import Path
import docx

from src.schema.layout_schema import DocumentLayout

logger = logging.getLogger(__name__)

class ValidationEngine:
    """
    Validates the final repaired DOCX against the source-of-truth DocumentLayout model.
    Generates a QA report and metadata.
    """
    def __init__(self, docx_path: str | Path, layout: DocumentLayout):
        self.docx_path = Path(docx_path)
        self.layout = layout

    def validate_and_generate_report(self) -> dict:
        """
        Runs validation checks and generates the QA report dictionary.
        """
        logger.info("Starting Validation Engine QA checks...")
        
        try:
            doc = docx.Document(self.docx_path)
        except Exception as e:
            logger.error(f"Failed to open DOCX for validation: {e}")
            return {"status": "error", "error": str(e)}

        report = {
            "qa_status": "passed",
            "confidence_score": 1.0,
            "metrics": {
                "expected_pages": self.layout.total_pages,
                "missing_paragraphs": 0,
                "missing_images": 0,
                "missing_tables": 0
            },
            "warnings": []
        }

        # 1. Gather all text from the docx for rough checking
        docx_text = "\n".join([p.text for p in doc.paragraphs]).lower()

        # 2. Validate Paragraphs
        total_p = 0
        missing_p = 0
        for page in self.layout.pages:
            for p in page.paragraphs:
                if len(p.text.strip()) > 10:  # Only check substantial paragraphs
                    total_p += 1
                    # A very loose check: at least first 15 chars should be in the docx text
                    snippet = p.text.strip()[:15].lower()
                    if snippet and snippet not in docx_text:
                        missing_p += 1

        if total_p > 0:
            report["metrics"]["missing_paragraphs"] = missing_p
            if missing_p > 0:
                report["warnings"].append(f"Could not find {missing_p} out of {total_p} source paragraphs.")
                report["confidence_score"] -= (missing_p / total_p) * 0.5

        # 3. Validate Images & Tables placeholders
        expected_images = sum(len(page.images) for page in self.layout.pages)
        expected_tables = sum(len(page.tables) for page in self.layout.pages)

        found_images = docx_text.count("<image_")
        found_tables = docx_text.count("<table_")

        if found_images < expected_images:
            report["metrics"]["missing_images"] = expected_images - found_images
            report["warnings"].append(f"Missing {expected_images - found_images} image placeholders.")
            report["confidence_score"] -= 0.1

        if found_tables < expected_tables:
            report["metrics"]["missing_tables"] = expected_tables - found_tables
            report["warnings"].append(f"Missing {expected_tables - found_tables} table placeholders.")
            report["confidence_score"] -= 0.1

        # Finalize
        if report["confidence_score"] < 0.7:
            report["qa_status"] = "review_needed"
        
        report["confidence_score"] = round(max(0.0, report["confidence_score"]), 2)
        return report

    def save_meta_json(self, output_dir: str | Path):
        """Generates and saves the final meta.json."""
        report = self.validate_and_generate_report()
        
        meta_path = Path(output_dir) / "meta.json"
        
        final_meta = {
            "document_info": {
                "total_pages": self.layout.total_pages,
            },
            "layout_data": self.layout.model_dump(),
            "qa_report": report
        }
        
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(final_meta, f, indent=4)
            
        logger.info(f"Saved meta.json to {meta_path}")
        return meta_path
