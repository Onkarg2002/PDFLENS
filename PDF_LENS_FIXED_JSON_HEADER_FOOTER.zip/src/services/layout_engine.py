import fitz  # PyMuPDF
from typing import Optional, List
from pathlib import Path

from src.schema.layout_schema import (
    DocumentLayout, PageLayout, Paragraph, BoundingBox, 
    ImagePlaceholder, TablePlaceholder, Hyperlink, Footnote
)
from src.services.header_footer_detector import HeaderFooterDetector

class LayoutAnalysisEngine:
    """
    Analyzes the original PDF to build a DocumentLayout model.
    This serves as the source of truth for the repair pipeline.
    """
    
    def __init__(self, pdf_path: str | Path):
        self.pdf_path = Path(pdf_path)
        self.doc: Optional[fitz.Document] = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def open(self):
        """Opens the PDF document."""
        if not self.pdf_path.exists():
            raise FileNotFoundError(f"PDF file not found: {self.pdf_path}")
        self.doc = fitz.open(self.pdf_path)
    
    def close(self):
        """Closes the PDF document."""
        if self.doc is not None:
            self.doc.close()
            self.doc = None

    def build_initial_layout(self) -> DocumentLayout:
        """
        Builds the initial DocumentLayout containing basic page information
        and extracts all rich text blocks, images, and links.
        """
        if self.doc is None:
            self.open()

        layout = DocumentLayout(total_pages=len(self.doc))

        for page_num in range(len(self.doc)):
            page = self.doc[page_num]
            rect = page.rect
            page_layout = PageLayout(
                page_number=page_num + 1,  # 1-indexed
                width=rect.width,
                height=rect.height
            )
            
            self._extract_page_content(page, page_layout)
            self._extract_hyperlinks(page, page_layout)
            self._extract_footnotes(page_layout) # Heuristic after basic extraction
            
            layout.pages.append(page_layout)

        # Run dynamic header/footer detection across the whole document
        detector = HeaderFooterDetector(layout)
        detector.detect_and_extract()

        return layout

    def _extract_page_content(self, page: fitz.Page, page_layout: PageLayout):
        """Extracts text blocks, images, and tables using PyMuPDF."""
        # get_text("dict") provides structure, reading order is generally preserved by PyMuPDF's block sorting
        text_dict = page.get_text("dict", sort=True)
        blocks = text_dict.get("blocks", [])
        
        img_counter = 1
        
        for b in blocks:
            bbox = BoundingBox(x0=b["bbox"][0], y0=b["bbox"][1], x1=b["bbox"][2], y1=b["bbox"][3])
            
            if b.get("type") == 0:  # Text block
                # Combine all text in the block
                block_text = ""
                for line in b.get("lines", []):
                    for span in line.get("spans", []):
                        block_text += span.get("text", "")
                    block_text += "\n"
                
                block_text = block_text.strip()
                if block_text:
                    page_layout.paragraphs.append(
                        Paragraph(text=block_text, bbox=bbox, block_type="text")
                    )
                    
            elif b.get("type") == 1:  # Image block
                page_layout.images.append(
                    ImagePlaceholder(tag=f"<IMAGE_{img_counter}>", bbox=bbox)
                )
                img_counter += 1
                
        # Basic table detection (PyMuPDF has find_tables)
        tabs = page.find_tables()
        if tabs and tabs.tables:
            for i, tab in enumerate(tabs.tables, 1):
                t_bbox = BoundingBox(x0=tab.bbox[0], y0=tab.bbox[1], x1=tab.bbox[2], y1=tab.bbox[3])
                page_layout.tables.append(TablePlaceholder(tag=f"<TABLE_{i}>", bbox=t_bbox))

    def _extract_hyperlinks(self, page: fitz.Page, page_layout: PageLayout):
        """Extracts clickable hyperlinks."""
        links = page.get_links()
        for link in links:
            if link.get("kind") == fitz.LINK_URI:
                l_bbox = BoundingBox(x0=link["from"][0], y0=link["from"][1], x1=link["from"][2], y1=link["from"][3])
                # We can grab the text at this bounding box
                link_text = page.get_textbox(link["from"]).strip()
                page_layout.hyperlinks.append(
                    Hyperlink(text=link_text, url=link.get("uri", ""), bbox=l_bbox)
                )

    def _extract_footnotes(self, page_layout: PageLayout):
        """
        Simple heuristic for footnote extraction:
        Looks for paragraphs at the bottom 15% of the page that start with a number.
        Moves them from paragraphs to footnotes.
        """
        bottom_threshold = page_layout.height * 0.85
        
        remaining_paragraphs = []
        fn_index = 1
        
        for p in page_layout.paragraphs:
            if p.bbox and p.bbox.y0 >= bottom_threshold:
                # Basic regex or string check for footnote starting with number
                if p.text and p.text[0].isdigit() and len(p.text) > 1:
                    # It's a candidate
                    # Extract leading number as reference
                    parts = p.text.split(maxsplit=1)
                    ref = parts[0]
                    content = parts[1] if len(parts) > 1 else ""
                    
                    page_layout.footnotes.append(
                        Footnote(footnote_index=fn_index, reference_text=ref, text=content, bbox=p.bbox)
                    )
                    fn_index += 1
                    continue # Do not add to remaining_paragraphs
                    
            remaining_paragraphs.append(p)
            
        page_layout.paragraphs = remaining_paragraphs

if __name__ == "__main__":
    # Test script stub
    pass
