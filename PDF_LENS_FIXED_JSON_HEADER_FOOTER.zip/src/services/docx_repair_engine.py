import re
from pathlib import Path
from collections import defaultdict
import docx

from src.schema.layout_schema import DocumentLayout

class DOCXRepairEngine:
    """
    Repairs a generated Temporary DOCX file using the source-of-truth DocumentLayout model.
    """
    
    def __init__(self, docx_path: str | Path, layout: DocumentLayout):
        self.docx_path = Path(docx_path)
        self.layout = layout
        self.doc = docx.Document(self.docx_path)

    def _normalize_text(self, text: str) -> str:
        # Strip digits and extra whitespace for matching
        text = re.sub(r'\d+', '', text)
        return " ".join(text.split()).strip().lower()

    def _get_primary_header_footer(self):
        """Finds the most frequent header and footer across all pages."""
        header_freq = defaultdict(int)
        footer_freq = defaultdict(int)

        for page in self.layout.pages:
            for h in page.headers:
                if h.text.strip():
                    header_freq[h.text.strip()] += 1
            for f in page.footers:
                if f.text.strip():
                    footer_freq[f.text.strip()] += 1

        primary_header = max(header_freq, key=header_freq.get) if header_freq else ""
        primary_footer = max(footer_freq, key=footer_freq.get) if footer_freq else ""
        return primary_header, primary_footer

    def repair_headers_and_footers(self):
        """
        Headers and Footers are intentionally left inline in the body to preserve per-page
        differences without requiring complex Section Break manipulation in DOCX.
        
        HOWEVER, Microsoft Word's PDF converter sometimes incorrectly classifies huge chunks
        of body text at the bottom of the page as a 'Footer' and traps it in the native
        Word Footer section, causing it to repeat on every page.
        
        We use the PyMuPDF Layout Engine truth to detect this. If the text in the Word footer
        is NOT found in our PyMuPDF footers, we rip it out of the footer and dump it back
        into the body of the document.
        """
        if not self.doc.sections:
            return

        # 1. Build Truth Sets from PyMuPDF
        true_footers = set()
        true_headers = set()
        
        for page in self.layout.pages:
            for f in page.footers:
                norm = self._normalize_text(f.text)
                if norm:
                    true_footers.add(norm)
            for h in page.headers:
                norm = self._normalize_text(h.text)
                if norm:
                    true_headers.add(norm)
                    
        # 2. Audit Word Sections
        extracted_body_paragraphs = []
        
        for section in self.doc.sections:
            # Audit Footers
            if section.footer:
                # We need to collect paragraphs to delete to avoid modifying while iterating
                paragraphs_to_delete = []
                for paragraph in section.footer.paragraphs:
                    text = paragraph.text.strip()
                    if not text:
                        continue
                        
                    norm_text = self._normalize_text(text)
                    
                    # If this text is NOT in our True Footers, and it's not just a digit (page num)
                    if norm_text not in true_footers and not (not norm_text and text.isdigit()):
                        extracted_body_paragraphs.append(text)
                        paragraphs_to_delete.append(paragraph)
                        
                for p in paragraphs_to_delete:
                    p_element = p._element
                    p_element.getparent().remove(p_element)
                    
            # Audit Headers (just in case the same bug happens with headers)
            if section.header:
                paragraphs_to_delete = []
                for paragraph in section.header.paragraphs:
                    text = paragraph.text.strip()
                    if not text:
                        continue
                        
                    norm_text = self._normalize_text(text)
                    if norm_text not in true_headers and not (not norm_text and text.isdigit()):
                        extracted_body_paragraphs.append(text)
                        paragraphs_to_delete.append(paragraph)
                        
                for p in paragraphs_to_delete:
                    p_element = p._element
                    p_element.getparent().remove(p_element)

        # 3. Dump rescued body text back into the document
        if extracted_body_paragraphs:
            # Since Word completely removed this text from the normal flow, we append it
            # to the end of the document to ensure the data is not lost.
            for text in extracted_body_paragraphs:
                self.doc.add_paragraph(text)

    def repair_footnotes_and_cleanup(self):
        """
        Moves identified footnotes to the end of the document.
        Validates placeholders.
        """
        # Collect all footnotes from layout
        layout_footnotes = []
        for page in self.layout.pages:
            for fn in page.footnotes:
                layout_footnotes.append(self._normalize_text(fn.text))
                
        if not layout_footnotes:
            return

        # Find them in the document, remove from inline, save for the end
        extracted_fn_paragraphs = []
        
        for paragraph in self.doc.paragraphs:
            norm_text = self._normalize_text(paragraph.text)
            if any(fn_text in norm_text for fn_text in layout_footnotes if fn_text):
                # We found a footnote inline! Remove it.
                p_element = paragraph._element
                extracted_fn_paragraphs.append(paragraph.text)
                p_element.getparent().remove(p_element)
                
        if extracted_fn_paragraphs:
            self.doc.add_page_break()
            self.doc.add_heading('Footnotes', level=1)
            for text in extracted_fn_paragraphs:
                self.doc.add_paragraph(text)

    def repair_reading_order(self):
        """
        Attempts to align the DOCX paragraph sequence with the DocumentLayout truth.
        (Simplified implementation: relies heavily on COM ordering but validates sequence).
        """
        # Complex XML tree reordering is risky. 
        # Here we could implement the element swapping logic:
        # e.g., p1._element.addnext(p2._element)
        pass

    def save(self, output_path: str | Path):
        self.doc.save(str(output_path))
