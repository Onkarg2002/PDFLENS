from __future__ import annotations

import gc
import os
import shutil
import threading
import traceback
import win32com.client
import win32gui
import win32con
from typing import Optional
from docx import Document
from src.services.docx_xml_safe import (DocxXmlValidationError,apply_safe_body_mutations,atomic_save_document,backup_file,restore_file,set_modifier_logger,validate_docx_package_deep,validate_saved_docx,)
from src.utils.file_util import validate_docx_package
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.docx_modifier")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)

_TWIPS_PER_PT = 20
_ROW_HEIGHT_PT = 14.0
_MIN_H_PT = 10.0


def _run_com_cleanups(
    modified_path: str,
    extract_header: bool,
    extract_footer: bool,
    extract_hyperlink: bool,
    extract_footnote: bool = False,
) -> None:
    """
    Open the saved modified DOCX in Word COM and clear headers/footers,
    remove footnotes, and optionally replace hyperlinks with tags.
    """
    if not (extract_header or extract_footer or extract_hyperlink or extract_footnote):
        return

    WD_HEADER_FOOTER_PRIMARY = 1
    WD_HEADER_FOOTER_FIRST_PAGE = 2
    WD_HEADER_FOOTER_EVEN_PAGES = 3

    stop_evt = threading.Event()

    def _dismiss(stop: threading.Event) -> None:
        titles = {"microsoft word", "word"}

        def _click(hwnd, words):
            found = []

            def _cb(h, _):
                if "button" not in win32gui.GetClassName(h).lower():
                    return True
                t = win32gui.GetWindowText(h).strip().lower().replace("&", "")
                if any(w in t for w in words):
                    found.append(h)
                    return False
                return True

            try:
                win32gui.EnumChildWindows(hwnd, _cb, None)
            except Exception:
                pass
            if found:
                try:
                    win32gui.SendMessage(found[0], win32con.BM_CLICK, 0, 0)
                except Exception:
                    pass
                return True
            return False

        def _on_win(hwnd, _):
            if not win32gui.IsWindowVisible(hwnd):
                return True
            title = win32gui.GetWindowText(hwnd).strip().lower()
            if title not in titles:
                return True
            if _click(hwnd, ["don't save", "dont save", "no"]):
                return True
            _click(hwnd, ["ok", "yes"])
            return True

        while not stop.is_set():
            try:
                win32gui.EnumWindows(_on_win, None)
            except Exception:
                pass
            stop.wait(0.12)

    dt = threading.Thread(target=_dismiss, args=(stop_evt,), daemon=True)
    dt.start()

    word = None
    doc = None
    try:
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0

        doc = word.Documents.Open(
            FileName=modified_path,
            ConfirmConversions=False,
            AddToRecentFiles=False,
            ReadOnly=False,
            NoEncodingDialog=True,
            Revert=False,
        )

        def _safe(fn, default=None):
            try:
                return fn()
            except Exception:
                return default

        if extract_footnote:
            _slog("  [modifier] Removing footnotes via COM …")
            total = _safe(lambda: doc.Footnotes.Count, 0)
            removed = 0
            for i in range(total, 0, -1):
                fn = _safe(lambda idx=i: doc.Footnotes(idx))
                if fn is None:
                    continue
                try:
                    fn.Delete()
                    removed += 1
                except Exception as e:
                    _slog(f"    [modifier] footnote {i}: {e}")
            _slog(f"  [modifier] Footnotes removed: {removed}/{total}")

        if extract_header:
            _slog("  [modifier] Clearing headers …")
            for si in range(1, _safe(lambda: doc.Sections.Count, 0) + 1):
                sec = _safe(lambda i=si: doc.Sections(i))
                if sec is None:
                    continue
                for hf_c, lbl in [
                    (WD_HEADER_FOOTER_PRIMARY, "Hdr-Primary"),
                    (WD_HEADER_FOOTER_FIRST_PAGE, "Hdr-FirstPage"),
                    (WD_HEADER_FOOTER_EVEN_PAGES, "Hdr-EvenPages"),
                ]:
                    try:
                        hf = sec.Headers(hf_c)
                        rng = _safe(lambda h=hf: h.Range)
                        if rng:
                            _safe(lambda r=rng: r.Delete())
                        shapes = _safe(lambda h=hf: h.Shapes)
                        if shapes:
                            for j in range(_safe(lambda s=shapes: s.Count, 0), 0, -1):
                                s = _safe(lambda ss=shapes, jj=j: ss(jj))
                                if s:
                                    _safe(lambda sh=s: sh.Delete())
                        _slog(f"    [modifier] {lbl} sec={si} cleared")
                    except Exception as e:
                        _slog(f"    [modifier] {lbl} sec={si}: {e}")

        if extract_footer:
            _slog("  [modifier] Clearing footers …")
            for si in range(1, _safe(lambda: doc.Sections.Count, 0) + 1):
                sec = _safe(lambda i=si: doc.Sections(i))
                if sec is None:
                    continue
                for hf_c, lbl in [
                    (WD_HEADER_FOOTER_PRIMARY, "Ftr-Primary"),
                    (WD_HEADER_FOOTER_FIRST_PAGE, "Ftr-FirstPage"),
                    (WD_HEADER_FOOTER_EVEN_PAGES, "Ftr-EvenPages"),
                ]:
                    try:
                        hf = sec.Footers(hf_c)
                        rng = _safe(lambda h=hf: h.Range)
                        if rng:
                            _safe(lambda r=rng: r.Delete())
                        shapes = _safe(lambda h=hf: h.Shapes)
                        if shapes:
                            for j in range(_safe(lambda s=shapes: s.Count, 0), 0, -1):
                                s = _safe(lambda ss=shapes, jj=j: ss(jj))
                                if s:
                                    _safe(lambda sh=s: sh.Delete())
                        _slog(f"    [modifier] {lbl} sec={si} cleared")
                    except Exception as e:
                        _slog(f"    [modifier] {lbl} sec={si}: {e}")

        if extract_hyperlink:
            _slog("  [modifier] Replacing hyperlinks with tags …")
            total = _safe(lambda: doc.Hyperlinks.Count, 0)
            replaced = 0
            tag_map = {hi: f"<doc_ai_hyperlink_{hi}>" for hi in range(1, total + 1)}
            for hi in range(total, 0, -1):
                hl = _safe(lambda i=hi: doc.Hyperlinks(i))
                tag = tag_map.get(hi, f"<doc_ai_hyperlink_{hi}>")
                if hl is None:
                    continue
                try:
                    rng = _safe(lambda h=hl: h.Range)
                    if rng is not None:
                        _safe(lambda r=rng, t=tag: setattr(r, "Text", t))
                    hl.Delete()
                    replaced += 1
                except Exception as e:
                    _slog(f"    [modifier] hyperlink {hi}: {e}")
            _slog(f"  [modifier] Hyperlinks replaced: {replaced}/{total}")

        doc.Save()
        doc.Close(SaveChanges=0)
        doc = None

    except Exception as exc:
        _slog(f"[modifier] COM cleanup error: {exc}")
        traceback.print_exc()
        if doc is not None:
            try:
                doc.Close(SaveChanges=0)
            except Exception:
                pass
        raise
    finally:
        stop_evt.set()
        dt.join(timeout=3)
        if word is not None:
            try:
                word.Quit()
            except Exception:
                pass
        gc.collect()


def _apply_xml_body_replacements(modified_path: str) -> dict:
    """
    Pure-XML body tagging with validation and atomic save.
    Raises DocxXmlValidationError on unrecoverable corruption risk.
    """
    _slog("\n[modifier] Applying safe XML body replacements …")
    doc = Document(modified_path)
    body = doc.element.body

    summary = apply_safe_body_mutations(
        body,
        replace_images=True,
        replace_tables=True,
    )

    for section, stats in summary.items():
        _slog(f"  [modifier/xml] {section}: {stats}")

    atomic_save_document(doc, modified_path)
    del doc
    gc.collect()
    return summary


def modify_docx_copy(
    original_docx: str,
    output_folder: str,
    extract_images: bool = True,
    extract_tables: bool = True,
    extract_header: bool = True,
    extract_footer: bool = True,
    extract_hyperlink: bool = True,
    extract_footnote: bool = False,
    base_name_override: str = "",
) -> dict:
    """
    Create a modified copy of `original_docx` with placeholder text tags.

    Body replacements use validated OpenXML surgery (docx_xml_safe).
    Header/footer clearing and footnote removal use COM.

    Recovery:
      - Validates input OPC package before copy
      - Backup before XML mutation; restore on XML failure
      - After successful XML, backup again before COM; COM failure keeps XML result
    """
    set_modifier_logger(print)

    original_docx = os.path.abspath(original_docx)
    output_folder = os.path.abspath(output_folder)
    os.makedirs(output_folder, exist_ok=True)

    base_name = base_name_override if base_name_override else os.path.splitext(os.path.basename(original_docx))[0]
    modified_path = os.path.join(output_folder, f"{base_name}_processed.docx")

    _slog(f"\n[modifier] Validating source DOCX …")
    try:
        validate_docx_package_deep(original_docx)
    except (ValueError, DocxXmlValidationError) as exc:
        raise DocxXmlValidationError(
            f"Source DOCX failed validation: {exc}"
        ) from exc

    _slog(f"\n[modifier] Copying DOCX:")
    _slog(f"  src  : {original_docx}")
    _slog(f"  dest : {modified_path}")
    shutil.copy2(original_docx, modified_path)

    pre_xml_backup = backup_file(modified_path, suffix=".pre_xml.bak")
    xml_ok_backup: Optional[str] = None
    xml_summary: dict = {}

    try:
        xml_summary = _apply_xml_body_replacements(modified_path)
        validate_saved_docx(modified_path)
        xml_ok_backup = backup_file(modified_path, suffix=".xml_ok.bak")
        _slog(f"[modifier] XML phase OK → {modified_path}")
    except Exception as exc:
        _slog(f"[modifier] XML phase FAILED: {exc}")
        traceback.print_exc()
        restore_file(pre_xml_backup, modified_path)
        _slog(f"[modifier] Restored pristine copy from {pre_xml_backup}")
        if os.path.isfile(pre_xml_backup):
            os.remove(pre_xml_backup)
        raise DocxXmlValidationError(
            f"XML body mutation failed; restored original copy: {exc}"
        ) from exc

    # pre_xml backup no longer needed after XML succeeded
    if os.path.isfile(pre_xml_backup):
        os.remove(pre_xml_backup)

    _slog("\n[modifier] Footnotes will be removed via COM …")
    try:
        _run_com_cleanups(
            modified_path=modified_path,
            extract_header=True,
            extract_footer=True,
            extract_hyperlink=False,
            extract_footnote=True,
        )
        try:
            validate_docx_package(modified_path)
        except ValueError as exc:
            _slog(f"[modifier] WARN post-COM package check: {exc}")
    except Exception as exc:
        _slog(f"[modifier] COM phase FAILED (non-fatal): {exc}")
        traceback.print_exc()
        if xml_ok_backup and os.path.isfile(xml_ok_backup):
            restore_file(xml_ok_backup, modified_path)
            _slog(
                f"[modifier] Recovered XML-only modified DOCX from {xml_ok_backup}"
            )
    finally:
        if xml_ok_backup and os.path.isfile(xml_ok_backup):
            os.remove(xml_ok_backup)

    _slog(f"\n[modifier] Done.")
    _slog(f"  original : {original_docx}")
    _slog(f"  modified : {modified_path}")

    return {
        "original_docx": original_docx,
        "modified_docx": modified_path,
        "xml_mutation_summary": xml_summary,
    }