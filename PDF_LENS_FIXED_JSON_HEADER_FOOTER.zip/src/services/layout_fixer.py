"""
layout_fixer.py — Lock Word COM layout after PDF→DOCX conversion.

Goals:
  • Preserve page count / vertical flow (no phantom reflow from line spacing)
  • Avoid corrupting header/footer stories (scope fixes to main text)
  • Stabilise tables (row height, cell spacing, alignment, autofit)
  • Reduce floating-image drift (anchor lock, wrap sanity)
  • Defensive handling for malformed PDF zones and COM edge cases

Margins are applied in apply_pdf_zones_to_docx() — not here.
"""
from __future__ import annotations
from typing import Any, Optional
from src.constants.constant import WD_IS_IN_TABLE
from src.utils.file_util import safe_com
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.layout_fixer")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)




# Word constants 
WD_LINE_SPACE_AT_LEAST = 3
WD_LINE_SPACE_EXACTLY = 4
WD_OPTIMIZE_FOR_WORD97 = 13
WD_MAIN_TEXT_STORY = 1
WD_ROW_HEIGHT_AUTO = 0
WD_AUTOFIT_FIXED = 2
WD_ALIGN_ROW_LEFT = 0

EXACT_SPACING_MULTIPLIER = 1.05

_FALLBACK_FONT_PT = 12.0
_MIN_FONT_PT = 6.0
_MAX_FONT_PT = 72.0
_MIN_LINE_SPACING_PT = 6.0
_MAX_LINE_SPACING_PT = 96.0
_MAX_TABLE_ROWS_TOTAL = 5000
_MAX_TABLES_TOTAL = 500
_MAX_SHAPES_TOTAL = 2000


#  Logging / numeric guards

def _log(msg: str) -> None:
    _slog(msg)


def _clamp_pt(value: Any, lo: float, hi: float, default: float) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return default
    if v != v:  # NaN
        return default
    return max(lo, min(hi, v))


def _safe_font_pt(size: Any) -> Optional[float]:
    """
    Word returns -1 or 9999999 for mixed/auto sizes — ignore those.
    """
    if size is None:
        return None
    try:
        v = float(size)
    except (TypeError, ValueError):
        return None
    if v <= 0 or v > 400:
        return None
    return _clamp_pt(v, _MIN_FONT_PT, _MAX_FONT_PT, _FALLBACK_FONT_PT)


def _audit_pdf_zones(pdf_zones: dict) -> list[str]:
    """Return human-readable warnings for malformed zone dicts (non-fatal)."""
    warnings: list[str] = []
    if not pdf_zones:
        warnings.append("pdf_zones empty — geometry-only fixes skipped")
        return warnings

    for pn, zone in pdf_zones.items():
        if not isinstance(zone, dict):
            warnings.append(f"page {pn}: zone is not a dict")
            continue
        ph = zone.get("page_height_pt") or zone.get("page_height")
        if ph is not None:
            try:
                if float(ph) <= 0:
                    warnings.append(f"page {pn}: invalid page_height_pt={ph}")
            except (TypeError, ValueError):
                warnings.append(f"page {pn}: non-numeric page_height_pt")
        for key in (
            "header_top_pt", "header_height_pt",
            "footer_dist_from_bottom_pt", "footer_height_pt",
        ):
            if key in zone and zone[key] is not None:
                try:
                    if float(zone[key]) < 0:
                        warnings.append(f"page {pn}: negative {key}")
                except (TypeError, ValueError):
                    warnings.append(f"page {pn}: bad {key}={zone[key]!r}")
    return warnings


def _main_story_range(doc) -> Any:
    """
    Main document story (body text). Using doc.Content also mutates H/F and
    can corrupt header/footer spacing — StoryRanges(1) is the safe target.
    """
    story = safe_com(
        lambda: doc.StoryRanges(WD_MAIN_TEXT_STORY),
        default=None,
        label="StoryRanges(MainText)",
    )
    if story is not None:
        return story
    _log("  [layout_fixer] WARN: StoryRanges unavailable — falling back to Content")
    return safe_com(lambda: doc.Content, default=None)


#  Public entry point

def fix_docx_layout(doc, pdf_zones: dict) -> None:
    """
    Apply layout-locking steps to an open Word document.

    Steps are isolated: a failure in one step does not skip the rest.
    *pdf_zones* is audited for malformed values (margins still applied elsewhere).
    """
    _log("\n[layout_fixer] Locking document layout …")

    for w in _audit_pdf_zones(pdf_zones or {}):
        _log(f"  [layout_fixer] WARN: {w}")

    steps = (
        ("line_spacing", _fix_line_spacing),
        ("kerning", _fix_font_kerning),
        ("tables", _fix_table_layout),
        ("shapes", _fix_shape_and_image_anchors),
    )
    for name, fn in steps:
        try:
            fn(doc)
        except Exception as exc:
            _log(f"  [layout_fixer] {name} FAILED (non-fatal): {exc}")

    _log("[layout_fixer] Done.")


#  Step A: Line spacing (main story only)

def _fix_line_spacing(doc) -> None:
    """
    Set AtLeast line spacing on main-text paragraphs only.

    wdLineSpaceAtLeast: floor height — large fonts/headings can grow without
    phantom page breaks (wdLineSpaceExactly caused 40→73 page inflation).

    Widow/orphan controls disabled — they steal lines and shift pagination.
    """
    rng = _main_story_range(doc)
    if rng is None:
        _log("  [line spacing] No main story — skipping.")
        return

    base_pt = _doc_default_font_pt(doc)
    exact_pt = _clamp_pt(
        base_pt * EXACT_SPACING_MULTIPLIER,
        _MIN_LINE_SPACING_PT,
        _MAX_LINE_SPACING_PT,
        _FALLBACK_FONT_PT * EXACT_SPACING_MULTIPLIER,
    )

    pfmt = safe_com(lambda: rng.ParagraphFormat, default=None)
    if pfmt is None:
        _log("  [line spacing] ParagraphFormat unavailable — skipping.")
        return

    safe_com(lambda: setattr(pfmt, "LineSpacingRule", WD_LINE_SPACE_AT_LEAST))
    safe_com(lambda: setattr(pfmt, "LineSpacing", exact_pt))
    safe_com(lambda: setattr(pfmt, "WidowControl", False))
    safe_com(lambda: setattr(pfmt, "KeepWithNext", False))
    safe_com(lambda: setattr(pfmt, "KeepTogether", False))

    _log(
        f"  [line spacing] Main story → AtLeast {exact_pt:.1f}pt "
        f"(base={base_pt:.1f}pt × {EXACT_SPACING_MULTIPLIER})"
    )


def _doc_default_font_pt(doc) -> float:
    """Normal style → default font → first body run → fallback."""
    for getter in (
        lambda: doc.Styles("Normal").Font.Size,
        lambda: doc.DefaultFont.Size,
    ):
        pt = _safe_font_pt(safe_com(getter, default=None))
        if pt is not None:
            return pt

    story = _main_story_range(doc)
    if story is not None:
        try:
            paras = safe_com(lambda: story.Paragraphs, default=None)
            count = safe_com(lambda: paras.Count, default=0) if paras else 0
            limit = min(int(count or 0), 25)
            for i in range(1, limit + 1):
                para = safe_com(lambda idx=i: paras(idx), default=None)
                if para is None:
                    continue
                runs = safe_com(lambda p=para: p.Runs, default=None)
                rcount = safe_com(lambda: runs.Count, default=0) if runs else 0
                for ri in range(1, min(int(rcount or 0), 8) + 1):
                    run = safe_com(lambda idx=ri: runs(idx), default=None)
                    if run is None:
                        continue
                    pt = _safe_font_pt(
                        safe_com(lambda r=run: r.Font.Size, default=None))
                    if pt is not None:
                        return pt
        except Exception:
            pass

    return _FALLBACK_FONT_PT


#  Step B: Kerning (main story only)

def _fix_font_kerning(doc) -> None:
    """Disable auto-kerning and character spacing in main text."""
    rng = _main_story_range(doc)
    if rng is None:
        _log("  [kerning] No main story — skipping.")
        return

    fnt = safe_com(lambda: rng.Font, default=None)
    if fnt is None:
        _log("  [kerning] Font object unavailable — skipping.")
        return

    safe_com(lambda: setattr(fnt, "Kerning", 0))
    safe_com(lambda: setattr(fnt, "Spacing", 0))
    _log("  [kerning] Main story → kerning=0, spacing=0")


#  Step C: Tables — row height, alignment, cell spacing

def _fix_table_layout(doc) -> None:
    """
    Stabilise table layout without splitting rows when Word allows it.

    Fixes prior bug: AutoFitBehavior(0) is wdAutoFitWindow, not Fixed — use 2.
    AllowBreakAcrossPages: prefer False (keep row on one page); fallback True
    if Word rejects (some merged-row tables freeze otherwise).
    """
    n_tables = safe_com(lambda: doc.Tables.Count, default=None)
    if not n_tables:
        _log("  [table rows] No tables — skipping.")
        return

    n_tables = int(n_tables)
    if n_tables > _MAX_TABLES_TOTAL:
        _log(f"  [table rows] Capping tables {_MAX_TABLES_TOTAL}/{n_tables}")
        n_tables = _MAX_TABLES_TOTAL

    rows_fixed = 0
    tables_fixed = 0
    rows_split_ok = 0
    rows_split_fallback = 0
    rows_failed = 0

    for t_idx in range(1, n_tables + 1):
        if rows_fixed >= _MAX_TABLE_ROWS_TOTAL:
            _log(f"  [table rows] Row cap ({_MAX_TABLE_ROWS_TOTAL}) at table {t_idx}")
            break

        table = safe_com(lambda i=t_idx: doc.Tables(i), default=None)
        if table is None:
            continue

        # Fixed column layout — prevents autofit widening columns → extra wraps
        safe_com(lambda t=table: t.AutoFitBehavior(WD_AUTOFIT_FIXED))
        try:
            table.AllowAutoFit = False
        except Exception:
            pass

        # Left-align rows (PDF converter often leaves mixed alignment)
        safe_com(lambda t=table: setattr(t, "Alignment", WD_ALIGN_ROW_LEFT))

        n_rows = safe_com(lambda t=table: t.Rows.Count, default=0) or 0
        if n_rows <= 0:
            continue

        for r_idx in range(1, int(n_rows) + 1):
            if rows_fixed >= _MAX_TABLE_ROWS_TOTAL:
                break
            row = safe_com(lambda i=r_idx, tb=table: tb.Rows(i), default=None)
            if row is None:
                rows_failed += 1
                continue

            safe_com(lambda r=row: setattr(r, "HeightRule", WD_ROW_HEIGHT_AUTO))

            # Prefer whole-row pagination; fallback if COM rejects (merged cells)
            if _set_allow_break_across_pages(row, allow=False):
                rows_split_ok += 1
            elif _set_allow_break_across_pages(row, allow=True):
                rows_split_fallback += 1
            else:
                rows_failed += 1

            rows_fixed += 1

        # Zero paragraph spacing inside table (bulk per table)
        pfmt = safe_com(lambda t=table: t.Range.ParagraphFormat, default=None)
        if pfmt is not None:
            safe_com(lambda p=pfmt: setattr(p, "SpaceBefore", 0))
            safe_com(lambda p=pfmt: setattr(p, "SpaceAfter", 0))
            safe_com(lambda p=pfmt: setattr(p, "LineSpacingRule", WD_LINE_SPACE_AT_LEAST))
            cell_pt = _clamp_pt(
                _doc_default_font_pt(doc) * EXACT_SPACING_MULTIPLIER,
                _MIN_LINE_SPACING_PT,
                _MAX_LINE_SPACING_PT,
                12.0,
            )
            safe_com(lambda p=pfmt, v=cell_pt: setattr(p, "LineSpacing", v))

        _fix_table_inline_shapes(table)
        tables_fixed += 1

    _log(
        f"  [table rows] {tables_fixed}/{n_tables} table(s), {rows_fixed} row(s) — "
        f"AutoFitFixed, HeightAuto, noBreak={rows_split_ok}, "
        f"breakFallback={rows_split_fallback}, failed={rows_failed}"
    )


def _set_allow_break_across_pages(row, allow: bool) -> bool:
    try:
        row.AllowBreakAcrossPages = allow
        return True
    except Exception:
        return False


def _fix_table_inline_shapes(table) -> None:
    """
    Inline images in cells can inflate row height if layout-in-cell is off.
    Best-effort: normalise wrap on floating shapes anchored inside table.
    """
    count = safe_com(lambda: table.Range.InlineShapes.Count, default=0) or 0
    for i in range(1, int(count) + 1):
        ish = safe_com(lambda idx=i: table.Range.InlineShapes(idx), default=None)
        if ish is None:
            continue
        safe_com(lambda s=ish: setattr(s, "LockAspectRatio", True))


#  Step D: Floating / anchored shapes (coordinate stability)

def _fix_shape_and_image_anchors(doc) -> None:
    """
    Reduce post-open layout drift for floating objects.

    • LockAnchor — prevents anchor paragraph moves from shifting image position
    • Avoid changing Left/Top (PDF coordinates already baked in at convert)
    • Inline shapes: lock aspect ratio only
    • Skip shapes in H/F (protected stories)
    """
    shapes_fixed = 0
    inline_fixed = 0
    skipped = 0
    failed = 0

    n_shapes = safe_com(lambda: doc.Shapes.Count, default=0) or 0
    limit = min(int(n_shapes), _MAX_SHAPES_TOTAL)

    for i in range(1, limit + 1):
        shape = safe_com(lambda idx=i: doc.Shapes(idx), default=None)
        if shape is None:
            failed += 1
            continue

        if _shape_in_header_footer(shape):
            skipped += 1
            continue

        # Do not change Left/Top/RelativePosition — PDF coordinates are fixed at convert.
        wrap = safe_com(lambda s=shape: s.WrapFormat, default=None)
        if wrap is not None and _shape_in_table(shape):
            safe_com(lambda w=wrap: setattr(w, "LayoutInCell", True))

        try:
            shape.LockAnchor = True
            shapes_fixed += 1
        except Exception:
            failed += 1

    story = _main_story_range(doc)
    if story is not None:
        icount = safe_com(lambda: story.InlineShapes.Count, default=0) or 0
        for i in range(1, min(int(icount), _MAX_SHAPES_TOTAL) + 1):
            ish = safe_com(lambda idx=i: story.InlineShapes(idx), default=None)
            if ish is None:
                continue
            safe_com(lambda s=ish: setattr(s, "LockAspectRatio", True))
            inline_fixed += 1

    _log(
        f"  [shapes] floating locked={shapes_fixed}, inline={inline_fixed}, "
        f"skipped_hf={skipped}, failed={failed}"
    )


def _shape_in_header_footer(shape) -> bool:
    """True when anchor lives in header/footer story."""
    anchor = safe_com(lambda s=shape: s.Anchor, default=None)
    if anchor is None:
        return False
    story_type = safe_com(
        lambda: int(anchor.StoryType), default=WD_MAIN_TEXT_STORY)
    # wdMainTextStory = 1; headers 6-8, footers 9-11 (approx)
    return story_type != WD_MAIN_TEXT_STORY


def _shape_in_table(shape) -> bool:
    anchor = safe_com(lambda s=shape: s.Anchor, default=None)
    if anchor is None:
        return False
    return bool(safe_com(
        lambda: anchor.Information(WD_IS_IN_TABLE),
        default=False,
    ))


#  Legacy margin helper (unused by pipeline — kept for tooling)

def _fix_margins(doc, pdf_zones: dict) -> None:
    """Deprecated: margins are set in apply_pdf_zones_to_docx()."""
    if not pdf_zones:
        _log("  [margins] No pdf_zones — skipping.")
        return

    master = pdf_zones.get(1) or next(iter(pdf_zones.values()), {})
    hdr_top_pt = _fval(master, "header_top_pt", 36.0)
    hdr_height_pt = _fval(master, "header_height_pt", 14.0)
    ftr_dist_pt = _fval(master, "footer_dist_from_bottom_pt", 36.0)
    ftr_height_pt = _fval(master, "footer_height_pt", 14.0)

    top_pt = hdr_top_pt + hdr_height_pt
    bottom_pt = ftr_dist_pt + ftr_height_pt
    header_dist_pt = max(hdr_top_pt, 18.0)
    footer_dist_pt = max(ftr_dist_pt, 18.0)

    sections_fixed = 0
    for section in doc.Sections:
        try:
            ps = section.PageSetup
            ps.TopMargin = top_pt
            ps.BottomMargin = bottom_pt
            ps.HeaderDistance = header_dist_pt
            ps.FooterDistance = footer_dist_pt
            sections_fixed += 1
        except Exception as exc:
            _log(f"  [margins] Section skipped: {exc}")

    _log(f"  [margins] {sections_fixed} section(s) updated")


def _fval(zone: dict, key: str, default: float) -> float:
    try:
        val = zone.get(key, default)
        return float(val) if val else default
    except (TypeError, ValueError):
        return default


#  Document open / compatibility

def optimised_open_params(doc_path: str) -> dict:
    """
    Open params that minimise Word repair/reflow on PDF-converted DOCX.

    OpenAndRepair=False avoids rebuilding positioned frames from scratch.
    """
    return {
        "FileName": doc_path,
        "ConfirmConversions": False,
        "AddToRecentFiles": False,
        "OpenAndRepair": False,
        "NoEncodingDialog": True,
        "Revert": False,
        "Format": 0,
    }


def fix_compatibility_flags(doc) -> None:
    """Disable layout-breaking compatibility modes after Open()."""
    flags = (
        (WD_OPTIMIZE_FOR_WORD97, False),
    )
    for flag, value in flags:
        try:
            doc.set_Compatibility(flag, value)
        except AttributeError:
            try:
                doc.Compatibility(flag)
            except Exception:
                pass
        except Exception as exc:
            _log(f"  [compat] flag {flag} (non-fatal): {exc}")
    _log("  [compat] wdOptimizeForWord97 disabled.")
