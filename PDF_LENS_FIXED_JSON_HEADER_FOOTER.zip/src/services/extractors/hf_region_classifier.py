"""
Dynamic header/footer region classifier (pdfplumber geometry + cross-page signals).

Replaces fixed-ratio heuristics (e.g. bottom 15% = footer) with multi-signal scoring,
continuation detection, and cross-page repetition analysis.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Optional

# ── Tunables (probabilistic, not hard zone cuts) ─────────────────────────────
_GAP_CLUSTER_PT: float = 15.0
_CONFIDENCE_THRESHOLD: float = 0.52
_MIN_REPETITION_PAGES: int = 2
_MAX_HF_WORDS: int = 42
_MAX_HF_LINES: int = 6
_BODY_WORD_SOFT: int = 55

_CONTINUATION_END_RE = re.compile(
    r"[,;:\-—]\s*$|"
    r"\b(and|or|the|of|to|for|with|under|in|on|at|by|as|a|an|that|which|who|"
    r"where|when|while|if|but|so|such|these|those|their|its|this|shall|will|"
    r"may|must|should|would|could|being|been|having|including|pursuant)\s*$",
    re.IGNORECASE,
)
_PAGE_NUM_RE = re.compile(
    r"^\s*(page\s*)?(\d{1,4}|[ivxlcdm]+)\s*(of\s*(\d{1,4}|[ivxlcdm]+))?\s*$",
    re.IGNORECASE,
)
_SENTENCE_END_RE = re.compile(r"[.!?][\s\"')\]]*\s*$")

_W_REPETITION = 0.35
_W_POSITION = 0.12
_W_TYPOGRAPHY = 0.15
_W_ALIGNMENT = 0.10
_W_ISOLATION = 0.10
_W_PAGE_NUMBER = 0.10
_W_CONTINUATION = 0.35
_W_BODY_STRUCTURE = 0.40


@dataclass
class TextBlock:
    lines: list[dict]
    text: str
    top_pt: float
    bottom_pt: float
    x0_pt: float
    x1_pt: float
    font_size: float
    line_count: int
    word_count: int
    page_num: int
    region_hint: str  # "top" | "bottom" | "body"


@dataclass
class CrossPageContext:
    """Built once per PDF; shared across page classifiers."""
    total_pages: int = 0
    fingerprint_pages: dict[str, set[int]] = field(default_factory=dict)
    fingerprint_meta: dict[str, dict] = field(default_factory=dict)
    page_tail_text: dict[int, str] = field(default_factory=dict)
    page_head_text: dict[int, str] = field(default_factory=dict)
    median_line_height: float = 12.0
    body_top_band: dict[int, float] = field(default_factory=dict)
    body_bottom_band: dict[int, float] = field(default_factory=dict)


def normalize_fingerprint(text: str, max_len: int = 80) -> str:
    t = re.sub(r"\s+", " ", (text or "").lower().strip())
    t = re.sub(r"[^\w\s]", "", t)
    return t[:max_len]


def build_text_blocks(
    lines: list[dict],
    page_num: int,
    page_height: float,
    gap_threshold: float = _GAP_CLUSTER_PT,
) -> list[TextBlock]:
    """Cluster consecutive lines into blocks separated by vertical gaps."""
    if not lines:
        return []

    blocks: list[TextBlock] = []
    cluster: list[dict] = []

    def _flush() -> None:
        if not cluster:
            return
        text = "\n".join(l["text"] for l in cluster if l.get("text"))
        if not text.strip():
            cluster.clear()
            return
        tops = [float(l["top_pt"]) for l in cluster]
        bots = [float(l["bottom_pt"]) for l in cluster]
        x0s = [float(l.get("x0_pt", 0)) for l in cluster]
        x1s = [float(l.get("x1_pt", 0)) for l in cluster]
        sizes = [float(l.get("font_size", 0)) for l in cluster if l.get("font_size")]
        mid = (min(tops) + max(bots)) / 2.0
        hint = "top" if mid < page_height * 0.38 else (
            "bottom" if mid > page_height * 0.62 else "body"
        )
        blocks.append(TextBlock(
            lines=list(cluster),
            text=text.strip(),
            top_pt=min(tops),
            bottom_pt=max(bots),
            x0_pt=min(x0s) if x0s else 0.0,
            x1_pt=max(x1s) if x1s else 0.0,
            font_size=sum(sizes) / len(sizes) if sizes else 0.0,
            line_count=len(cluster),
            word_count=len(text.split()),
            page_num=page_num,
            region_hint=hint,
        ))
        cluster.clear()

    for i, line in enumerate(lines):
        cluster.append(line)
        if i + 1 < len(lines):
            nxt = lines[i + 1]
            gap = float(nxt["top_pt"]) - float(line["bottom_pt"])
            if gap > gap_threshold:
                _flush()
    _flush()
    return blocks


def detect_sentence_continuation(
    block_text: str,
    prev_tail: str = "",
    next_head: str = "",
) -> float:
    """
    Return continuation penalty 0..1 (higher = more likely body flow, not H/F).
    """
    text = (block_text or "").strip()
    if not text:
        return 0.0

    penalty = 0.0
    words = text.split()

    if _CONTINUATION_END_RE.search(text):
        penalty += 0.45
    if words and not _SENTENCE_END_RE.search(text) and len(words) > 12:
        penalty += 0.25
    if len(words) > _BODY_WORD_SOFT:
        penalty += min(0.35, (len(words) - _BODY_WORD_SOFT) / 80.0)

    prev = (prev_tail or "").strip()
    nxt = (next_head or "").strip()
    if prev and text:
        tail = " ".join(prev.split()[-4:])
        if _CONTINUATION_END_RE.search(tail):
            penalty += 0.35
        if prev[-1:] in ",;:-—" or (
            prev.split() and prev.split()[-1].lower()
            in ("and", "or", "the", "of", "to", "for", "with", "under", "in", "a", "an")
        ):
            penalty += 0.30
    if nxt and nxt[:1].islower():
        penalty += 0.40
    if prev and text and prev[-1].isalnum() and text[0].islower():
        penalty += 0.35

    return min(1.0, penalty)


def analyze_cross_page_repetition(
    all_page_lines: dict[int, list[dict]],
) -> CrossPageContext:
    """Fingerprint blocks on top/bottom bands and count cross-page stability."""
    ctx = CrossPageContext(total_pages=len(all_page_lines))
    all_heights: list[float] = []

    for pn, lines in sorted(all_page_lines.items()):
        if not lines:
            continue
        ph = max(float(l["bottom_pt"]) for l in lines) if lines else 842.0
        ph = max(ph, max(float(l.get("top_pt", 0)) for l in lines) + 1.0)
        for l in lines:
            h = float(l["bottom_pt"]) - float(l["top_pt"])
            if h > 0.5:
                all_heights.append(h)

        blocks = build_text_blocks(lines, pn, ph)
        body_blocks = [b for b in blocks if b.region_hint == "body"]
        if body_blocks:
            ctx.body_top_band[pn] = min(b.top_pt for b in body_blocks)
            ctx.body_bottom_band[pn] = max(b.bottom_pt for b in body_blocks)
        elif blocks:
            mids = [(b.top_pt + b.bottom_pt) / 2 for b in blocks]
            mid = sorted(mids)[len(mids) // 2]
            ctx.body_top_band[pn] = mid - ph * 0.25
            ctx.body_bottom_band[pn] = mid + ph * 0.25

        ctx.page_tail_text[pn] = "\n".join(
            l["text"] for l in lines[-3:] if l.get("text")
        ).strip()
        ctx.page_head_text[pn] = "\n".join(
            l["text"] for l in lines[:3] if l.get("text")
        ).strip()

        for block in blocks:
            if block.region_hint == "body" and block.word_count > _BODY_WORD_SOFT:
                continue
            fp = normalize_fingerprint(block.text)
            if len(fp) < 4:
                continue
            ctx.fingerprint_pages.setdefault(fp, set()).add(pn)
            meta = ctx.fingerprint_meta.setdefault(fp, {
                "positions": [],
                "font_sizes": [],
                "alignments": [],
                "word_counts": [],
            })
            meta["positions"].append((pn, block.top_pt, block.bottom_pt))
            if block.font_size:
                meta["font_sizes"].append(block.font_size)
            meta["word_counts"].append(block.word_count)
            page_w = max(float(l.get("x1_pt", 0)) for l in block.lines) or 595.0
            cx = (block.x0_pt + block.x1_pt) / 2.0
            if page_w > 0:
                rel = cx / page_w
                if rel < 0.35:
                    meta["alignments"].append("left")
                elif rel > 0.65:
                    meta["alignments"].append("right")
                else:
                    meta["alignments"].append("center")

    if all_heights:
        all_heights.sort()
        ctx.median_line_height = all_heights[len(all_heights) // 2]

    return ctx


def _repetition_score(fp: str, ctx: CrossPageContext) -> float:
    pages = ctx.fingerprint_pages.get(fp, set())
    n = len(pages)
    if n < 2:
        return 0.0
    ratio = n / max(ctx.total_pages, 1)
    if n >= max(_MIN_REPETITION_PAGES, int(ctx.total_pages * 0.4)):
        return min(1.0, 0.7 + ratio * 0.3)
    if n >= _MIN_REPETITION_PAGES:
        return min(0.75, 0.35 + ratio * 0.4)
    return 0.15 * n


def _position_score(block: TextBlock, is_header: bool, ctx: CrossPageContext) -> float:
    """Weak signal: relative to inferred body band, not fixed page ratio."""
    pn = block.page_num
    body_top = ctx.body_top_band.get(pn)
    body_bot = ctx.body_bottom_band.get(pn)
    if body_top is None or body_bot is None:
        return 0.25

    if is_header:
        if block.bottom_pt <= body_top + ctx.median_line_height * 2:
            return 0.85
        if block.top_pt < body_top:
            return 0.55
        return 0.1
    else:
        if block.top_pt >= body_bot - ctx.median_line_height * 2:
            return 0.85
        if block.bottom_pt > body_bot:
            return 0.55
        return 0.1


def _typography_score(block: TextBlock) -> float:
    if block.line_count <= 0:
        return 0.0
    score = 0.0
    if block.word_count <= 20:
        score += 0.5
    elif block.word_count <= _MAX_HF_WORDS:
        score += 0.25
    if block.line_count <= 3:
        score += 0.35
    elif block.line_count <= _MAX_HF_LINES:
        score += 0.15
    if block.font_size > 0 and (block.font_size < 9 or block.font_size > 14):
        score += 0.1
    return min(1.0, score)


def _alignment_score(block: TextBlock, fp: str, ctx: CrossPageContext) -> float:
    meta = ctx.fingerprint_meta.get(fp, {})
    aligns = meta.get("alignments") or []
    if not aligns:
        return 0.3
    dominant = max(set(aligns), key=aligns.count)
    if dominant == "center":
        return 0.9
    if dominant == "right":
        return 0.75
    return 0.5


def _isolation_score(block: TextBlock, all_blocks: list[TextBlock]) -> float:
    if not all_blocks:
        return 0.5
    gaps = []
    for other in all_blocks:
        if other is block:
            continue
        if other.bottom_pt < block.top_pt:
            gaps.append(block.top_pt - other.bottom_pt)
        elif other.top_pt > block.bottom_pt:
            gaps.append(other.top_pt - block.bottom_pt)
    if not gaps:
        return 0.4
    return min(1.0, max(gaps) / 30.0)


def _page_number_score(text: str) -> float:
    for line in text.splitlines():
        if _PAGE_NUM_RE.match(line.strip()):
            return 1.0
    if re.search(r"\bpage\b.*\d", text, re.I) and len(text.split()) <= 8:
        return 0.7
    return 0.0


def _body_structure_penalty(block: TextBlock) -> float:
    text = block.text
    words = text.split()
    penalty = 0.0
    if len(words) > _MAX_HF_WORDS:
        penalty += min(0.5, (len(words) - _MAX_HF_WORDS) / 60.0)
    if block.line_count > _MAX_HF_LINES:
        penalty += 0.35
    sentences = re.split(r"[.!?]+", text)
    if len([s for s in sentences if s.strip()]) >= 3:
        penalty += 0.35
    if len(text) > 200 and not _PAGE_NUM_RE.search(text[:80]):
        penalty += 0.25
    return min(1.0, penalty)


def compute_header_footer_score(
    block: TextBlock,
    is_header: bool,
    ctx: CrossPageContext,
    all_blocks: list[TextBlock],
) -> dict[str, Any]:
    fp = normalize_fingerprint(block.text)
    prev_tail = ctx.page_tail_text.get(block.page_num - 1, "")
    next_head = ctx.page_head_text.get(block.page_num + 1, "")

    rep = _repetition_score(fp, ctx)
    pos = _position_score(block, is_header, ctx)
    typo = _typography_score(block)
    align = _alignment_score(block, fp, ctx)
    isol = _isolation_score(block, all_blocks)
    pnum = _page_number_score(block.text)
    cont = detect_sentence_continuation(block.text, prev_tail, next_head)
    body_p = _body_structure_penalty(block)

    raw = (
        rep * _W_REPETITION
        + pos * _W_POSITION
        + typo * _W_TYPOGRAPHY
        + align * _W_ALIGNMENT
        + isol * _W_ISOLATION
        + pnum * _W_PAGE_NUMBER
        - cont * _W_CONTINUATION
        - body_p * _W_BODY_STRUCTURE
    )
    confidence = max(0.0, min(1.0, raw))

    return {
        "confidence": round(confidence, 4),
        "fingerprint": fp,
        "repetition_score": round(rep, 3),
        "position_score": round(pos, 3),
        "continuation_penalty": round(cont, 3),
        "body_structure_penalty": round(body_p, 3),
        "is_header": is_header,
    }


def dynamic_header_boundary(
    blocks: list[TextBlock],
    ctx: CrossPageContext,
    page_height: float,
) -> tuple[list[dict], float]:
    """Pick best header block lines + confidence."""
    candidates = [b for b in blocks if b.region_hint in ("top", "body")]
    best_lines: list[dict] = []
    best_conf = 0.0

    for block in candidates:
        sc = compute_header_footer_score(block, True, ctx, blocks)
        if sc["confidence"] >= _CONFIDENCE_THRESHOLD and sc["confidence"] > best_conf:
            if sc["continuation_penalty"] < 0.55 and sc["body_structure_penalty"] < 0.55:
                best_conf = sc["confidence"]
                best_lines = block.lines

    if not best_lines and candidates:
        for block in sorted(candidates, key=lambda b: b.top_pt):
            sc = compute_header_footer_score(block, True, ctx, blocks)
            if sc["repetition_score"] >= 0.5 and sc["confidence"] > best_conf:
                best_conf = sc["confidence"]
                best_lines = block.lines

    return best_lines, best_conf


def dynamic_footer_boundary(
    blocks: list[TextBlock],
    ctx: CrossPageContext,
    page_height: float,
) -> tuple[list[dict], float]:
    """Pick best footer block lines + confidence."""
    candidates = [b for b in blocks if b.region_hint in ("bottom", "body")]
    best_lines: list[dict] = []
    best_conf = 0.0

    for block in candidates:
        sc = compute_header_footer_score(block, False, ctx, blocks)
        if sc["confidence"] >= _CONFIDENCE_THRESHOLD and sc["confidence"] > best_conf:
            if sc["continuation_penalty"] < 0.55 and sc["body_structure_penalty"] < 0.55:
                best_conf = sc["confidence"]
                best_lines = block.lines

    if not best_lines and candidates:
        for block in sorted(candidates, key=lambda b: -b.bottom_pt):
            sc = compute_header_footer_score(block, False, ctx, blocks)
            if sc["repetition_score"] >= 0.5 and sc["confidence"] > best_conf:
                best_conf = sc["confidence"]
                best_lines = block.lines

    return best_lines, best_conf


def classify_page_regions(
    lines: list[dict],
    page_num: int,
    page_width: float,
    page_height: float,
    ctx: CrossPageContext,
    page_images: Optional[list] = None,
    gap_threshold: float = _GAP_CLUSTER_PT,
) -> dict:
    """
    Classify header/footer for one page using multi-signal scoring.
    Returns same shape as legacy detect_header_footer_dynamic().
    """
    all_blocks = build_text_blocks(lines, page_num, page_height, gap_threshold)
    hdr_lines, hdr_conf = dynamic_header_boundary(all_blocks, ctx, page_height)
    ftr_lines, ftr_conf = dynamic_footer_boundary(all_blocks, ctx, page_height)

    hdr_top, hdr_bot = _bbox_lines(hdr_lines)
    ftr_top, ftr_bot = _bbox_lines(ftr_lines)

    max_zone_height = page_height * 0.22
    if hdr_lines and (hdr_bot - hdr_top) > max_zone_height:
        hdr_lines, hdr_conf = [], 0.0
        hdr_top = hdr_bot = 0.0
    if ftr_lines and (ftr_bot - ftr_top) > max_zone_height:
        ftr_lines, ftr_conf = [], 0.0
        ftr_top = ftr_bot = 0.0

    if hdr_lines and ftr_lines and hdr_bot >= ftr_top:
        if hdr_conf >= ftr_conf:
            ftr_lines, ftr_conf = [], 0.0
            ftr_top = ftr_bot = 0.0
        else:
            hdr_lines, hdr_conf = [], 0.0
            hdr_top = hdr_bot = 0.0

    hdr_img_bnd = hdr_bot if hdr_bot > 0 else page_height * 0.12
    ftr_img_bnd = ftr_top if ftr_top > 0 else page_height * 0.88
    img_zones = _classify_images_simple(
        page_images or [], page_height, hdr_img_bnd, ftr_img_bnd,
    )

    if not hdr_lines and img_zones["header"]:
        hdr_top = min(i["top_pt"] for i in img_zones["header"])
        hdr_bot = max(i["bottom_pt"] for i in img_zones["header"])
    if not ftr_lines and img_zones["footer"]:
        ftr_top = min(i["top_pt"] for i in img_zones["footer"])
        ftr_bot = max(i["bottom_pt"] for i in img_zones["footer"])

    return {
        "header_lines": hdr_lines,
        "footer_lines": ftr_lines,
        "header_block": "\n".join(l["text"] for l in hdr_lines),
        "footer_block": "\n".join(l["text"] for l in ftr_lines),
        "header_images": img_zones["header"],
        "footer_images": img_zones["footer"],
        "header_confidence": round(hdr_conf, 4),
        "footer_confidence": round(ftr_conf, 4),
        "classification_method": "multi_signal",
        "coordinates": {
            "page_width_pt": round(page_width, 3),
            "page_height_pt": round(page_height, 3),
            "header_top_pt": round(hdr_top, 3),
            "header_bottom_pt": round(hdr_bot, 3),
            "header_height_pt": round(hdr_bot - hdr_top, 3) if hdr_lines else 0.0,
            "footer_top_pt": round(ftr_top, 3),
            "footer_bottom_pt": round(ftr_bot, 3),
            "footer_height_pt": round(ftr_bot - ftr_top, 3) if ftr_lines else 0.0,
            "footer_dist_from_bottom_pt": round(page_height - ftr_bot, 3) if ftr_bot else 0.0,
        },
    }


def _bbox_lines(lines: list) -> tuple[float, float]:
    if not lines:
        return 0.0, 0.0
    return (
        min(float(l["top_pt"]) for l in lines),
        max(float(l["bottom_pt"]) for l in lines),
    )


def _classify_images_simple(
    images: list,
    ph: float,
    hdr_boundary: float,
    ftr_boundary: float,
) -> dict:
    hdr_imgs, ftr_imgs = [], []
    for img in images:
        img_top = float(img.get("top", 0))
        img_bottom = float(img.get("bottom", img_top))
        h = img_bottom - img_top
        if h < 4.0:
            continue
        img_mid = (img_top + img_bottom) / 2.0
        record = {
            "top_pt": round(img_top, 3),
            "bottom_pt": round(img_bottom, 3),
            "width_pt": round(float(img.get("width", 0)), 3),
            "height_pt": round(h, 3),
            "name": img.get("name", ""),
        }
        if img_mid <= hdr_boundary:
            hdr_imgs.append(record)
        elif img_mid >= ftr_boundary:
            ftr_imgs.append(record)
    return {"header": hdr_imgs, "footer": ftr_imgs}
