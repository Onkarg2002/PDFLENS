import os
import json
import pdfplumber
from PIL import Image
from src.constants.constant import (
    MATH_UNICODE_RANGES, MATH_FONT_FRAGMENTS,
    FOLDER_EQUATIONS, SUFFIX_EQUATIONS,
)
from src.utils.file_util import ensure_dir
from src.services.extractors.image_extractor import pdf_region_to_pil
from src.services.extractors.extractor_com_safe import log_classified
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.extractors.equation_extractor")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)

#  MATH DETECTION HELPERS

def _count_math_chars(text: str) -> int:
    count = 0
    for ch in text:
        cp = ord(ch)
        for lo, hi in MATH_UNICODE_RANGES:
            if lo <= cp <= hi:
                count += 1; break
    return count


def _is_math_font(fontname: str) -> bool:
    if not fontname: return False
    fn = fontname.lower()
    return any(frag in fn for frag in MATH_FONT_FRAGMENTS)


#  REGION SCANNER

def scan_pdf_for_equation_regions(pdf_path: str,
                                   padding_pt: float = 8.0,
                                   cluster_gap_pt: float = 18.0) -> list:
    regions = []
    try:
        with pdfplumber.open(pdf_path) as pdf:
            for page_idx, page in enumerate(pdf.pages):
                pn = page_idx + 1
                pw = float(page.width)
                ph = float(page.height)

                math_chars = []
                for c in page.chars:
                    fn  = c.get("fontname", "") or ""
                    txt = c.get("text", "")
                    if _is_math_font(fn) or _count_math_chars(txt) > 0:
                        math_chars.append({
                            "x0":     float(c["x0"]), "x1":     float(c["x1"]),
                            "top":    float(c["top"]), "bottom": float(c["bottom"]),
                            "type":   "math_font" if _is_math_font(fn) else "unicode_math",
                        })

                if not math_chars: continue

                math_chars.sort(key=lambda c: c["top"])
                clusters, cur = [], [math_chars[0]]
                for c in math_chars[1:]:
                    if c["top"] - cur[-1]["bottom"] > cluster_gap_pt:
                        clusters.append(cur); cur = [c]
                    else:
                        cur.append(c)
                clusters.append(cur)

                for cl in clusters:
                    x0 = max(0.0, min(c["x0"]    for c in cl) - padding_pt)
                    x1 = min(pw,  max(c["x1"]    for c in cl) + padding_pt)
                    y0 = max(0.0, min(c["top"]   for c in cl) - padding_pt)
                    y1 = min(ph,  max(c["bottom"] for c in cl) + padding_pt)
                    eq_type = ("math_font"
                               if any(c["type"] == "math_font" for c in cl)
                               else "unicode_math")
                    regions.append({
                        "page_number":   pn,
                        "x0": x0, "y0": y0, "x1": x1, "y1": y1,
                        "type":          eq_type,
                        "char_count":    len(cl),
                        "page_width_pt": pw, "page_height_pt": ph,
                    })
    except Exception as e:
        log_classified(e, "scan_pdf_eq")

    _slog(f"  [scan_pdf_eq] Found {len(regions)} equation region(s)")
    return regions


#  IMAGE RENDER + SAVE

def _render_one_equation(args) -> dict:
    """Render a single equation region to a bordered PNG. Used by thread pool."""
    idx, r, eq_folder, pdf_path = args
    eq_num = idx + 1
    fname  = f"equation_{eq_num}.png"
    fpath  = os.path.join(eq_folder, fname)

    img = pdf_region_to_pil(pdf_path, r["page_number"],
                             r["x0"], r["y0"], r["x1"], r["y1"], dpi=220)
    if img is None:
        _slog(f"    [equations] eq {eq_num}: render failed — skipping")
        return {}

    bordered = Image.new("RGB", (img.width + 8, img.height + 8), (255, 255, 255))
    bordered.paste(img, (4, 4))
    bordered.save(fpath, "PNG")
    _slog(f"    [equations] eq {eq_num}: p{r['page_number']} → {fname}")

    return {
        "equation_index": eq_num,
        "type":           r["type"],
        "page_number":    r["page_number"],
        "image_file":     fname,
        "image_folder":   FOLDER_EQUATIONS,
        "pdf_bbox":       {k: r[k] for k in ("x0","y0","x1","y1")},
        "char_count":     r["char_count"],
    }


def extract_equations_as_images(output_folder: str, pdf_path: str) -> list:
    """
    Render each detected equation region as a bordered PNG.
    Returns list of equation metadata dicts.
    PERFORMANCE: rendering is parallelised with ThreadPoolExecutor (4 workers).
    """
    if not pdf_path or not os.path.isfile(pdf_path):
        _slog("  [equations] No pdf_path — skipping.")
        return []

    eq_folder = ensure_dir(os.path.join(output_folder, FOLDER_EQUATIONS))
    _slog("  [equations] Scanning PDF for equation regions …")
    regions = scan_pdf_for_equation_regions(pdf_path)

    if not regions:
        _slog("  [equations] No equation regions found.")
        return []

    # PERFORMANCE: render all equation images in parallel (pure Python / CPU)
    args_list = [(idx, r, eq_folder, pdf_path) for idx, r in enumerate(regions)]
    equations = []

    from concurrent.futures import ThreadPoolExecutor, as_completed
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {pool.submit(_render_one_equation, a): a[0] for a in args_list}
        # collect in original order
        results = {}
        for fut in as_completed(futures):
            orig_idx = futures[fut]
            try:
                results[orig_idx] = fut.result()
            except Exception as e:
                _slog(f"    [equations] eq {orig_idx+1}: thread error — {e}")
                results[orig_idx] = {}

    for idx in range(len(regions)):
        meta = results.get(idx, {})
        if meta:
            equations.append(meta)

    _slog(f"  [equations] Saved {len(equations)} equation image(s).")
    return equations


#  JSON WRITER

def save_equations_json(equations_data: list, output_folder: str,
                         base_name: str) -> str:
    """Write _equations.json. Returns file path."""
    path = os.path.join(output_folder, f"{base_name}{SUFFIX_EQUATIONS}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({
            "total_equations": len(equations_data),
            "equations":       equations_data,
        }, f, indent=2, ensure_ascii=False)
    _slog(f"  [equations] JSON → {os.path.basename(path)}")
    return path

#

























