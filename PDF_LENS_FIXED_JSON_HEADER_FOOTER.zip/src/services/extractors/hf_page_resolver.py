"""
Page ↔ section header/footer resolution and region serialization.

Bridges Step 6.5 semantic extraction (by_section + lookup) to per-page output
and full_analysis.json without re-running COM extraction per page.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Optional

from src.constants.constant import (
    WD_HEADER_FOOTER_EVEN_PAGES,
    WD_HEADER_FOOTER_FIRST_PAGE,
    WD_HEADER_FOOTER_PRIMARY,
)
_HF_TYPE_LABELS: dict[int, str] = {
    WD_HEADER_FOOTER_PRIMARY: "primary",
    WD_HEADER_FOOTER_FIRST_PAGE: "first_page",
    WD_HEADER_FOOTER_EVEN_PAGES: "even_pages",
}

_PAGE_NUM_TEXT_RE = re.compile(
    r"^\s*(\d{1,4}|[ivxlcdm]+)\s*$", re.IGNORECASE,
)
# PDF→DOCX conversions often wrap PAGE fields as ":: 12 ::"
_DECORATIVE_PAGE_NUM_RE = re.compile(
    r"^\s*::\s*(\d{1,4}|[ivxlcdm]+)\s*::\s*$", re.IGNORECASE,
)
_CONFIDENTIAL_RE = re.compile(
    r"\b(confidential|private|draft|internal use only)\b", re.I,
)
_DATE_RE = re.compile(
    r"\b\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4}\b|\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\b",
    re.I,
)


def effective_odd_and_even_pages(
    word_flag: bool,
    *,
    even_stories_detected: bool = False,
) -> bool:
    """
    Effective odd/even mode: Word PageSetup flag OR even-page stories in DOCX.

    Converted/repaired DOCX files often keep even header/footer XML while
    OddAndEvenPagesHeaderFooter remains False.
    """
    return bool(word_flag or even_stories_detected)


def hf_text_has_dynamic_page_number(
    text: str,
    *,
    has_page_field: bool = False,
) -> bool:
    """True when footer/header text is a PAGE field or static page placeholder."""
    if has_page_field:
        return True
    t = (text or "").strip()
    if not t:
        return False
    return bool(
        _DECORATIVE_PAGE_NUM_RE.match(t) or _PAGE_NUM_TEXT_RE.match(t)
    )


def resolve_hf_text_for_page(
    text: str,
    page_num: int,
    *,
    has_page_field: bool = False,
    pdf_zone_text: str = "",
) -> str:
    """
    Per-page header/footer text for JSON export.

    Word COM returns the same unresolved PAGE placeholder on every page
    (e.g. ':: 1 ::'). Prefer PDF zone text when present; otherwise substitute
    the current page number into known placeholder patterns.
    """
    pdf_text = (pdf_zone_text or "").strip()
    if pdf_text:
        return pdf_text
    t = (text or "").strip()
    if not t or not hf_text_has_dynamic_page_number(
        t, has_page_field=has_page_field,
    ):
        return t
    if _DECORATIVE_PAGE_NUM_RE.match(t):
        return f":: {page_num} ::"
    if _PAGE_NUM_TEXT_RE.match(t):
        return str(page_num)
    if has_page_field and re.search(r"\d+", t):
        return re.sub(r"\d+", str(page_num), t, count=1)
    return t


def resolve_hf_type_for_page(
    page_num: int,
    *,
    different_first_page: bool,
    odd_and_even: bool,
    even_stories_detected: bool = False,
) -> int:
    """Word wdHeaderFooter* constant for this page."""
    if page_num == 1 and different_first_page:
        return WD_HEADER_FOOTER_FIRST_PAGE
    use_odd_even = effective_odd_and_even_pages(
        odd_and_even, even_stories_detected=even_stories_detected,
    )
    if use_odd_even and page_num % 2 == 0:
        return WD_HEADER_FOOTER_EVEN_PAGES
    return WD_HEADER_FOOTER_PRIMARY


class HeaderFooterIndex:
    """
    Index over extract_real_section_headers_footers() result.

    Resolves (section_start, hf_type, is_header) with fallbacks via by_section.
    """

    def __init__(self, semantic_result: Optional[dict] = None) -> None:
        semantic_result = semantic_result or {}
        self.lookup: dict = dict(semantic_result.get("lookup") or {})
        self.by_section: dict = dict(semantic_result.get("by_section") or {})
        self.section_start_by_index: dict[int, int] = {}
        self.section_index_by_start: dict[int, int] = {}
        for sec_idx, entry in self.by_section.items():
            try:
                idx = int(sec_idx)
            except (TypeError, ValueError):
                continue
            start = entry.get("section_start")
            if start is not None:
                self.section_start_by_index[idx] = int(start)
                self.section_index_by_start[int(start)] = idx

    def _from_by_section(
        self, sec_start: int, hf_type: int, is_header: bool,
    ) -> Optional[dict]:
        sec_idx = self.section_index_by_start.get(sec_start)
        if sec_idx is None:
            for idx, start in self.section_start_by_index.items():
                if start == sec_start:
                    sec_idx = idx
                    break
        if sec_idx is None:
            return None
        entry = self.by_section.get(sec_idx) or self.by_section.get(str(sec_idx))
        if not entry:
            return None
        bucket = entry.get("headers" if is_header else "footers") or {}
        info = bucket.get(hf_type) or bucket.get(int(hf_type))
        return copy.deepcopy(info) if info else None

    def effective_odd_and_even_for_section(
        self, sec_start: int, word_flag: bool = False,
    ) -> bool:
        """Per-section odd/even: Word flag OR stories detected at extraction."""
        sec_idx = self.section_index_by_start.get(sec_start)
        if sec_idx is None:
            for idx, start in self.section_start_by_index.items():
                if start == sec_start:
                    sec_idx = idx
                    break
        if sec_idx is not None:
            entry = self.by_section.get(sec_idx) or self.by_section.get(str(sec_idx))
            if entry is not None:
                section_flag = entry.get("odd_and_even_effective")
                if section_flag is not None:
                    return bool(section_flag) or bool(word_flag)
        return bool(word_flag)

    def resolve(
        self,
        sec_start: int,
        hf_type: int,
        is_header: bool,
    ) -> Optional[dict]:
        """Resolve header/footer info dict for section + story type."""
        key = (sec_start, hf_type, is_header)
        info = self.lookup.get(key)
        if info is not None:
            return copy.deepcopy(info)
        return self._from_by_section(sec_start, hf_type, is_header)

    def resolve_header_for_page(
        self,
        page_num: int,
        sec_start: int,
        *,
        different_first_page: bool = False,
        odd_and_even: bool = False,
    ) -> Optional[dict]:
        effective = self.effective_odd_and_even_for_section(sec_start, odd_and_even)
        hf_type = resolve_hf_type_for_page(
            page_num,
            different_first_page=different_first_page,
            odd_and_even=effective,
        )
        return self.resolve(sec_start, hf_type, True)

    def resolve_footer_for_page(
        self,
        page_num: int,
        sec_start: int,
        *,
        different_first_page: bool = False,
        odd_and_even: bool = False,
    ) -> Optional[dict]:
        effective = self.effective_odd_and_even_for_section(sec_start, odd_and_even)
        hf_type = resolve_hf_type_for_page(
            page_num,
            different_first_page=different_first_page,
            odd_and_even=effective,
        )
        return self.resolve(sec_start, hf_type, False)


def infer_region_type(info: dict, is_header: bool) -> str:
    """Classify header/footer content into a dynamic region type."""
    text = (info.get("text") or "").strip()
    if info.get("has_page_field"):
        return "page_number"
    if _DECORATIVE_PAGE_NUM_RE.match(text):
        return "page_number"
    if _PAGE_NUM_TEXT_RE.match(text):
        return "page_number"
    if _CONFIDENTIAL_RE.search(text):
        return "confidential_footer" if not is_header else "confidential_header"
    if _DATE_RE.search(text) and len(text.split()) <= 12:
        return "date_footer" if not is_header else "date_header"
    if (info.get("images") or {}).get("count", 0) > 0 and len(text) < 20:
        return "image_header" if is_header else "image_footer"
    if len(text) > 80:
        return "section_header" if is_header else "legal_footer"
    if text:
        return "running_header" if is_header else "running_footer"
    return "empty"


def _region_confidence(info: dict, pdf_zone: Optional[dict], is_header: bool) -> float:
    sem = float(info.get("semantic_confidence") or 0.0)
    vis = float(info.get("visual_confidence") or 0.0)
    if pdf_zone:
        zc = float(
            pdf_zone.get("header_confidence" if is_header else "footer_confidence") or 0.0
        )
        return max(sem, vis, zc)
    return max(sem, vis)


def format_hf_region(
    info: Optional[dict],
    *,
    is_header: bool,
    hf_type: int,
    sec_start: int,
    page_num: int,
    pdf_zone: Optional[dict] = None,
    include_empty: bool = False,
) -> dict:
    """Canonical region object for JSON / API."""
    if not info:
        info = {}
    text = (info.get("text") or "").strip()
    if not text and pdf_zone:
        block = (
            pdf_zone.get("header_block") if is_header else pdf_zone.get("footer_block")
        ) or ""
        if block.strip() and (
            info.get("has_page_field")
            or not (info.get("text") or "").strip()
        ):
            text = block.strip()
            info = dict(info)
            info["text"] = text
            if info.get("extraction_source") in (None, "", "empty"):
                info["extraction_source"] = "pdf_zone_fallback"

    if not text and not include_empty:
        if not (info.get("images") or {}).get("count"):
            return {}

    hf_label = info.get("hf_type_label") or _HF_TYPE_LABELS.get(hf_type, "primary")
    region = {
        "text": text,
        "confidence": round(_region_confidence(info, pdf_zone, is_header), 4),
        "type": infer_region_type(info, is_header),
        "source": info.get("extraction_source", "semantic"),
        "hf_type": hf_label,
        "hf_type_id": hf_type,
        "section_start": sec_start,
        "page_number": page_num,
        "has_page_field": bool(info.get("has_page_field")),
        "semantic_confidence": info.get("semantic_confidence", 0.0),
        "visual_confidence": info.get("visual_confidence", 0.0),
        "used_pdf_fallback": bool(info.get("used_pdf_fallback")),
        "font_sizes": info.get("font_sizes", []),
        "font_names": info.get("font_names", []),
        "word_styles": info.get("word_styles", []),
        "hyperlinks": info.get("hyperlinks", []),
        "images": info.get("images", {"count": 0, "details": []}),
        "tables": info.get("tables", []),
        "table_count": info.get("table_count", 0),
        "shape_text_found": bool(info.get("shape_text_found")),
    }
    if pdf_zone:
        region["pdf_zone"] = {
            "header_block": pdf_zone.get("header_block", ""),
            "footer_block": pdf_zone.get("footer_block", ""),
            "header_confidence": pdf_zone.get("header_confidence", 0.0),
            "footer_confidence": pdf_zone.get("footer_confidence", 0.0),
            "classification_method": pdf_zone.get("classification_method", ""),
        }
    return region


def format_body_region(
    *,
    full_text: str,
    content_lines: list,
    tables_count: int,
    images_in_body: dict,
    hyperlinks: list,
) -> dict:
    return {
        "full_text": full_text,
        "paragraphs": content_lines,
        "tables_count": tables_count,
        "images_count": images_in_body.get("total_count", 0),
        "images": images_in_body,
        "hyperlinks": hyperlinks,
    }


def build_page_regions(
    *,
    page_num: int,
    sec_start: int,
    hf_type: int,
    different_first_page: bool,
    odd_and_even: bool,
    header_info: dict,
    footer_info: dict,
    pdf_zone: Optional[dict],
    extract_header: bool,
    extract_footer: bool,
    body_full_text: str,
    content_lines: list,
    tables_count: int,
    images_in_body: dict,
    hyperlinks: list,
) -> dict:
    """Unified page.regions model for pipeline + full_analysis."""
    regions: dict[str, Any] = {
        "body": format_body_region(
            full_text=body_full_text,
            content_lines=content_lines,
            tables_count=tables_count,
            images_in_body=images_in_body,
            hyperlinks=hyperlinks,
        ),
    }
    if extract_header:
        hdr = format_hf_region(
            header_info,
            is_header=True,
            hf_type=hf_type,
            sec_start=sec_start,
            page_num=page_num,
            pdf_zone=pdf_zone,
            include_empty=bool(
                (header_info.get("images") or {}).get("count")
            ),
        )
        if hdr:
            regions["header"] = hdr
    if extract_footer:
        ftr = format_hf_region(
            footer_info,
            is_header=False,
            hf_type=hf_type,
            sec_start=sec_start,
            page_num=page_num,
            pdf_zone=pdf_zone,
            include_empty=bool(
                (footer_info.get("images") or {}).get("count")
            ),
        )
        if ftr:
            regions["footer"] = ftr
    return regions


def region_display_text(region: Optional[dict]) -> str:
    """Flat text for backward-compatible header_text/footer_text fields."""
    if not region:
        return ""
    return (region.get("text") or "").strip()
