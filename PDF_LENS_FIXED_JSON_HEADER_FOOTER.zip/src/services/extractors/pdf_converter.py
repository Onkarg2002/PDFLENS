import os
import threading
import time
import win32com.client
import win32gui
import win32con
from src.constants.constant import WD_PERMISSION_ERROR, WD_CORRUPTED_ERROR
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.extractors.pdf_converter")

# ── One-shot registry fix: suppress "Word will now convert your PDF…" popup ──
# DontWarnPDFToWord=1 under HKCU\SOFTWARE\Microsoft\Office\<ver>\Word\Options
# is the ONLY permanent suppression.  DisplayAlerts=0 does NOT suppress it
# because it fires from Word's PDF-reflow engine, not the COM alert framework.
def _suppress_pdf_reflow_dialog_once() -> None:
    """Write DontWarnPDFToWord=1 into every installed Office version key."""
    import sys
    try:
        import winreg
        hive   = winreg.HKEY_CURRENT_USER
        base   = r"SOFTWARE\Microsoft\Office"
        subkey = r"Word\Options"
        for ver in ("16.0", "15.0", "14.0"):
            path = rf"{base}\{ver}\{subkey}"
            try:
                with winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE) as k:
                    winreg.SetValueEx(k, "DontWarnPDFToWord", 0, winreg.REG_DWORD, 1)
            except Exception:
                pass
    except Exception as exc:
        import sys as _sys
        print(f"[pdf_converter] WARN: could not write DontWarnPDFToWord: {exc}",
              file=_sys.stderr)

_suppress_pdf_reflow_dialog_once()


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)


#  DIALOG AUTO-DISMISS
def auto_dismiss_word_dialogs(stop_event: threading.Event,
                               interval: float = 0.05) -> None:
    """
    Background thread: scans for any visible Microsoft Word modal dialog
    and auto-dismisses it.  Interval reduced to 50ms for faster response.

    Catches dialogs by BOTH title AND window class so it works on all
    Office versions including Office 365 (NUIDialog / NetUIHWND classes).
    """
    # Titles that identify a Word dialog (lowercase, substring match)
    _TITLE_FRAGMENTS = (
        "microsoft word", "word",
    )
    # Win32 window classes used by Word dialogs across Office versions
    _DIALOG_CLASSES = {
        "#32770",       # standard Win32 dialog (Office 2010–2016)
        "nuidialog",    # Office 365 / 2019 / 2021 modern dialog
        "netuilwnd",
        "msocommandbar",
    }

    def _click_button_by_text(parent_hwnd, want_texts):
        found = []
        def _cb(hwnd, _):
            if "button" not in win32gui.GetClassName(hwnd).lower():
                return True
            txt = win32gui.GetWindowText(hwnd).strip().lower().replace("&", "")
            for w in want_texts:
                if w in txt:
                    found.append(hwnd)
                    return False
            return True
        try:
            win32gui.EnumChildWindows(parent_hwnd, _cb, None)
        except Exception:
            pass
        if found:
            try:
                win32gui.SendMessage(found[0], win32con.BM_CLICK, 0, 0)
            except Exception:
                pass
            return True
        return False

    def _is_word_dialog(hwnd):
        if not win32gui.IsWindowVisible(hwnd):
            return False
        title = win32gui.GetWindowText(hwnd).strip().lower()
        cls   = win32gui.GetClassName(hwnd).strip().lower()
        # Match by class name (catches NUIDialog on Office 365)
        if cls in _DIALOG_CLASSES:
            return True
        # Match by title fragment
        if any(frag in title for frag in _TITLE_FRAGMENTS):
            return True
        return False

    def _dismiss(hwnd, _):
        try:
            if not _is_word_dialog(hwnd):
                return True

            # Priority 1 – "Want to save?" → Don't Save  (must come before OK)
            if _click_button_by_text(hwnd, ["don't save", "dont save"]):
                _slog("  [dismiss] Auto-clicked 'Don't Save'")
                return True

            # Priority 2 – Any OK-only dialog (covers PDF reflow info popup)
            if _click_button_by_text(hwnd, ["ok"]):
                _slog("  [dismiss] Auto-clicked 'OK'")
                return True

            # Priority 3 – Overwrite / confirm prompts → Yes
            if _click_button_by_text(hwnd, ["yes"]):
                _slog("  [dismiss] Auto-clicked 'Yes'")
                return True

            # Last resort: send Enter key to the dialog
            win32gui.PostMessage(hwnd, win32con.WM_KEYDOWN, win32con.VK_RETURN, 0)
            win32gui.PostMessage(hwnd, win32con.WM_KEYUP,   win32con.VK_RETURN, 0)
        except Exception:
            pass
        return True

    while not stop_event.is_set():
        try:
            win32gui.EnumWindows(_dismiss, None)
        except Exception:
            pass
        stop_event.wait(interval)


#  PDF PERMISSIONS STRIP

def _strip_pdf_permissions(pdf_path: str) -> str:
    try:
        import pikepdf
    except ImportError:
        _slog("  [unlock] pikepdf not installed")
        return pdf_path
    base, ext     = os.path.splitext(pdf_path)
    unlocked_path = base + "_unlocked" + ext
    try:
        with pikepdf.open(pdf_path, allow_overwriting_input=False) as pdf:
            pdf.save(unlocked_path, encryption=False)
        _slog(f"  [unlock] → {unlocked_path}")
        return unlocked_path
    except Exception as e:
        _slog(f"  [unlock] {e}")
        return pdf_path


#  CONVERSION

def convert_pdf_to_docx(pdf_path: str, output_docx_path: str) -> str:
    """
    Convert a PDF to DOCX using Word COM automation.
    • Pre-deletes any existing output file so Word never shows the overwrite dialog.
    • Sets DisplayAlerts=0 and OverwritePrompt=False on SaveAs.
    • Background dismiss thread handles any remaining modal dialogs:
        - "Want to save?" → Don't Save
        - "Cannot close Word…" → OK
    • Handles permission-restricted PDFs via pikepdf unlock.
    """
    pdf_path         = os.path.abspath(pdf_path)
    output_docx_path = os.path.abspath(output_docx_path)

    def _open_and_save(src: str, open_and_repair: bool = False) -> str:
        src = os.path.abspath(src)

        # Remove pre-existing output so Word never prompts to overwrite
        if os.path.isfile(output_docx_path):
            try:
                os.remove(output_docx_path)
            except OSError as e:
                _slog(f"  [convert] Could not pre-delete output file: {e}")

        word = win32com.client.DispatchEx("Word.Application")
        word.Visible       = False
        word.DisplayAlerts = 0   # wdAlertsNone – suppresses all built-in alerts
        word.ScreenUpdating = False

        # ── Nuclear PDF-reflow popup suppression (3 layers) ──────────────────
        # Layer 1: registry (already written at module load by
        #          _suppress_pdf_reflow_dialog_once above).
        # Layer 2: COM Options — set BEFORE Documents.Open so Word's reflow
        #          engine reads them during the open call.
        #          DoNotPromptForConvert is the direct COM equivalent of the
        #          DontWarnPDFToWord registry key and works even when the
        #          registry write was blocked by permissions.
        for _opt, _val in (
            ("DoNotPromptForConvert",              True),   # suppress PDF reflow dialog
            ("ConfirmConversions",                 False),  # no format-conversion prompts
            ("CheckSpellingAsYouType",             False),
            ("CheckGrammarAsYouType",              False),
            ("AutoFormatAsYouTypeApplyHeadings",   False),
            ("AutoFormatAsYouTypeApplyBullets",    False),
            ("Pagination",                         False),
        ):
            try:
                setattr(word.Options, _opt, _val)
            except Exception:
                pass
        # ─────────────────────────────────────────────────────────────────────

        # Dismiss thread covers full open → SaveAs → Close lifetime
        # (Layer 3 fallback — clicks OK if the popup somehow still appears)
        stop_evt       = threading.Event()
        dismiss_thread = threading.Thread(
            target=auto_dismiss_word_dialogs,
            args=(stop_evt,),
            daemon=True,
        )
        dismiss_thread.start()

        try:
            doc = word.Documents.Open(
                FileName           = src,
                ConfirmConversions = False,
                AddToRecentFiles   = False,
                OpenAndRepair      = open_and_repair,
                NoEncodingDialog   = True,
                Revert             = False,
                Format             = 0,       # wdOpenFormatAuto
            )

            # Save as DOCX. Pre-deletion above ensures no overwrite prompt.
            # Use positional args only — COM SaveAs2 doesn't accept keyword args.
            doc.SaveAs2(output_docx_path, 16)  # 16 = wdFormatDocumentDefault

            # Close without saving (file was just written above)
            _close_doc_safely(doc)

        finally:
            stop_evt.set()
            dismiss_thread.join(timeout=3)
            try:
                word.Quit()
            except Exception:
                pass

        return output_docx_path

    def _is_permission_error(exc: Exception) -> bool:
        return (
            (hasattr(exc, "excepinfo") and exc.excepinfo and
             len(exc.excepinfo) > 5 and exc.excepinfo[5] == WD_PERMISSION_ERROR)    
            or "permissions" in str(exc).lower()
            or str(WD_PERMISSION_ERROR) in str(exc)
        )

    def _is_corrupted_error(exc: Exception) -> bool:
        return (
            (hasattr(exc, "excepinfo") and exc.excepinfo and
             len(exc.excepinfo) > 0 and exc.excepinfo[0] == WD_CORRUPTED_ERROR)
            or str(WD_CORRUPTED_ERROR) in str(exc)
            or "corrupted" in str(exc).lower()
            or "corrupt" in str(exc).lower()
        )

    # --- First attempt: normal open ---
    try:
        return _open_and_save(pdf_path, open_and_repair=False)
    except Exception as exc:
        if _is_corrupted_error(exc):
            _slog("  [convert] Word flagged file as corrupted — retrying with OpenAndRepair=True …")
            try:
                return _open_and_save(pdf_path, open_and_repair=True)
            except Exception as exc2:
                if not _is_permission_error(exc2):
                    raise
                # corrupted AND permission-locked: fall through to unlock
                exc = exc2

        if not _is_permission_error(exc):
            raise

    # --- Permission-restricted PDF: strip permissions and retry ---
    _slog("  [convert] Permission-restricted PDF — unlocking …")
    unlocked = _strip_pdf_permissions(pdf_path)
    if unlocked == pdf_path:
        raise RuntimeError("Could not remove PDF permissions.")
    try:
        return _open_and_save(unlocked, open_and_repair=False)
    except Exception as exc:
        if _is_corrupted_error(exc):
            _slog("  [convert] Unlocked PDF also flagged corrupted — retrying with OpenAndRepair=True …")
            return _open_and_save(unlocked, open_and_repair=True)
        raise
    finally:
        try:
            if os.path.isfile(unlocked):
                os.remove(unlocked)
        except Exception: 
            pass


def _close_doc_safely(doc, max_retries: int = 6) -> None:
    """
    Attempt doc.Close(SaveChanges=0) with retries for RPC_E_CALL_REJECTED.
    If Word is blocked by a nested dialog the dismiss thread will clear it
    and the next retry will succeed.
    """
    for attempt in range(max_retries):
        try:
            doc.Close(SaveChanges=0)
            return
        except Exception as exc:
            err = str(exc).lower()
            if attempt < max_retries - 1 and any(
                kw in err for kw in ("rejected", "callee", "-2147418111")
            ):
                _slog(f"  [close] Word busy, retry {attempt + 1}/{max_retries - 1} …")
                time.sleep(1.0)
            else:
                _slog(f"  [close] doc.Close failed (ignored): {exc}")
                return