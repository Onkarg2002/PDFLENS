import os
import json
import zipfile
import xml.etree.ElementTree as etree
from src.services.extractors.extractor_com_safe import (log_classified,normalize_word_text,)
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.extractors.footnote_extractor")

#logger fun
def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)

_WD_NAMESPACE = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
_RESERVED_IDS = {"-1", "0"}
_NS = {'w': _WD_NAMESPACE}

# lastRenderedPageBreak lives in the same W namespace
_LRPB_TAG = f'{{{_WD_NAMESPACE}}}lastRenderedPageBreak'


def _build_para_page_map(body) -> dict[int, int]:
    """
    Walk every w:p in the body and build a dict: para_index → page_number.

    Word embeds a <w:lastRenderedPageBreak> element inside the first run of the
    first paragraph that starts on a new page.  When we encounter one, we
    increment the page counter BEFORE recording that paragraph's page number,
    because the paragraph itself belongs to the NEW page.

    Page numbering starts at 1.
    """
    para_page: dict[int, int] = {}
    current_page = 1

    for i, para in enumerate(body.findall('w:p', _NS)):
        # Check whether this paragraph carries a lastRenderedPageBreak
        if para.findall(f'.//{_LRPB_TAG}'):
            current_page += 1
        para_page[i] = current_page

    return para_page


def _parse_document_xml(archive) -> tuple[dict[str, int], dict[str, int]]:
    """
    Parse word/document.xml and return two dicts:
      ref_page_map  – footnote_id → page_number  (resolved via lastRenderedPageBreak)
      ref_order_map – footnote_id → para_index   (reading order, used as sort key)
    """
    ref_page_map:  dict[str, int] = {}
    ref_order_map: dict[str, int] = {}

    if 'word/document.xml' not in archive.namelist():
        return ref_page_map, ref_order_map

    try:
        with archive.open('word/document.xml') as f:
            doc_root = etree.parse(f).getroot()

        body = doc_root.find('.//w:body', _NS)
        if body is None:
            return ref_page_map, ref_order_map

        para_page = _build_para_page_map(body)

        for i, para in enumerate(body.findall('w:p', _NS)):
            for ref in para.findall('.//w:footnoteReference', _NS):
                fid = ref.attrib.get(f'{{{_WD_NAMESPACE}}}id', '')
                if fid and fid not in _RESERVED_IDS and fid not in ref_page_map:
                    ref_page_map[fid]  = para_page.get(i, 1)
                    ref_order_map[fid] = i

    except Exception as exc:
        _slog(f"[footnote_extractor] document.xml parse error: {exc}")

    return ref_page_map, ref_order_map


def extract_footnotes_from_docx_xml(doc_path: str) -> list[dict]:
    """
    Extract footnotes from a DOCX file.

    Reads word/footnotes.xml for the text of each footnote and
    word/document.xml (via lastRenderedPageBreak markers) to determine the
    exact page number where each footnote reference appears.

    Returns a list of dicts:
      {
        "footnote_index":  int,   # 1-based, sorted by reading order
        "page_number":     int,   # resolved from lastRenderedPageBreak
        "reference_text":  str,   # the footnote marker id (e.g. "1", "2")
        "doc_para_index":  int,   # paragraph index in document.xml (sort key)
        "text":            str,   # full footnote text
      }
    """
    footnotes_map: dict[str, str] = {}
    ref_page_map:  dict[str, int] = {}
    ref_order_map: dict[str, int] = {}

    try:
        with zipfile.ZipFile(doc_path, 'r') as archive:
            if 'word/footnotes.xml' not in archive.namelist():
                _slog("[footnote_extractor] word/footnotes.xml not found")
                return []

            # --- collect footnote texts ---
            with archive.open('word/footnotes.xml') as f:
                fn_root = etree.parse(f).getroot()

            for footnote in fn_root.findall('w:footnote', _NS):
                fid = footnote.attrib.get(f'{{{_WD_NAMESPACE}}}id', '')
                if fid in _RESERVED_IDS:
                    continue
                text = normalize_word_text(''.join(
                    t.text for t in footnote.findall('.//w:t', _NS)
                    if t.text
                ))
                if text:
                    footnotes_map[fid] = text

            # --- resolve page numbers directly from document.xml ---
            ref_page_map, ref_order_map = _parse_document_xml(archive)

    except Exception as exc:
        log_classified(exc, "footnote_xml")
        return []

    def sort_key(fid: str) -> tuple:
        # Sort by paragraph position (reading order), then numeric id
        para_pos = ref_order_map.get(fid, 999999)
        try:
            return (para_pos, int(fid))
        except ValueError:
            return (para_pos, 0)

    result = []
    for i, (fid, txt) in enumerate(
        sorted(footnotes_map.items(), key=lambda kv: sort_key(kv[0])), 1
    ):
        result.append({
            "footnote_index": i,
            "page_number":    ref_page_map.get(fid, 0),  # 0 = unresolved
            "reference_text": fid,
            "doc_para_index": ref_order_map.get(fid, -1),
            "text":           txt,
        })

    return result


def extract_footnotes_from_doc(doc_path: str) -> list[dict]:
    if doc_path and os.path.isfile(doc_path):
        return extract_footnotes_from_docx_xml(doc_path)
    _slog("[footnote_extractor] Invalid DOCX path")
    return []


def save_footnotes_json(data: list, output_folder: str, base_name: str) -> str:
    """
    Save a standalone page-wise footnotes JSON file.

    Output structure:
    {
      "total_footnotes": N,
      "pages": [
        {
          "page_number": 4,
          "footnotes": [
            {"footnote_index": 1, "marker": "1", "text": "..."}
          ]
        },
        ...
      ]
    }
    """
    pages_map: dict[int, list] = {}
    for fn in data:
        pn = fn.get("page_number", 0)
        pages_map.setdefault(pn, []).append({
            "footnote_index": fn.get("footnote_index"),
            "marker":         fn.get("reference_text", ""),
            "text":           fn.get("text", ""),
        })

    pages_out = [
        {"page_number": pn, "footnotes": fns}
        for pn, fns in sorted(pages_map.items())
    ]

    path = os.path.join(output_folder, f"{base_name}_footnotes.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({
            "total_footn"
            "otes": len(data),
            "pages": pages_out,
        }, f, indent=2, ensure_ascii=False)

    return path