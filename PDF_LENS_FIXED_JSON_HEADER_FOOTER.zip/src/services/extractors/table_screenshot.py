from __future__ import annotations
import gc
import os
import tempfile
import threading
from typing import Optional
import fitz
from PIL import Image

from src.utils.file_util import safe_com, ensure_dir
from src.services.extractors.extractor_com_safe import (
    extraction_scope,
    log_classified,
    release_com_refs,
)
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.extractors.table_screenshot")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)


# tunables
_DPI_NORMAL    = 180   
_DPI_LARGE     = 150   
_LARGE_ROW_THR = 20   
_BORDER_PX     = 10    
_STACK_GAP     = 2  
_GC_PIXEL_THRESHOLD = 4_000_000  

# Word COM constants
_WD_EXPORT_FORMAT_PDF       = 17
_WD_EXPORT_OPTIMIZE_PRINT   = 0
_WD_EXPORT_DOCUMENT_CONTENT = 7
_WD_EXPORT_NO_BOOKMARKS     = 0

# shared temp-file slot
_TEMP_PDF_LOCK = threading.Lock()
_TEMP_PDF_PATH: Optional[str] = None


def _get_temp_pdf_path() -> str:
    """Return the shared temp PDF path, creating it once if needed."""
    global _TEMP_PDF_PATH
    with _TEMP_PDF_LOCK:
        if _TEMP_PDF_PATH is None or not os.path.isdir(
                os.path.dirname(_TEMP_PDF_PATH) or "."):
            fd, path = tempfile.mkstemp(suffix=".pdf", prefix="tbl_export_")
            os.close(fd)
            _TEMP_PDF_PATH = path
        return _TEMP_PDF_PATH


def close_pdf_cache() -> None:
    """Remove the shared temp PDF if present (pipeline teardown)."""
    global _TEMP_PDF_PATH
    with _TEMP_PDF_LOCK:
        if _TEMP_PDF_PATH and os.path.isfile(_TEMP_PDF_PATH):
            try:
                os.remove(_TEMP_PDF_PATH)
            except Exception:
                pass
        _TEMP_PDF_PATH = None


# CORE: export table range → temp PDF → render → PIL Image

def _export_range_to_pdf(table_range, temp_pdf_path: str) -> bool:
    """
    Export the table's Range to a temporary PDF using ExportAsFixedFormat2.
    Falls back to ExportAsFixedFormat (Word 2007) if needed.
    """
    try:
        table_range.ExportAsFixedFormat2(
            OutputFileName     = temp_pdf_path,
            ExportFormat       = _WD_EXPORT_FORMAT_PDF,
            OpenAfterExport    = False,
            OptimizeFor        = _WD_EXPORT_OPTIMIZE_PRINT,
            ExportCurrentPage  = False,
            Item               = _WD_EXPORT_DOCUMENT_CONTENT,
            IncludeDocProps    = False,
            KeepIRM            = False,
            CreateBookmarks    = _WD_EXPORT_NO_BOOKMARKS,
            DocStructureTags   = False,
            BitmapMissingFonts = True,
            UseISO19005_1      = False,
        )
        return True
    except Exception as e1:
        _slog(f"      [export] ExportAsFixedFormat2 failed: {e1}")
        try:
            table_range.ExportAsFixedFormat(
                OutputFileName     = temp_pdf_path,
                ExportFormat       = _WD_EXPORT_FORMAT_PDF,
                OpenAfterExport    = False,
                OptimizeFor        = _WD_EXPORT_OPTIMIZE_PRINT,
                Item               = _WD_EXPORT_DOCUMENT_CONTENT,
                IncludeDocProps    = False,
                KeepIRM            = False,
                CreateBookmarks    = _WD_EXPORT_NO_BOOKMARKS,
                DocStructureTags   = False,
                BitmapMissingFonts = True,
                UseISO19005_1      = False,
            )
            return True
        except Exception as e2:
            _slog(f"      [export] fallback also failed: {e2}")
            return False


def _read_table_coords(table_obj) -> tuple[dict, object]:
    """
    One COM round-trip for rows/cols/range bounds/page (when possible).
    Returns (coords_dict, tbl_range).
    """
    coords: dict = {}
    tbl_range = None
    packed = safe_com(
        lambda t=table_obj: (
            int(t.Rows.Count),
            int(t.Columns.Count),
            int(t.Range.Start),
            int(t.Range.End),
            int(t.Range.Information(3)),
        ),
        default=None,
    )
    if packed:
        rows, cols, start, end, page = packed
        coords["rows"]           = rows
        coords["columns"]        = cols
        coords["start_char_pos"] = start
        coords["end_char_pos"]   = end
        coords["start_page"]     = page
        tbl_range = table_obj.Range
    else:
        try:
            tbl_range = table_obj.Range
            coords["rows"]    = safe_com(lambda: table_obj.Rows.Count,    default=0)
            coords["columns"] = safe_com(lambda: table_obj.Columns.Count, default=0)
            coords["start_char_pos"] = safe_com(lambda r=tbl_range: r.Start, default=0)
            coords["end_char_pos"]   = safe_com(lambda r=tbl_range: r.End,   default=0)
            coords["start_page"]     = safe_com(
                lambda r=tbl_range: int(r.Information(3)), default=0)
        except Exception:
            tbl_range = safe_com(lambda: table_obj.Range)
    return coords, tbl_range


def _render_fitz_doc_to_image(fitz_doc: fitz.Document, dpi: int) -> Optional[Image.Image]:
    """
    Rasterise an open fitz document and stack pages vertically.

    Multi-page tables paste one page at a time and close each page PIL image
    immediately to cap peak memory (no list of full-page bitmaps).
    """
    n_pages = len(fitz_doc)
    if n_pages == 0:
        _slog("      [render] exported PDF has 0 pages")
        return None

    mat = fitz.Matrix(dpi / 72.0, dpi / 72.0)

    if n_pages == 1:
        page = fitz_doc[0]
        try:
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            return img
        finally:
            pix = None

    # Multi-page: measure, allocate canvas, render incrementally
    sizes: list[tuple[int, int]] = []
    for idx in range(n_pages):
        page = fitz_doc[idx]
        rect = page.rect
        w = max(1, int(rect.width * dpi / 72.0))
        h = max(1, int(rect.height * dpi / 72.0))
        sizes.append((w, h))

    max_w   = max(w for w, _ in sizes)
    total_h = sum(h for _, h in sizes) + _STACK_GAP * (n_pages - 1)
    canvas  = Image.new("RGB", (max_w, total_h), (255, 255, 255))
    y       = 0

    for idx in range(n_pages):
        page = fitz_doc[idx]
        pix  = None
        img  = None
        try:
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            canvas.paste(img, ((max_w - img.width) // 2, y))
            y += img.height + _STACK_GAP
        finally:
            if img is not None:
                try:
                    img.close()
                except Exception:
                    pass
            pix = None

    return canvas


def _open_render_pdf(
    pdf_path: str,
    row_count: int,
    dpi_hint: int,
) -> tuple[Optional[Image.Image], int, int]:
    """
    Single fitz open: page count → adaptive DPI → one render pass.
    Returns (image, page_count, dpi_used).
    """
    try:
        with fitz.open(pdf_path) as fitz_doc:
            n_pages      = len(fitz_doc)
            effective_dpi = _choose_dpi(row_count, n_pages, dpi_hint)
            img          = _render_fitz_doc_to_image(fitz_doc, effective_dpi)
            return img, n_pages, effective_dpi
    except Exception as e:
        _slog(f"      [render] PDF render failed: {e}")
        return None, 0, dpi_hint or _DPI_NORMAL


def _add_border(img: Image.Image, px: int = _BORDER_PX) -> Image.Image:
    out = Image.new(
        "RGB",
        (img.width + px * 2, img.height + px * 2),
        (255, 255, 255),
    )
    out.paste(img, (px, px))
    return out


def _choose_dpi(row_count: int, n_pdf_pages: int, dpi_hint: int) -> int:
    """Adaptive DPI capped by caller hint (never exceeds hint)."""
    adaptive = _DPI_LARGE if (row_count > _LARGE_ROW_THR or n_pdf_pages > 1) else _DPI_NORMAL
    if dpi_hint > 0:
        return min(dpi_hint, adaptive)
    return adaptive


def _maybe_collect_pixels(pixel_count: int) -> None:
    """Run gc only after large bitmap work."""
    if pixel_count >= _GC_PIXEL_THRESHOLD:
        gc.collect(0)



# PUBLIC API
def capture_table_screenshot(
    pdf_path:          str,           
    table_obj,
    section_page_setup,               
    pdf_zones:         dict,          
    output_folder:     str,
    table_index:       int,
    dpi:               int = _DPI_NORMAL,
    word_total_pages:  int = 0,       
) -> tuple[Optional[str], dict]:
    """
    Capture an exact screenshot of a Word table using ExportAsFixedFormat2.

    Exports the table's Range to a shared temp PDF (Word renders it exactly),
    then rasterises every page of that PDF and stacks them into one PNG.
    """
    ensure_dir(output_folder)

    coords, tbl_range = _read_table_coords(table_obj)
    row_count = int(coords.get("rows") or 0)

    _slog(f"    [t{table_index}] ExportAsFixedFormat2 → temp PDF …")

    tmp_pdf = _get_temp_pdf_path()
    img: Optional[Image.Image] = None
    final: Optional[Image.Image] = None

    with extraction_scope(f"table_screenshot_{table_index}"):
        try:
            ok = _export_range_to_pdf(tbl_range, tmp_pdf)

            if not ok or not os.path.isfile(tmp_pdf) or os.path.getsize(tmp_pdf) == 0:
                _slog(f"    [t{table_index}] export failed or produced empty PDF")
                return None, coords

            pdf_size = os.path.getsize(tmp_pdf)
            _slog(f"    [t{table_index}] temp PDF: {pdf_size:,} bytes")

            img, n_pages, effective_dpi = _open_render_pdf(
                tmp_pdf, row_count, dpi)
            if img is None:
                _slog(f"    [t{table_index}] render failed")
                return None, coords

            _slog(f"    [t{table_index}] rows={row_count} pages={n_pages} "
                  f"→ DPI={effective_dpi}")

            final = _add_border(img)
            try:
                img.close()
            except Exception:
                pass
            img = None

            fname = f"doc_ai_table_id_{table_index}.png"
            fpath = os.path.join(output_folder, fname)
            final.save(fpath, "PNG")

            pixel_count = final.width * final.height
            coords["screenshot_size_px"] = [final.width, final.height]
            coords["method"]             = "ExportAsFixedFormat2"
            coords["dpi_used"]           = effective_dpi

            _slog(f"    [t{table_index}] ✓ saved → {fname} "
                  f"({final.width}×{final.height}px @ {effective_dpi} DPI)")

            try:
                final.close()
            except Exception:
                pass
            final = None

            _maybe_collect_pixels(pixel_count)

            return fname, coords

        except Exception as exc:
            log_classified(exc, f"table_screenshot_{table_index}")
            return None, coords
        finally:
            for _img in (img, final):
                if _img is not None:
                    try:
                        _img.close()
                    except Exception:
                        pass
            release_com_refs(tbl_range)
            del img, final
