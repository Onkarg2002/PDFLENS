from __future__ import annotations

import json
import os
import re
from src.utils.file_util import safe_com
from src.services.extractors.extractor_com_safe import (
    extraction_scope,
    iter_com_collection,
    log_classified,
    normalize_word_text,
)

_MAX_HYPERLINKS_PER_RANGE = 2000



def _clean_text(raw: str, url: str) -> str:
    """
    Remove raw URL strings that Word injects as run display text,
    strip surrounding stray punctuation, normalise whitespace.
    """
    cleaned = raw.replace(url, "")
    cleaned = re.sub(r'https?://\S+', '', cleaned)
    cleaned = re.sub(r'^[\s()\[\]]+|[\s()\[\]]+$', '', cleaned)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    return normalize_word_text(cleaned, max_len=50_000)


# Range-level extraction

def extract_hyperlinks_from_range(
    rng,
    page_number:   int = 0,
    start_counter: int = 1,
) -> tuple[list[dict], int]:
    """
    Extract hyperlinks from a COM Range, merging split runs into one record
    per unique URL, and assign a unique <doc_ai_hyperlink_N> tag to each.

    Returns (records, next_counter).
    """
    counter = start_counter
    raw: list[tuple[str, str, str]] = []

    with extraction_scope(f"hyperlinks_p{page_number}"):
        try:
            hl_coll = rng.Hyperlinks
        except Exception as exc:
            log_classified(exc, "Hyperlinks")
            return [], counter

        for hl in iter_com_collection(
                hl_coll,
                max_items=_MAX_HYPERLINKS_PER_RANGE,
                label="Hyperlinks",
        ):
            try:
                display = normalize_word_text(
                    safe_com(lambda h=hl: h.TextToDisplay, default=""), max_len=10_000)
                url = normalize_word_text(
                    safe_com(lambda h=hl: h.Address, default=""), max_len=10_000)
                sub = normalize_word_text(
                    safe_com(lambda h=hl: h.SubAddress, default=""), max_len=10_000)
            except Exception as exc:
                log_classified(exc, "hyperlink_item")
                continue
            if not url and not display:
                continue
            raw.append((url, sub, display))

    # Step 2: merge consecutive runs with the same URL
    merged: list[dict] = []
    for url, sub, run_text in raw:
        if (
            merged
            and merged[-1]["url"] == url
            and merged[-1]["sub_address"] == sub
        ):
            merged[-1]["parts"].append(run_text)
        else:
            merged.append({"url": url, "sub_address": sub, "parts": [run_text]})

    # Step 3: build clean display text and assign tags 
    records: list[dict] = []
    for entry in merged:
        url = entry["url"]
        sub = entry["sub_address"]
        joined  = " ".join(entry["parts"])
        display = _clean_text(joined, url)
        if not display:
            display = url

        tag_id  = f"doc_ai_hyperlink_{counter}"
        tag_str = f"<{tag_id}>"

        records.append({
            "id":          tag_id,
            "tag":         tag_str,
            "text":        display,
            "url":         url,
            "sub_address": sub,
            "page":        page_number,
        })
        counter += 1

    return records, counter
