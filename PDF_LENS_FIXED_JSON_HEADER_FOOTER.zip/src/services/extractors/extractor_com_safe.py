#Safety Middleware Between Word COM and Extractors
from __future__ import annotations


import gc
import logging
import re
from enum import Enum

from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any, Callable, Generator, Optional
from src.utils.file_util import safe_com, _is_com_busy
from src.utils.structured_log import get_logger, log_event

MSO_GROUP = 6

_STALE_TOKENS = (
    "800706ba", "80010001", "8001000c", "80010005",
    "rpc_e_", "server is unavailable", "disconnected",
    "callee", "call was rejected", "server died",
)
_CORRUPT_TOKENS = (
    "value out of range", "out of range", "invalid argument",
    "item with the specified name does not exist",
    "has been deleted", "no longer valid", "800a1066",
)

_WORD_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")
_SURROGATE_RE = re.compile(r"[\ud800-\udfff]")

_DEFAULT_MAX_COM_ITEMS = 10_000
_DEFAULT_MAX_GROUP_DEPTH = 8
_DEFAULT_MAX_SHAPES_PER_RANGE = 500


#categories for failures
class ExtractorErrorCategory(str, Enum):
    OK = "ok"
    COM_BUSY = "com_busy"
    COM_STALE = "com_stale"
    COM_CORRUPT_ELEMENT = "com_corrupt_element"
    COM_UNKNOWN = "com_unknown"
    UNICODE = "unicode"
    MALFORMED_DOCUMENT = "malformed_document"
    RESOURCE = "resource"
    UNKNOWN = "unknown"



@dataclass
class ClassifiedExtractorError:
    category: ExtractorErrorCategory
    message: str
    exc: Optional[BaseException] = None

    def log(self, prefix: str = "extractor") -> None:
        _LOG.warning("[%s] %s: %s", prefix, self.category.value, self.message)


#classify the exception and detect
def classify_exception(
    exc: BaseException,
    *,
    context: str = "",
) -> ClassifiedExtractorError:
    msg = str(exc).lower()
    ctx = f" ({context})" if context else ""

    if _is_com_busy(exc):
        return ClassifiedExtractorError(ExtractorErrorCategory.COM_BUSY,
                                        f"Word COM busy{ctx}", exc)
    if any(t in msg for t in _STALE_TOKENS):
        return ClassifiedExtractorError(ExtractorErrorCategory.COM_STALE,
                                        f"Word COM stale{ctx}", exc)
    if any(t in msg for t in _CORRUPT_TOKENS):
        return ClassifiedExtractorError(ExtractorErrorCategory.COM_CORRUPT_ELEMENT,
                                        f"Invalid COM element{ctx}", exc)
    if isinstance(exc, (UnicodeDecodeError, UnicodeEncodeError)):
        return ClassifiedExtractorError(ExtractorErrorCategory.UNICODE,
                                        f"Unicode error{ctx}", exc)
    if "zip" in msg or "badzip" in msg or "xmlsyntax" in msg:
        return ClassifiedExtractorError(ExtractorErrorCategory.MALFORMED_DOCUMENT,
                                        f"Malformed package{ctx}", exc)
    if isinstance(exc, (MemoryError, OSError)):
        return ClassifiedExtractorError(ExtractorErrorCategory.RESOURCE,
                                        f"Resource error{ctx}", exc)
    try:
        import pywintypes
        if isinstance(exc, pywintypes.com_error):
            return ClassifiedExtractorError(ExtractorErrorCategory.COM_UNKNOWN,
                                            f"COM error{ctx}: {exc}", exc)
    except ImportError:
        pass
    return ClassifiedExtractorError(ExtractorErrorCategory.UNKNOWN,
                                    f"{type(exc).__name__}{ctx}: {exc}", exc)


def log_classified(exc: BaseException, context: str, prefix: str = "extractor") -> ExtractorErrorCategory:
    c = classify_exception(exc, context=context)
    log_event(
        get_logger("pdf_lens.extractors"),
        "extractor_error",
        msg=c.message,
        level=logging.WARNING,
        category=c.category.value,
        context=context,
        component=prefix,
    )
    return c.category


def normalize_word_text(
    raw: Any,
    *,
    strip_controls: bool = True,
    replace_surrogates: bool = True,
    max_len: int = 500_000,
) -> str:
    """
    Safe Unicode string from Word Range.Text / cell text.
    """
    if raw is None:
        return ""
    try:
        if not isinstance(raw, str):
            raw = str(raw)
    except Exception:
        return ""
    if replace_surrogates:
        raw = _SURROGATE_RE.sub("", raw)
    if strip_controls:
        raw = raw.replace("\x07", "").replace("\r", "\n")
        raw = _WORD_CTRL_RE.sub("", raw)
    raw = raw.strip()
    if max_len and len(raw) > max_len:
        raw = raw[:max_len]
    return raw

# Tries to help COM cleanup.
def release_com_refs(*objs: Any) -> None:
    for obj in objs:
        try:
            del obj
        except Exception:
            pass


def gc_collect_if_needed(threshold_items: int = 0, every_n: int = 50) -> None:
    if threshold_items and threshold_items % every_n == 0:
        gc.collect(0)

#Helps long-running extraction stability and hels cleanup
@contextmanager
def extraction_scope(label: str = "extract"):
    """Guaranteed gc tick after a bounded extraction block."""
    try:
        yield
    finally:
        gc.collect(0)


#safely iterates Word COM collections
def iter_com_collection(
    collection,
    *,
    max_items: int = _DEFAULT_MAX_COM_ITEMS,
    label: str = "collection",
) -> Generator[Any, None, None]:
    """
    Safe 1-based COM iteration — never materialise list(collection).
    Stops at max_items with a warning.
    """
    count = safe_com(lambda: collection.Count, default=0) or 0
    try:
        n = int(count)
    except (TypeError, ValueError):
        return
    if n <= 0:
        return
    if n > max_items:
        from src.utils.structured_log import get_logger, log_event
        log_event(
            get_logger("pdf_lens.extractors"),
            "com_collection_cap",
            msg=f"capping {label} Count={n} → {max_items}",
            level=logging.WARNING,
            label=label,
            count=n,
            cap=max_items,
        )
        n = max_items
    for i in range(1, n + 1):
        item = safe_com(lambda idx=i: collection(idx), default=None)
        if item is not None:
            yield item

# For Navigating the shapes in the docx
def is_group_shape(shape) -> bool:
    return safe_com(lambda s=shape: s.Type, default=None) == MSO_GROUP


def is_smartart_like_shape(shape) -> bool:
    """
    SmartArt / diagram shapes often fail Export — detect via name/type/heuristic.
    """
    name = (safe_com(lambda s=shape: s.Name, default="") or "").lower()
    if "smartart" in name or "diagram" in name:
        return True
    try:
        st = safe_com(lambda s=shape: s.Type, default=None)
        if st in (MSO_GROUP,):
            return False
    except Exception:
        pass
    return False


def shape_text_from_com(shape, depth: int = 0, max_depth: int = _DEFAULT_MAX_GROUP_DEPTH) -> list[str]:
    """
    Recursive shape/textbox text; handles msoGroup nesting with depth cap.
    """
    if depth > max_depth:
        return []
    texts: list[str] = []
    if is_group_shape(shape):
        items = safe_com(lambda s=shape: s.GroupItems, default=None)
        if items is not None:
            for child in iter_com_collection(
                    items, max_items=200, label="GroupItems"):
                texts.extend(shape_text_from_com(child, depth + 1, max_depth))
        return texts
    if is_smartart_like_shape(shape):
        alt = normalize_word_text(safe_com(lambda s=shape: s.AlternativeText, default=""))
        if alt:
            texts.append(alt)
        return texts
    has_tf = safe_com(lambda s=shape: s.TextFrame.HasText, default=False)
    if has_tf:
        t = normalize_word_text(
            safe_com(lambda s=shape: s.TextFrame.TextRange.Text, default=""))
        if t:
            texts.append(t)
    return texts


#This helper fixes invalid ranges
def clamp_doc_range_bounds(
    doc,
    start: int,
    end: int,
    *,
    window: int = 400,
) -> tuple[int, int]:
    """Clamp Range(start,end) to valid document bounds."""
    doc_end = int(safe_com(lambda: doc.Content.End, default=0) or 0)
    doc_end = max(1, doc_end)
    start = max(0, min(int(start), doc_end - 1))
    end = max(start + 1, min(int(end), doc_end))
    if window > 0 and end - start > window * 2:
        end = min(doc_end, start + window * 2)
    return start, end


def safe_doc_range(doc, start: int, end: int, *, context: str = "range"):
    """doc.Range with bounds clamp; returns None on corrupt COM."""
    start, end = clamp_doc_range_bounds(doc, start, end)
    try:
        return doc.Range(start, end)
    except Exception as exc:
        log_classified(exc, context)
        return None
