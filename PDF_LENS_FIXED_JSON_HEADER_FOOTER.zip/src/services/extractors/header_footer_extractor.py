import gc
import os
from typing import Any, Optional
import json
import pdfplumber
from src.constants.constant import (
    WD_HEADER_FOOTER_PRIMARY, WD_HEADER_FOOTER_FIRST_PAGE,
    WD_HEADER_FOOTER_EVEN_PAGES, WD_GO_TO_PAGE, WD_GO_TO_ABSOLUTE,
    WD_VERT_POS_REL_PAGE, SUFFIX_PDF_ZONES,
)
from src.utils.file_util import (
    safe_com, com_retry, pt_to_inch,
    build_fingerprints, para_matches_fingerprints,
)
from src.services.extractors.extractor_com_safe import (
    extraction_scope,
    iter_com_collection,
    log_classified,
    normalize_word_text,
    release_com_refs,
    shape_text_from_com,
)
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.extractors.header_footer_extractor")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)



#  CONSTANTS

_GAP_THRESHOLD_PT: float = 15.0      # inter-line gap that signals zone boundary
_MIN_IMAGE_HEIGHT_PT: float = 4.0    # ignore tiny images (rules, decorators)
_EMPTY_TEXT_THRESHOLD: int = 3       # COM text shorter than this → visual rescue
_MSO_GROUP: int = 6                  # msoShapeType constant for grouped shapes
_FOOTER_ZONE_RATIO: float = 0.72     # footer Y gate (rescue-only positional match)
_SEMANTIC_CONF_MIN: float = 0.35     # prefer semantic above this score
_VISUAL_RESCUE_THRESHOLD: float = 0.40  # minimum PDF zone score to allow rescue

_HF_TYPE_LABELS: dict[int, str] = {
    WD_HEADER_FOOTER_PRIMARY:    "primary",
    WD_HEADER_FOOTER_FIRST_PAGE: "first_page",
    WD_HEADER_FOOTER_EVEN_PAGES: "even_pages",
}

_HF_TYPES_ALL: list[tuple[int, str]] = [
    (WD_HEADER_FOOTER_PRIMARY,    "primary"),
    (WD_HEADER_FOOTER_FIRST_PAGE, "first_page"),
    (WD_HEADER_FOOTER_EVEN_PAGES, "even_pages"),
]

def _log_hf(event: str, msg: str, **extra: Any) -> None:
    """Structured header/footer extraction logging."""
    log_event(_SLOG, event, msg=msg, component="header_footer_extractor", **extra)


# Per-document GoTo page-start cache for footer rescue (avoids repeated pagination).
# Keyed by id(doc); cleared explicitly or when the process ends.
_RESCUE_PAGE_CACHES: dict[int, dict] = {}



#  VISUAL PDF FALLBACK (RESCUE / GEOMETRY — not primary extraction)

def _chars_to_lines(chars: list) -> list:
    """
    Bucket PDF characters by rounded top-Y into visual lines.
    Returns a list of line dicts sorted top-to-bottom.
    """
    buckets: dict = {}
    for c in chars:
        key = round(float(c["top"]), 0)
        buckets.setdefault(key, []).append(c)

    lines = []
    for key in sorted(buckets):
        cs   = buckets[key]
        text = "".join(c["text"] for c in sorted(cs, key=lambda x: x["x0"])).strip()
        if not text:
            continue
        sizes = [float(c["size"]) for c in cs if c.get("size")]
        lines.append({
            "text":      text,
            "font_size": round(sum(sizes) / len(sizes), 2) if sizes else 0.0,
            "top_pt":    round(float(cs[0]["top"]),    3),
            "bottom_pt": round(float(cs[0]["bottom"]), 3),
            "x0_pt":     round(min(float(c["x0"]) for c in cs), 3),
            "x1_pt":     round(max(float(c["x1"]) for c in cs), 3),
        })
    return lines


def _cluster_from_top(lines: list, gap: float,
                      max_bottom_pt: float = 0.0) -> list:
    """
    Collect consecutive lines from the top until:
      (a) inter-line gap exceeds `gap`, OR
      (b) the next line's top_pt exceeds `max_bottom_pt` (when > 0).
    Combining both guards prevents body text from being swept into the header
    on pages where the gap between the real header line and the first body
    line is smaller than `gap`.
    """
    zone = []
    for i, line in enumerate(lines):
        # Position guard: stop before adding a line that starts beyond boundary
        if max_bottom_pt > 0 and line["top_pt"] > max_bottom_pt:
            break
        zone.append(line)
        if i + 1 < len(lines):
            next_line = lines[i + 1]
            # Gap guard
            if next_line["top_pt"] - line["bottom_pt"] > gap:
                break
            # Look-ahead position guard: don't include next line if it's past boundary
            if max_bottom_pt > 0 and next_line["top_pt"] > max_bottom_pt:
                break
    return zone


def _cluster_from_bottom(lines: list, gap: float,
                         min_top_pt: float = 0.0) -> list:
    """
    Collect consecutive lines from the bottom (upward) until:
      (a) inter-line gap exceeds `gap`, OR
      (b) the next line's bottom_pt is less than `min_top_pt` (when > 0).
    """
    rev = list(reversed(lines))
    zone_rev = []
    for i, line in enumerate(rev):
        # Position guard: stop before adding a line that ends above boundary
        if min_top_pt > 0 and line["bottom_pt"] < min_top_pt:
            break
        zone_rev.append(line)
        if i + 1 < len(rev):
            next_line = rev[i + 1]
            # Gap guard
            if line["top_pt"] - next_line["bottom_pt"] > gap:
                break
            # Look-ahead position guard
            if min_top_pt > 0 and next_line["bottom_pt"] < min_top_pt:
                break
    return list(reversed(zone_rev))


def _bbox(lines: list) -> tuple:
    """Return (top_pt, bottom_pt) bounding box for a list of line dicts."""
    if not lines:
        return 0.0, 0.0
    return (min(l["top_pt"] for l in lines),
            max(l["bottom_pt"] for l in lines))


def _classify_images(images: list, ph: float,
                     hdr_boundary: float, ftr_boundary: float) -> dict:
    """Split page images into header / footer buckets by image midpoint."""
    hdr_imgs, ftr_imgs = [], []
    for img in images:
        img_top    = float(img.get("top",    0))
        img_bottom = float(img.get("bottom", img_top))
        h          = img_bottom - img_top
        if h < _MIN_IMAGE_HEIGHT_PT:
            continue
        img_mid = (img_top + img_bottom) / 2.0
        record = {
            "top_pt":    round(img_top,              3),
            "bottom_pt": round(img_bottom,           3),
            "width_pt":  round(float(img.get("width",  0)), 3),
            "height_pt": round(h,                    3),
            "name":      img.get("name", ""),
        }
        if img_mid <= hdr_boundary:
            hdr_imgs.append(record)
        elif img_mid >= ftr_boundary:
            ftr_imgs.append(record)
    return {"header": hdr_imgs, "footer": ftr_imgs}


_MAX_ZONE_RATIO: float = 0.15 
_DEFAULT_HDR_MAX_PT: float = 72.0
_DEFAULT_FTR_MIN_RATIO: float = 0.85  


def detect_header_footer_dynamic(
        pdf_page,
        gap_threshold: float = _GAP_THRESHOLD_PT,
        hdr_max_pt: float = _DEFAULT_HDR_MAX_PT,
        ftr_min_ratio: float = _DEFAULT_FTR_MIN_RATIO,
) -> dict:
    """
    VISUAL FALLBACK ONLY — used for PDF zone JSON, geometry hints, and rescue.

    Detect header and footer zones on a pdfplumber Page using a combination of:
      1. Gap-based line clustering (stop when inter-line gap > gap_threshold)
      2. Hard position boundary (lines past hdr_max_pt are never header)
      3. Absolute height cap (zone > 15% of page is discarded)

    This triple guard prevents body text from being swept into the header zone
    on pages where (a) the PDF has no dedicated header stream and body text
    starts near the top, or (b) the gap between the real header line and the
    first body line is smaller than gap_threshold.

    Parameters
    ----------
    pdf_page      : pdfplumber Page object
    gap_threshold : inter-line gap (pt) that signals end of zone (default 15pt)
    hdr_max_pt    : hard ceiling — lines whose top_pt exceeds this are never
                    included in the header zone (default 72pt = 1 inch)
    ftr_min_ratio : footer lines must start below page_height * ftr_min_ratio
                    (default 0.85 = bottom 15% of page)
    """
    pw = float(pdf_page.width)
    ph = float(pdf_page.height)
    ftr_min_pt = ph * ftr_min_ratio

    all_lines = _chars_to_lines(pdf_page.chars or [])

    #  cluster zones with dual guard (gap + position) 
    hdr_lines = (_cluster_from_top(all_lines, gap_threshold,
                                   max_bottom_pt=hdr_max_pt)
                 if all_lines else [])
    ftr_lines = (_cluster_from_bottom(all_lines, gap_threshold,
                                      min_top_pt=ftr_min_pt)
                 if all_lines else [])
    hdr_top, hdr_bot = _bbox(hdr_lines)
    ftr_top, ftr_bot = _bbox(ftr_lines)

    max_zone_height = ph * _MAX_ZONE_RATIO
    if hdr_lines and (hdr_bot - hdr_top) > max_zone_height:
        hdr_lines = []; hdr_top = hdr_bot = 0.0
    if ftr_lines and (ftr_bot - ftr_top) > max_zone_height:
        ftr_lines = []; ftr_top = ftr_bot = 0.0

    # overlap guard 
    if hdr_lines and ftr_lines and hdr_bot >= ftr_top:
        if (hdr_bot - hdr_top) <= (ftr_bot - ftr_top):
            hdr_lines = []; hdr_top = hdr_bot = 0.0
        else:
            ftr_lines = []; ftr_top = ftr_bot = 0.0

    # image zones 
    hdr_img_bnd = hdr_bot if hdr_bot > 0 else ph * 0.15
    ftr_img_bnd = ftr_top if ftr_top > 0 else ph * 0.85
    try:
        page_imgs = pdf_page.images or []
    except Exception:
        page_imgs = []
    img_zones = _classify_images(page_imgs, ph, hdr_img_bnd, ftr_img_bnd)

    if not hdr_lines and img_zones["header"]:
        hdr_top = min(i["top_pt"]    for i in img_zones["header"])
        hdr_bot = max(i["bottom_pt"] for i in img_zones["header"])
    if not ftr_lines and img_zones["footer"]:
        ftr_top = min(i["top_pt"]    for i in img_zones["footer"])
        ftr_bot = max(i["bottom_pt"] for i in img_zones["footer"])

    return {
        "header_lines":  hdr_lines,
        "footer_lines":  ftr_lines,
        "header_block":  "\n".join(l["text"] for l in hdr_lines),
        "footer_block":  "\n".join(l["text"] for l in ftr_lines),
        "header_images": img_zones["header"],
        "footer_images": img_zones["footer"],
        "coordinates": {
            "page_width_pt":             round(pw,                3),
            "page_height_pt":            round(ph,                3),
            "header_top_pt":             round(hdr_top,           3),
            "header_bottom_pt":          round(hdr_bot,           3),
            "header_height_pt":          round(hdr_bot - hdr_top, 3),
            "footer_top_pt":             round(ftr_top,           3),
            "footer_bottom_pt":          round(ftr_bot,           3),
            "footer_height_pt":          round(ftr_bot - ftr_top, 3),
            "footer_dist_from_bottom_pt":round(ph - ftr_bot,      3) if ftr_bot else 0.0,
        },
    }


#  PDF ZONE BATCH EXTRACTION

def extract_pdf_header_footer_zones(
        pdf_path: str,
        gap_threshold: float = _GAP_THRESHOLD_PT,
        header_ratio: float = 0.15,  
        footer_ratio: float = 0.15,  
        hdr_max_pt: float = _DEFAULT_HDR_MAX_PT,
        ftr_min_ratio: float = _DEFAULT_FTR_MIN_RATIO,
) -> dict:
    """
    VISUAL FALLBACK — run detect_header_footer_dynamic() on every PDF page.
    Returns {page_number: flattened_zone_dict} for rescue, geometry, and compare.

    Not the primary header/footer text source; Word COM sections are primary.
    """
    import gc as _gc
    zones: dict = {}
    # Open once but process page-by-page, releasing each pdfplumber Page
    # object after extraction so image/text objects don't accumulate.
    with pdfplumber.open(pdf_path) as pdf:
        total_pdf_pages = len(pdf.pages)
        for page_idx in range(total_pdf_pages):
            pn   = page_idx + 1
            page = pdf.pages[page_idx]
            try:
                zone = detect_header_footer_dynamic(
                    page,
                    gap_threshold=gap_threshold,
                    hdr_max_pt=hdr_max_pt,
                    ftr_min_ratio=ftr_min_ratio,
                )
                c    = zone["coordinates"]
                zones[pn] = {
                    "header_lines":              zone["header_lines"],
                    "footer_lines":              zone["footer_lines"],
                    "header_block":              zone["header_block"],
                    "footer_block":              zone["footer_block"],
                    "header_images":             zone["header_images"],
                    "footer_images":             zone["footer_images"],
                    # flattened coords (backwards-compat)
                    "header_top_pt":             c["header_top_pt"],
                    "header_bottom_pt":          c["header_bottom_pt"],
                    "header_height_pt":          c["header_height_pt"],
                    "footer_top_pt":             c["footer_top_pt"],
                    "footer_bottom_pt":          c["footer_bottom_pt"],
                    "footer_height_pt":          c["footer_height_pt"],
                    "footer_dist_from_bottom_pt":c["footer_dist_from_bottom_pt"],
                    "page_width_pt":             c["page_width_pt"],
                    "page_height_pt":            c["page_height_pt"],
                }
            except Exception as _e:
                _slog(f"  [pdf zones] page {pn}: {_e}")
            finally:
                # Explicitly close page to release cached chars/rects/images
                try:
                    page.close()
                except Exception:
                    pass
                del page
                # GC every 25 pages to free pdfplumber text/image objects
                if pn % 25 == 0:
                    _gc.collect()
    return zones


def save_pdf_zones_json(pdf_zones: dict, output_folder: str, base_name: str) -> str:
    path = os.path.join(output_folder, f"{base_name}{SUFFIX_PDF_ZONES}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(pdf_zones, f, indent=2, ensure_ascii=False)
    _slog(f"  [pdf zones] JSON -> {os.path.basename(path)}")
    return path



#  GEOMETRY APPLICATION
 

@com_retry()
def apply_pdf_zones_to_docx(doc, pdf_zones: dict) -> None:
    """Adjust DOCX section margins and header/footer distances to match PDF zones."""
    for sec_idx, section in enumerate(doc.Sections):
        pn   = sec_idx + 1
        zone = pdf_zones.get(pn) or pdf_zones.get(1)
        if not zone:
            continue
        try:
            setup = section.PageSetup
            # OPT: one COM round-trip for all PageSetup reads per section.
            _ps = safe_com(
                lambda s=setup: (
                    float(s.PageHeight or 841.9),
                    float(s.PageWidth or 595.3),
                    float(s.TopMargin or 72.0),
                    float(s.BottomMargin or 72.0),
                ),
                default=(841.9, 595.3, 72.0, 72.0),
            )
            page_h, page_w, orig_top, orig_bot = _ps


            max_margin = page_h * 0.40        
            hdr_top_pt    = min(zone["header_top_pt"]              or 36.0, max_margin)
            hdr_height_pt = min(zone["header_height_pt"]           or 14.0, max_margin)
            hdr_bot_pt    = hdr_top_pt + hdr_height_pt  
            ftr_dist_pt   = min(zone["footer_dist_from_bottom_pt"] or 36.0, max_margin)
            ftr_height_pt = min(zone["footer_height_pt"]           or 14.0, max_margin)

            hdr_dist = max(hdr_bot_pt, 18.0)
            hdr_dist = min(hdr_dist, page_h * 0.35)

            ftr_dist = max(18.0, min(ftr_dist_pt, page_h * 0.35))

            top_margin = max(hdr_bot_pt, orig_top)
            bot_margin = max(ftr_dist_pt + ftr_height_pt, orig_bot)
            top_margin = min(top_margin, page_h * 0.35)
            bot_margin = min(bot_margin, page_h * 0.35)

            while top_margin + bot_margin > page_h * 0.70:
                top_margin = round(top_margin * 0.9, 1)
                bot_margin = round(bot_margin * 0.9, 1)

            setup.HeaderDistance = hdr_dist
            setup.FooterDistance = ftr_dist
            setup.TopMargin      = top_margin
            setup.BottomMargin   = bot_margin
            _slog(f"  [geometry sec{pn}] HdrDist={hdr_dist:.1f}pt "
                  f"FtrDist={ftr_dist:.1f}pt "
                  f"TopM={top_margin:.1f}pt BotM={bot_margin:.1f}pt")
        except Exception as e:
            _slog(f"  [geometry sec{pn}] skipped: {e}")


#  PRIMARY — WORD COM SECTION HEADER/FOOTER EXTRACTION

def clear_rescue_page_cache(doc=None) -> None:
    """Drop cached page-start positions (call when closing a Word document)."""
    if doc is None:
        _RESCUE_PAGE_CACHES.clear()
    else:
        _RESCUE_PAGE_CACHES.pop(id(doc), None)


def _rescue_cache_bucket(doc, page_start_cache: Optional[dict] = None) -> dict:
    """
    Return the mutable page-start cache for *doc*.
    Uses *page_start_cache* when supplied (e.g. pipeline Step 7 cache).
    """
    if page_start_cache is not None:
        bucket = _RESCUE_PAGE_CACHES.setdefault(id(doc), {})
        bucket["starts"] = page_start_cache
        return bucket
    return _RESCUE_PAGE_CACHES.setdefault(
        id(doc), {"starts": {}, "content_end": 0})


def _goto_page_start_rescue(doc, page_num: int) -> int:
    """GoTo page start with @com_retry semantics (used only when cache misses)."""
    @com_retry()
    def _go():
        rng = doc.GoTo(WD_GO_TO_PAGE, WD_GO_TO_ABSOLUTE, page_num)
        return int(rng.Start)
    return _go()


def _ensure_rescue_page_starts(
    doc,
    bucket: dict,
    page_from: int,
    page_to: int,
    total_pages: int,
) -> None:
    """Fill bucket['starts'][pn] for pages page_from … page_to (+ delimiter page)."""
    starts = bucket["starts"]
    last_needed = page_to + 1 if page_to < total_pages else page_to
    for pn in range(page_from, last_needed + 1):
        if pn in starts:
            continue
        starts[pn] = _goto_page_start_rescue(doc, pn)


def _rescue_page_range(
    doc,
    page_num: int,
    bucket: dict,
    total_pages: int,
):
    """Build a page body Range via enterprise-safe page boundary helper."""
    from src.services.pipeline.page_boundary import (
        get_doc_content_end,
        safe_page_range,
    )

    starts = bucket["starts"]
    ref = bucket.setdefault("content_end_ref", {"value": 0})
    if not ref.get("value"):
        ref["value"] = bucket.get("content_end") or get_doc_content_end(doc)
    rng, _diag = safe_page_range(
        doc, page_num, starts, total_pages, ref)
    bucket["content_end"] = ref["value"]
    return rng


def _footer_zone_top_pt(pdf_zone: dict) -> float:
    """Cached footer vertical gate from PDF zone (geometry-sensitive)."""
    return float(pdf_zone.get("page_height_pt") or 0) * _FOOTER_ZONE_RATIO


def _para_footer_position_match(para, footer_zone_top: float) -> bool:
    """
    True when paragraph vertical position is in the footer band.
    Only called when fingerprint match failed — preserves layout gate.
    """
    y = safe_com(
        lambda p=para: p.Range.Information(WD_VERT_POS_REL_PAGE),
        default=None,
    )
    return y is not None and y >= footer_zone_top


def _scan_page_for_displaced_footers(
    doc,
    search_page: int,
    page_num_for_pos: int,
    fingerprints: list,
    footer_zone_top: float,
    bucket: dict,
    total_pages: int,
    displaced: list,
    log_prefix: str = "",
) -> None:
    """
    Scan one page for displaced footer paragraphs.
    Information() is skipped when fingerprint already matches (safe win).
    """
    if search_page > total_pages:
        return
    try:
        p_rng = _rescue_page_range(doc, search_page, bucket, total_pages)
        if p_rng is None:
            return
        for para in p_rng.Paragraphs:
            txt = safe_com(lambda p=para: p.Range.Text.strip(), default="")
            if not txt:
                continue
            matched_fp = para_matches_fingerprints(txt, fingerprints, threshold=2)
            if matched_fp:
                displaced.append(para)
                if log_prefix:
                    _slog(f"    -> displaced ({log_prefix}): FP | {txt[:60]!r}")
                continue
            matched_pos = False
            if search_page == page_num_for_pos and footer_zone_top > 0:
                matched_pos = _para_footer_position_match(para, footer_zone_top)
            if matched_pos:
                displaced.append(para)
                if log_prefix:
                    _slog(f"    -> displaced ({log_prefix}): POS | {txt[:60]!r}")
    except Exception as e:
        _slog(f"  [rescue_footer] scan p{search_page}: {e}")


def _resolve_total_pages(doc, pdf_zones: dict, total_pages: int) -> int:
    """
    Prefer explicit total_pages, then PDF zone count, then one ComputeStatistics.
    Avoids repeated pagination during rescue loops.
    """
    if total_pages and total_pages > 0:
        return total_pages
    if pdf_zones:
        n = max(pdf_zones.keys(), default=0)
        if n > 0:
            return n
    return safe_com(lambda: doc.Content.ComputeStatistics(2), default=1)


def _iter_com(collection, max_items: int = 2000, label: str = "hf_com"):
    """Yield items from a 1-based COM collection (capped, defensive)."""
    yield from iter_com_collection(collection, max_items=max_items, label=label)


def _shape_text_recursive(shape, depth: int = 0) -> list:
    """Recursive shape/textbox/SmartArt-alt text via shared helper."""
    return shape_text_from_com(shape, depth=depth, max_depth=8)


def _inline_shape_text(ishape) -> Optional[str]:
    """Extract text from an InlineShape that wraps a TextFrame."""
    has_tf = safe_com(lambda: ishape.TextFrame.HasText, default=False)
    if not has_tf:
        return None
    t = normalize_word_text(
        safe_com(lambda: ishape.TextFrame.TextRange.Text, default=""))
    return t or None


def _dedup_merge(*blocks: str) -> str:
    """
    Merge text blocks, skipping those already subsumed by an earlier block.
    Prevents duplicate content when text appears in both inline and shape layers.
    """
    seen = []
    for block in blocks:
        if not block or not block.strip():
            continue
        norm = block.strip()
        if any(norm in s or s in norm for s in seen):
            continue
        seen.append(norm)
    return "\n".join(seen)


def _release_hf_com_refs(*objs: Any) -> None:
    """Explicitly drop COM proxies to avoid stale references after Word recycle."""
    release_com_refs(*objs)


def _shape_position_pt(shape) -> dict:
    """Word shape coordinates in points (header/footer layer)."""
    left = safe_com(lambda: shape.Left, default=None)
    top  = safe_com(lambda: shape.Top,  default=None)
    if left is None and top is None:
        return {}
    width  = safe_com(lambda: shape.Width,  default=0)
    height = safe_com(lambda: shape.Height, default=0)
    return {
        "left_pt":   round(float(left or 0), 3),
        "top_pt":    round(float(top or 0),  3),
        "width_pt":  round(float(width or 0), 3),
        "height_pt": round(float(height or 0), 3),
    }


def _extract_hf_tables(rng) -> list:
    """Extract tables from a header/footer Range."""
    tables_out: list = []
    tbl_coll = safe_com(lambda: rng.Tables, default=None)
    if tbl_coll is None:
        return tables_out
    for tbl in _iter_com(tbl_coll):
        n_rows = safe_com(lambda t=tbl: t.Rows.Count, default=0) or 0
        n_cols = safe_com(lambda t=tbl: t.Columns.Count, default=0) or 0
        rows: list = []
        for r in range(1, n_rows + 1):
            row_cells: list = []
            for c in range(1, n_cols + 1):
                cell_text = safe_com(
                    lambda t=tbl, rr=r, cc=c: t.Cell(rr, cc).Range.Text,
                    default="",
                )
                if cell_text:
                    cell_text = (cell_text.replace("\r", "")
                                 .replace("\x07", "").strip())
                row_cells.append(cell_text)
            rows.append(row_cells)
        tables_out.append({
            "row_count": n_rows,
            "col_count": n_cols,
            "rows":      rows,
        })
        _release_hf_com_refs(tbl)
    _release_hf_com_refs(tbl_coll)
    return tables_out


def _semantic_confidence(info: dict) -> float:
    """Score 0–1 for Word COM header/footer extraction quality."""
    score = 0.0
    text = (info.get("text") or "").strip()
    if len(text) > _EMPTY_TEXT_THRESHOLD:
        score += 0.45
    if info.get("shape_text_found"):
        score += 0.15
    img_count = (info.get("images") or {}).get("count", 0)
    if img_count > 0:
        score += 0.15
    if (info.get("table_count") or 0) > 0:
        score += 0.15
    if info.get("hyperlinks"):
        score += 0.05
    if info.get("has_page_field") and text:
        score += 0.05
    return min(1.0, score)


def _visual_confidence(pdf_zone: Optional[dict], is_header: bool) -> float:
    """Score 0–1 for PDF visual zone quality (fallback signal only)."""
    if not pdf_zone:
        return 0.0
    block = ((pdf_zone.get("header_block") if is_header
              else pdf_zone.get("footer_block")) or "").strip()
    if not block:
        return 0.0
    score = min(0.5, len(block) / 80.0)
    lines = (pdf_zone.get("header_lines") if is_header
             else pdf_zone.get("footer_lines")) or []
    if lines:
        score += 0.25
    imgs = (pdf_zone.get("header_images") if is_header
            else pdf_zone.get("footer_images")) or []
    if imgs:
        score += 0.15
    return min(1.0, score)


def _needs_visual_rescue(semantic_conf: float, info: dict,
                         pdf_zone: Optional[dict], is_header: bool) -> bool:
    """True when semantic extraction is weak but PDF zones are strong."""
    if semantic_conf >= _SEMANTIC_CONF_MIN:
        return False
    vis = _visual_confidence(pdf_zone, is_header)
    if vis < _VISUAL_RESCUE_THRESHOLD:
        return False
    text = (info.get("text") or "").strip()
    if len(text) <= _EMPTY_TEXT_THRESHOLD:
        return True
    if not info.get("shape_text_found") and vis >= 0.5:
        imgs_sem = (info.get("images") or {}).get("count", 0)
        imgs_vis = len(
            (pdf_zone.get("header_images") if is_header
             else pdf_zone.get("footer_images")) or [])
        if imgs_vis > 0 and imgs_sem == 0:
            return True
    return False


def _merge_semantic_with_visual(
        info: dict,
        pdf_zone: Optional[dict],
        is_header: bool,
        page_number: int = 0,
) -> dict:
    """Prefer semantic text; activate PDF visual rescue only when needed."""
    sem_conf = _semantic_confidence(info)
    vis_conf = _visual_confidence(pdf_zone, is_header)
    info["semantic_confidence"] = round(sem_conf, 3)
    info["visual_confidence"]   = round(vis_conf, 3)
    info["rescue_activated"]    = False

    if not _needs_visual_rescue(sem_conf, info, pdf_zone, is_header):
        info["extraction_source"] = "semantic" if sem_conf > 0 else "empty"
        info["used_pdf_fallback"] = False
        return info

    pdf_key  = "header_block" if is_header else "footer_block"
    pdf_text = ((pdf_zone or {}).get(pdf_key) or "").strip()
    if not pdf_text:
        info["extraction_source"] = "semantic" if sem_conf > 0 else "empty"
        info["used_pdf_fallback"] = False
        return info

    existing = (info.get("text") or "").strip()
    if len(existing) <= _EMPTY_TEXT_THRESHOLD:
        info["text"]              = pdf_text
        info["used_pdf_fallback"] = True
        info["rescue_activated"]  = True
        info["extraction_source"] = "visual_fallback"
        _log_hf(
            "rescue",
            f"PDF text fallback {'header' if is_header else 'footer'}",
            page=page_number,
            sem=sem_conf,
            vis=vis_conf,
        )
    elif pdf_text not in existing:
        info["text"]              = _dedup_merge(existing, pdf_text)
        info["used_pdf_fallback"] = True
        info["rescue_activated"]  = True
        info["extraction_source"] = "merged"
        _log_hf(
            "merge",
            f"merged PDF zone into {'header' if is_header else 'footer'}",
            page=page_number,
            sem=sem_conf,
            vis=vis_conf,
        )
    else:
        info["extraction_source"] = "semantic"

    info["semantic_confidence"] = round(_semantic_confidence(info), 3)
    return info


def _hf_exists(hf_obj) -> bool:
    """True when the header/footer story exists and is linked or has content."""
    try:
        rng = safe_com(lambda: hf_obj.Range, default=None)
        if rng is None:
            return False
        txt = safe_com(lambda: rng.Text, default="")
        if txt and txt.replace("\r", "").replace("\x07", "").strip():
            return True
        shapes = safe_com(lambda: hf_obj.Shapes, default=None)
        if shapes and (safe_com(lambda: shapes.Count, default=0) or 0) > 0:
            return True
        if rng is not None:
            ils = safe_com(lambda: rng.InlineShapes, default=None)
            if ils and (safe_com(lambda: ils.Count, default=0) or 0) > 0:
                return True
    except Exception:
        pass
    return False


def extract_real_section_headers_footers(
        doc,
        img_folder: str,
        pdf_zones: Optional[dict] = None,
        extract_images: bool = True,
        odd_and_even: bool = False,
) -> dict:
    """
    PRIMARY extraction: walk doc.Sections and extract real Word headers/footers.

    Uses section.Headers(wd*) and section.Footers(wd*) for primary, first-page,
    and even-page stories.  PDF visual zones are used only for confidence-based
    rescue via _merge_semantic_with_visual.

    Returns
    -------
    {
        "section_count": int,
        "extraction_source": "word_com",
        "by_section": { section_index: { headers, footers, ... } },
        "lookup": { (section_start, hf_type, is_header): info_dict },
        "rescue_count": int,
        "missing_headers": [...],
        "missing_footers": [...],
    }
    """
    sec_count = safe_com(lambda: doc.Sections.Count, default=0) or 0
    _log_hf("semantic_start", "extracting section headers/footers",
            sections=sec_count)

    by_section: dict = {}
    lookup: dict = {}
    rescue_count   = 0
    missing_hdr: list = []
    missing_ftr: list = []

    for sec_idx in range(1, sec_count + 1):
        section = safe_com(lambda i=sec_idx: doc.Sections(i), default=None)
        if section is None:
            continue

        sec_start = safe_com(lambda s=section: s.Range.Start, default=sec_idx)
        ps = safe_com(lambda s=section: s.PageSetup, default=None)
        diff_first = bool(safe_com(
            lambda p=ps: p.DifferentFirstPageHeaderFooter,
            default=False)) if ps else False
        linked_prev = bool(safe_com(
            lambda s=section: s.LinkToPrevious,
            default=False))

        sec_entry = {
            "section_index":      sec_idx,
            "section_start":      sec_start,
            "different_first_page": diff_first,
            "linked_to_previous": linked_prev,
            "headers":            {},
            "footers":            {},
        }

        # Representative PDF page for this section (rescue merge hint)
        pdf_zone = (pdf_zones or {}).get(sec_idx) or (pdf_zones or {}).get(1)

        for hf_type, type_label in _HF_TYPES_ALL:
            if hf_type == WD_HEADER_FOOTER_FIRST_PAGE and not diff_first:
                continue
            if hf_type == WD_HEADER_FOOTER_EVEN_PAGES and not odd_and_even:
                continue

            for is_header in (True, False):
                coll_name = "Headers" if is_header else "Footers"
                hf_obj = safe_com(
                    lambda s=section, t=hf_type, cn=coll_name: getattr(s, cn)(t),
                    default=None,
                )
                if hf_obj is None:
                    key = (sec_start, hf_type, is_header)
                    if is_header:
                        missing_hdr.append(
                            {"section": sec_idx, "type": type_label})
                    else:
                        missing_ftr.append(
                            {"section": sec_idx, "type": type_label})
                    continue

                prefix = (f"sec{sec_idx}_{'hdr' if is_header else 'ftr'}"
                          f"_{type_label}")
                info = analyze_header_footer_range(
                    hf_obj,
                    img_folder,
                    prefix=prefix,
                    extract_images=extract_images,
                    page_number=sec_idx,
                    pdf_zone=pdf_zone,
                    is_header=is_header,
                    section_index=sec_idx,
                    hf_type=hf_type,
                    hf_type_label=type_label,
                    prefer_semantic=True,
                )
                if info.get("rescue_activated"):
                    rescue_count += 1

                bucket = sec_entry["headers"] if is_header else sec_entry["footers"]
                bucket[hf_type] = info
                lookup[(sec_start, hf_type, is_header)] = info

                if not _hf_exists(hf_obj) and not (info.get("text") or "").strip():
                    if is_header:
                        missing_hdr.append(
                            {"section": sec_idx, "type": type_label})
                    else:
                        missing_ftr.append(
                            {"section": sec_idx, "type": type_label})

                _release_hf_com_refs(hf_obj)

        by_section[sec_idx] = sec_entry
        _release_hf_com_refs(section, ps)

        if sec_idx % 5 == 0:
            gc.collect()

    result = {
        "section_count":     sec_count,
        "extraction_source": "word_com",
        "by_section":        by_section,
        "lookup":            lookup,
        "rescue_count":      rescue_count,
        "missing_headers":   missing_hdr,
        "missing_footers":   missing_ftr,
    }
    _log_hf(
        "semantic_done",
        "section extraction complete",
        sections=sec_count,
        rescue=rescue_count,
        missing_hdr=len(missing_hdr),
        missing_ftr=len(missing_ftr),
    )
    gc.collect()
    return result


def analyze_header_footer_range(
        hf_obj,
        img_folder: str,
        prefix: str = "hf",
        extract_images: bool = True,
        page_number: int = 0,
        pdf_zone: Optional[dict] = None,
        is_header: bool = True,
        section_index: int = 0,
        hf_type: int = WD_HEADER_FOOTER_PRIMARY,
        hf_type_label: str = "primary",
        prefer_semantic: bool = True,
) -> dict:
    """
    Extract a single Word header or footer COM object (semantic primary).

    Layers: Range text, Shapes (recursive groups/textboxes), InlineShapes,
    ShapeRange, tables, images with coordinates, hyperlinks, then optional
    PDF visual rescue when semantic confidence is low.
    """
    from src.services.extractors.image_extractor import extract_and_save_image
    from src.services.extractors.hyperlink_extractor import extract_hyperlinks_from_range

    rng = safe_com(lambda: hf_obj.Range, default=None)

    inline_text = ""
    has_page_field = False
    if rng is not None:
        raw = safe_com(lambda: rng.Text, default="")
        inline_text = normalize_word_text(raw)

    imgs: list = []

    shape_texts: list = []
    shapes_col = safe_com(lambda: hf_obj.Shapes, default=None)
    if shapes_col is not None:
        for shape in _iter_com(shapes_col):
            shape_texts.extend(_shape_text_recursive(shape))
            if extract_images:
                meta = safe_com(
                    lambda s=shape: extract_and_save_image(
                        s, img_folder, f"{prefix}_float",
                        page_number=page_number),
                    default=None)
                if meta:
                    meta.update(_shape_position_pt(shape))
                    meta["hf_layer"] = "floating"
                    imgs.append(meta)
            _release_hf_com_refs(shape)
        _release_hf_com_refs(shapes_col)

    inline_shape_texts: list = []
    if rng is not None:
        ils = safe_com(lambda: rng.InlineShapes, default=None)
        if ils is not None:
            for ishape in _iter_com(ils):
                t = _inline_shape_text(ishape)
                if t:
                    inline_shape_texts.append(t)
                if extract_images:
                    meta = safe_com(
                        lambda s=ishape: extract_and_save_image(
                            s, img_folder, f"{prefix}_inline",
                            page_number=page_number),
                        default=None)
                    if meta:
                        meta.update(_shape_position_pt(ishape))
                        meta["hf_layer"] = "inline"
                        imgs.append(meta)
                _release_hf_com_refs(ishape)
            _release_hf_com_refs(ils)

    shape_range_texts: list = []
    if rng is not None:
        try:
            sr = rng.ShapeRange
            for shape in _iter_com(sr):
                shape_range_texts.extend(_shape_text_recursive(shape))
                if extract_images:
                    meta = safe_com(
                        lambda s=shape: extract_and_save_image(
                            s, img_folder, f"{prefix}_sr",
                            page_number=page_number),
                        default=None)
                    if meta:
                        meta.update(_shape_position_pt(shape))
                        meta["hf_layer"] = "shape_range"
                        imgs.append(meta)
                _release_hf_com_refs(shape)
            _release_hf_com_refs(sr)
        except Exception:
            pass

    tables: list = []
    if rng is not None:
        tables = _extract_hf_tables(rng)

    fsizes: set = set()
    fnames: set = set()
    styles: set = set()
    if rng is not None:
        paras = safe_com(lambda: rng.Paragraphs, default=None)
        if paras is not None:
            for para in _iter_com(paras):
                if not has_page_field:
                    try:
                        fields_coll = safe_com(
                            lambda p=para: p.Range.Fields, default=None)
                        if fields_coll is not None:
                            for fld in _iter_com(
                                    fields_coll, max_items=32, label="Fields"):
                                code = safe_com(
                                    lambda f=fld: f.Code.Text, default="")
                                if code and any(
                                        k in code.upper()
                                        for k in ("PAGE", "NUMPAGES")):
                                    has_page_field = True
                                    break
                    except Exception as exc:
                        log_classified(exc, "hf_fields")
                _font_meta = safe_com(
                    lambda p=para: (
                        p.Range.Font.Size,
                        p.Range.Font.Name,
                        p.Range.Style.NameLocal,
                    ),
                    default=None,
                )
                if _font_meta:
                    sz, nm, sn = _font_meta
                    if sz and sz > 0:
                        fsizes.add(float(sz))
                    if nm:
                        fnames.add(str(nm))
                    if sn:
                        styles.add(str(sn))
                _release_hf_com_refs(para)
            _release_hf_com_refs(paras)

    hls: list = []
    if rng is not None:
        try:
            hls = extract_hyperlinks_from_range(rng)
        except Exception:
            hls = []

    shape_text_found = bool(any(
        t.strip() for t in
        shape_texts + inline_shape_texts + shape_range_texts))
    merged_text = _dedup_merge(
        inline_text,
        *shape_texts,
        *inline_shape_texts,
        *shape_range_texts,
    )

    info = {
        "text":              merged_text,
        "font_sizes":        sorted(fsizes),
        "font_names":        sorted(fnames),
        "word_styles":       sorted(styles),
        "hyperlinks":        hls,
        "images":            {"count": len(imgs), "details": imgs},
        "tables":            tables,
        "table_count":       len(tables),
        "shape_text_found":  shape_text_found,
        "used_pdf_fallback": False,
        "has_page_field":    has_page_field,
        "section_index":     section_index or page_number,
        "hf_type":           hf_type,
        "hf_type_label":     hf_type_label or _HF_TYPE_LABELS.get(hf_type, ""),
        "is_header":         is_header,
        "extraction_source": "semantic",
        "rescue_activated":  False,
        "semantic_confidence": 0.0,
        "visual_confidence":   0.0,
    }

    if prefer_semantic and pdf_zone is not None:
        info = _merge_semantic_with_visual(
            info, pdf_zone, is_header, page_number=page_number)
    else:
        info["semantic_confidence"] = round(_semantic_confidence(info), 3)
        info["visual_confidence"]   = round(
            _visual_confidence(pdf_zone, is_header), 3)

    _release_hf_com_refs(rng)
    return info



#  FOOTER RESCUE


def rescue_first_page_footer(
    doc,
    pdf_zones: dict,
    total_pages: int = 0,
    page_start_cache: Optional[dict[int, int]] = None,
    doc_content_end: int = 0,
    doc_content_end_ref: Optional[dict[str, int]] = None,
) -> bool:
    """Move displaced first-page footer paragraphs back into the footer zone."""
    zone1 = pdf_zones.get(1)
    if not zone1 or not zone1["footer_block"].strip():
        _slog("  [rescue_footer] No footer text on PDF p1 - skip.")
        return False

    footer_block    = zone1["footer_block"]
    footer_lines    = zone1["footer_lines"]
    footer_zone_top = _footer_zone_top_pt(zone1)
    fingerprints    = build_fingerprints(footer_block)
    _slog(f"  [rescue_footer] fingerprints: {fingerprints}")

    doc.Sections(1).PageSetup.DifferentFirstPageHeaderFooter = True
    displaced = []
    total_pages = _resolve_total_pages(doc, pdf_zones, total_pages)
    bucket = _rescue_cache_bucket(doc, page_start_cache)
    if doc_content_end_ref is not None:
        bucket["content_end_ref"] = doc_content_end_ref
    elif doc_content_end:
        bucket["content_end"] = doc_content_end
        bucket["content_end_ref"] = {"value": doc_content_end}

    for search_page in (1, 2):
        _scan_page_for_displaced_footers(
            doc, search_page, 1, fingerprints, footer_zone_top,
            bucket, total_pages, displaced,
            log_prefix=f"p{search_page}",
        )

    if not displaced:
        _slog("  [rescue_footer] Nothing displaced.")
        return False

    try:
        fp_footer = doc.Sections(1).Footers(WD_HEADER_FOOTER_FIRST_PAGE)
        fp_footer.Range.Delete()
        rng = fp_footer.Range
        for i, line in enumerate(footer_lines):
            if i > 0:
                rng.InsertParagraphAfter()
                rng.Collapse(0)
            rng.InsertAfter(line["text"])
            if line.get("font_size") and line["font_size"] > 0:
                fp_footer.Range.Font.Size = line["font_size"]
        _slog(f"  [rescue_footer] Wrote {len(footer_lines)} line(s) to First-Page Footer.")
    except Exception as e:
        _slog(f"  [rescue_footer] write: {e}")

    deleted = 0
    for para in reversed(displaced):
        try:
            para.Range.Delete()
            deleted += 1
        except Exception:
            pass
    _slog(f"  [rescue_footer] Deleted {deleted} displaced para(s).")
    from src.services.pipeline.page_boundary import (
        invalidate_page_boundary_cache,
        refresh_content_end_after_mutation,
    )
    starts = bucket.get("starts", {})
    ref = bucket.get("content_end_ref", {"value": 0})
    refresh_content_end_after_mutation(
        doc, ref, cache=starts, invalidate_from=1,
        reason="rescue_first_page_footer",
    )
    return True


def rescue_page_footer(
    doc,
    page_num: int,
    section,
    h_type: int,
    pdf_zone: dict,
    total_pages: int = 0,
    page_start_cache: Optional[dict[int, int]] = None,
    doc_content_end: int = 0,
    doc_content_end_ref: Optional[dict[str, int]] = None,
) -> bool:
    """Rescue displaced footer for a single page (page 2+).

    PERFORMANCE: total_pages from pipeline; page-start cache avoids repeated
    GoTo/pagination; Information() only when fingerprint match fails.
    """
    if not pdf_zone or not pdf_zone.get("footer_block", "").strip():
        return False
    footer_rng  = safe_com(lambda: section.Footers(h_type).Range)
    if footer_rng is None:
        return False
    current_txt = safe_com(
        lambda: footer_rng.Text.strip().replace("\r", "").replace("\x07", ""),
        default="")
    if current_txt:
        return False

    fingerprints    = build_fingerprints(pdf_zone["footer_block"])
    footer_lines    = pdf_zone["footer_lines"]
    footer_zone_top = _footer_zone_top_pt(pdf_zone)
    total_pages     = _resolve_total_pages(doc, {}, total_pages)
    displaced       = []
    bucket = _rescue_cache_bucket(doc, page_start_cache)
    if doc_content_end_ref is not None:
        bucket["content_end_ref"] = doc_content_end_ref
    elif doc_content_end:
        bucket["content_end"] = doc_content_end
        bucket["content_end_ref"] = {"value": doc_content_end}

    search_pages = [page_num, min(page_num + 1, total_pages)]
    for search_page in search_pages:
        _scan_page_for_displaced_footers(
            doc, search_page, page_num, fingerprints, footer_zone_top,
            bucket, total_pages, displaced,
        )

    if not displaced:
        return False

    try:
        footer_rng.Delete()
        rng = section.Footers(h_type).Range
        for i, line in enumerate(footer_lines):
            if i > 0:
                rng.InsertParagraphAfter()
                rng.Collapse(0)
            rng.InsertAfter(line["text"])
            if line.get("font_size") and line["font_size"] > 0:
                section.Footers(h_type).Range.Font.Size = line["font_size"]
    except Exception as e:
        _slog(f"  [rescue_footer p{page_num}] write: {e}")

    for para in reversed(displaced):
        try:
            para.Range.Delete()
        except Exception:
            pass
    from src.services.pipeline.page_boundary import (
        refresh_content_end_after_mutation,
    )
    starts = bucket.get("starts", {})
    ref = bucket.get("content_end_ref", {"value": 0})
    refresh_content_end_after_mutation(
        doc, ref, cache=starts, invalidate_from=page_num,
        reason=f"rescue_page_footer_p{page_num}",
    )
    return True


def extract_layout_metadata(pdf_path: str, doc, output_folder: str,
                             base_name: str) -> str:
    """Extract page size + margin metadata and save JSON. Returns file path."""
    from src.constants.constant import SUFFIX_LAYOUT_META

    pdf_info: dict = {}
    if pdf_path and os.path.isfile(pdf_path):
        try:
            with pdfplumber.open(pdf_path) as pdf:
                for i, pg in enumerate(pdf.pages):
                    pdf_info[i + 1] = {
                        "pdf_width_pt":  float(pg.width),
                        "pdf_height_pt": float(pg.height),
                    }
        except Exception as e:
            _slog(f"  [layout_meta] PDF error: {e}")
    else:
        _slog("  [layout_meta] No PDF - skipping PDF size info.")

    data = []
    for i, sec in enumerate(doc.Sections):
        s = sec.PageSetup
        data.append({
            "page_section":                     i + 1,
            "original_pdf_size":                pdf_info.get(i + 1, "N/A"),
            "docx_page_height_inch":            round(pt_to_inch(s.PageHeight), 4),
            "docx_page_width_inch":             round(pt_to_inch(s.PageWidth),  4),
            "header_distance_from_top_inch":    round(pt_to_inch(s.HeaderDistance), 4),
            "footer_distance_from_bottom_inch": round(pt_to_inch(s.FooterDistance), 4),
            "top_margin_inch":                  round(pt_to_inch(s.TopMargin),    4),
            "bottom_margin_inch":               round(pt_to_inch(s.BottomMargin), 4),
        })

    path = os.path.join(output_folder, f"{base_name}{SUFFIX_LAYOUT_META}")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    _slog(f"  [layout_meta] JSON -> {os.path.basename(path)}")
    return path