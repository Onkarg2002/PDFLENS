from __future__ import annotations

from src.constants.constant import WD_IS_IN_TABLE
from src.utils.file_util import safe_com, ensure_dir
from src.services.extractors.extractor_com_safe import (
    extraction_scope,
    iter_com_collection,
    log_classified,
    normalize_word_text,
)

_MAX_PARAS_PER_PAGE = 5000


#  PAGE BODY TEXT
def _collect_table_spans(page_range) -> list[tuple[int, int]]:
    """
    Cache (Start, End) for every table intersecting *page_range*.
    Used instead of per-paragraph Information(WD_IS_IN_TABLE) when possible.
    """
    spans: list[tuple[int, int]] = []
    try:
        tables = page_range.Tables
        n      = int(safe_com(lambda: tables.Count, default=0) or 0)
    except Exception:
        return spans
    for tbl in iter_com_collection(tables, max_items=500, label="page_tables"):
        bounds = safe_com(
            lambda t=tbl: (int(t.Range.Start), int(t.Range.End)),
            default=None,
        )
        if bounds:
            spans.append(bounds)
    return spans


def _para_in_table_spans(para_start: int, spans: list[tuple[int, int]]) -> bool:
    """True when paragraph start falls inside any cached table span."""
    for start, end in spans:
        if start <= para_start < end:
            return True
    return False


def _apply_hl_tags(txt: str, hl_text_to_tag: dict[str, str]) -> str:
    """Replace hyperlink anchor strings with tags (one replace per anchor, in order)."""
    if not hl_text_to_tag:
        return txt
    for anchor, tag in hl_text_to_tag.items():
        if anchor and anchor in txt:
            txt = txt.replace(anchor, tag, 1)
    return txt


def _extract_para_line(
    para,
    hl_text_to_tag: dict[str, str],
    table_spans: list[tuple[int, int]],
    use_information_for_table: bool,
) -> dict | None:
    """
    One COM round-trip per paragraph: text + start + font/style (+ optional in-table).
    Returns a content_lines dict or None when the paragraph is empty.
    """
    if use_information_for_table:
        _packed = safe_com(
            lambda p=para: (
                p.Range.Text.strip(),
                int(p.Range.Start),
                str(p.Range.Font.Name),
                p.Range.Font.Size,
                p.Range.Font.Bold,
                p.Range.Font.Italic,
                p.Range.Style.NameLocal,
                bool(p.Range.Information(WD_IS_IN_TABLE)),
            ),
            default=None,
        )
        if not _packed:
            return None
        raw_txt, _start, f_name, f_size, f_bold, f_ital, s_name, in_tbl = _packed
    else:
        _packed = safe_com(
            lambda p=para: (
                p.Range.Text.strip(),
                int(p.Range.Start),
                str(p.Range.Font.Name),
                p.Range.Font.Size,
                p.Range.Font.Bold,
                p.Range.Font.Italic,
                p.Range.Style.NameLocal,
            ),
            default=None,
        )
        if not _packed:
            return None
        raw_txt, _start, f_name, f_size, f_bold, f_ital, s_name = _packed
        in_tbl = _para_in_table_spans(_start, table_spans) if table_spans else False

    raw_txt = normalize_word_text(raw_txt)
    if not raw_txt:
        return None

    return {
        "text":        _apply_hl_tags(raw_txt, hl_text_to_tag),
        "font_name":   f_name,
        "font_size":   float(f_size) if f_size and f_size > 0 else "Multiple",
        "is_bold":     bool(f_bold == -1),
        "is_italic":   bool(f_ital == -1),
        "style_name":  s_name,
        "is_in_table": in_tbl,
    }


def extract_page_text(
    page_range,
    extract_hyperlinks_flag: bool = True,
    hyperlink_counter:       int  = 1,
    page_number:             int  = 0,
    extract_tables:          bool = True,
) -> dict:
    """
    Extract text and hyperlinks from a COM page Range.

    When extract_hyperlinks_flag=True:
      - Each hyperlink found on this page gets ONE unique <doc_ai_hyperlink_N> tag
      - The tag replaces only the hyperlink's own anchor text in full_text
      - No URL matching, no nested scanning, no duplication

    When extract_hyperlinks_flag=False:
      - Hyperlinks stay as plain text; hyperlinks list is empty

    When extract_tables=False:
      - Skips table-span caching and sets is_in_table=False (no layout queries).
    """
    from src.services.extractors.hyperlink_extractor import extract_hyperlinks_from_range

    # Extract hyperlinks and assign tags
    if extract_hyperlinks_flag:
        hyperlinks, next_counter = extract_hyperlinks_from_range(
            page_range,
            page_number   = page_number,
            start_counter = hyperlink_counter,
        )
        hl_text_to_tag: dict[str, str] = {}
        for hl in hyperlinks:
            anchor = hl["text"]
            if anchor:
                hl_text_to_tag[anchor] = hl["tag"]
    else:
        hyperlinks     = []
        next_counter   = hyperlink_counter
        hl_text_to_tag = {}


    table_spans: list[tuple[int, int]] = []
    tables_count = 0
    use_information_for_table = False

    if extract_tables:
        tables_count = safe_com(lambda: page_range.Tables.Count, default=0) or 0
        if tables_count > 0:
            table_spans = _collect_table_spans(page_range)
            use_information_for_table = len(table_spans) == 0

    lines: list = []
    with extraction_scope(f"text_p{page_number}"):
        try:
            paras_coll = page_range.Paragraphs
        except Exception as exc:
            log_classified(exc, "Paragraphs")
            paras_coll = None

        if paras_coll is not None:
            for para in iter_com_collection(
                    paras_coll,
                    max_items=_MAX_PARAS_PER_PAGE,
                    label="Paragraphs",
            ):
                try:
                    line = _extract_para_line(
                        para,
                        hl_text_to_tag,
                        table_spans,
                        use_information_for_table,
                    )
                    if line:
                        lines.append(line)
                except Exception as exc:
                    log_classified(exc, f"para_p{page_number}")

    return {
        "content_lines":   lines,
        "hyperlinks":      hyperlinks,
        "tables_count":    tables_count,
        "next_hl_counter": next_counter,
    }



#  PAGE FULL TEXT ASSEMBLY

def build_page_full_text(
    content_lines:      list,
    page_hdr_text:      str,
    page_ftr_text:      str,
    extract_tables:     bool,
    extract_header:     bool = True,
    extract_footer:     bool = True,
    extract_images:     bool = True,
    extract_hyperlinks: bool = True,
    hyperlinks:         list = None,
    pdf_page_text:      str  = "",   
) -> str:
    """
    Build the full text string for one page.

    If extract_tables=True and every non-empty line is inside a table (table-only
    DOCX page), returns the pdf_page_text fallback instead of an empty string.
    This handles the case where a large table spans multiple DOCX pages but fits
    on one PDF page — the 'continuation' DOCX pages contain only table rows with
    no body paragraphs, so COM extraction yields nothing usable.
    """
    lines_out = []
    all_in_table = True   

    for line in content_lines:
        txt = line["text"].strip()
        if not txt:
            continue
        if extract_tables and line.get("is_in_table"):
            continue
        all_in_table = False
        if extract_header and page_hdr_text and txt == page_hdr_text:
            continue
        if extract_footer and page_ftr_text and txt == page_ftr_text:
            continue
        lines_out.append(txt)

    result = "\n".join(lines_out)

    if not result and pdf_page_text:
        result = pdf_page_text.strip()

    return result
