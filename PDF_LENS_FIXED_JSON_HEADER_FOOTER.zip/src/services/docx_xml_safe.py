"""
OpenXML safety layer for DOCX body mutation (used by docx_modifier).

Goals:
  - Validate OPC package before/after mutation
  - Preserve namespaces and run properties (w:rPr)
  - Handle drawings, VML, OLE, OMML, SmartArt-like graphics
  - Skip or cautiously handle tracked-change regions
  - Atomic save + backup recovery
"""
from __future__ import annotations

import os
import shutil
import zipfile
from typing import Callable, Optional
from lxml import etree
from src.utils.file_util import validate_docx_package
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.docx_xml_safe")

def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)


# ── Namespaces (ECMA-376 / ISO 29500) ─────────────────────────────────────────
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
MC_NS = "http://schemas.openxmlformats.org/markup-compatibility/2006"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
XML_NS = "http://www.w3.org/XML/1998/namespace"

W = f"{{{W_NS}}}"
M = f"{{{M_NS}}}"
MC = f"{{{MC_NS}}}"

TAG_BODY = f"{W}body"
TAG_P = f"{W}p"
TAG_R = f"{W}r"
TAG_T = f"{W}t"
TAG_RPR = f"{W}rPr"
TAG_TBL = f"{W}tbl"
TAG_TR = f"{W}tr"
TAG_TRPR = f"{W}trPr"
TAG_TRHEIGHT = f"{W}trHeight"
TAG_DRAWING = f"{W}drawing"
TAG_PICT = f"{W}pict"
TAG_OBJECT = f"{W}object"
TAG_ALT = f"{MC}AlternateContent"
TAG_HDR = f"{W}hdr"
TAG_FTR = f"{W}ftr"
TAG_TXBX = f"{W}txbxContent"
TAG_FTN = f"{W}footnote"
TAG_ENDN = f"{W}endnote"
TAG_INS = f"{W}ins"
TAG_DEL = f"{W}del"
TAG_MOVE_FROM = f"{W}moveFrom"
TAG_MOVE_TO = f"{W}moveTo"
TAG_SDT = f"{W}sdt"
TAG_OMATH_PARA = f"{M}oMathPara"
TAG_OMATH = f"{M}oMath"

TRACKED_ANCESTOR_TAGS = frozenset({
    TAG_INS, TAG_DEL, TAG_MOVE_FROM, TAG_MOVE_TO,
    f"{W}cellIns", f"{W}cellDel", f"{W}customXmlInsRangeStart",
})

PROTECTED_ANCESTOR_TAGS = frozenset({
    TAG_HDR, TAG_FTR, TAG_TXBX, TAG_FTN, TAG_ENDN,
})

GRAPHIC_URI_SMARTART = "http://schemas.openxmlformats.org/drawingml/2006/diagram"
GRAPHIC_URI_CHART = "http://schemas.openxmlformats.org/drawingml/2006/chart"
GRAPHIC_URI_PICTURE = "http://schemas.openxmlformats.org/drawingml/2006/picture"

_LOG: Callable[[str], None] = print

def set_modifier_logger(log_fn: Callable[[str], None]) -> None:
    global _LOG
    _LOG = log_fn

def _log(msg: str) -> None:
    try:
        _LOG(msg)
    except Exception:
        _slog(msg)


class DocxXmlValidationError(ValueError):
    """Raised when OPC/XML validation fails."""

def _w(local: str) -> str:
    return f"{W}{local}"

#  Validation

def validate_docx_package_deep(path: str, min_bytes: int = 512) -> None:
    """OPC + parse word/document.xml (recovering parser)."""
    validate_docx_package(path, min_bytes=min_bytes)
    path = os.path.abspath(path)
    with zipfile.ZipFile(path, "r") as zf:
        _parse_document_xml_bytes(zf.read("word/document.xml"), label=path)

def _parse_document_xml_bytes(data: bytes, label: str = "document.xml") -> etree._Element:
    if not data or not data.strip():
        raise DocxXmlValidationError(f"Empty {label}")
    parser = etree.XMLParser(recover=True, remove_blank_text=False, huge_tree=True)
    try:
        root = etree.fromstring(data, parser)
    except etree.XMLSyntaxError as exc:
        raise DocxXmlValidationError(f"Malformed XML in {label}: {exc}") from exc
    body = root if root.tag == TAG_BODY else root.find(f".//{TAG_BODY}")
    if body is None:
        raise DocxXmlValidationError(f"No w:body in {label}")
    return root

def validate_body_after_mutation(body: etree._Element) -> None:
    """
    Lightweight structural checks — not a full OOXML validator.
    Raises DocxXmlValidationError on fatal issues.
    """
    if body.tag != TAG_BODY:
        raise DocxXmlValidationError(f"Expected w:body, got {body.tag}")

    errors: list[str] = []
    for r in body.iter(TAG_R):
        texts = r.findall(TAG_T)
        if len(texts) > 1:
            errors.append("w:r with multiple w:t children (may confuse Word)")
            if len(errors) >= 5:
                break

    for t in body.iter(TAG_T):
        if t.text and "\x00" in t.text:
            errors.append("w:t contains NUL character")

    if errors:
        raise DocxXmlValidationError("; ".join(errors[:5]))

def validate_saved_docx(path: str) -> None:
    """Re-read package after save."""
    validate_docx_package_deep(path)

#  Backup / atomic IO

def backup_file(path: str, suffix: str = ".bak") -> str:
    path = os.path.abspath(path)
    bak = path + suffix
    shutil.copy2(path, bak)
    return bak


def restore_file(from_path: str, to_path: str) -> None:
    shutil.copy2(from_path, to_path)


def atomic_save_document(doc, dest_path: str) -> None:
    """Save python-docx Document via temp file then replace."""
    dest_path = os.path.abspath(dest_path)
    tmp = dest_path + ".tmp_save"
    parent = os.path.dirname(dest_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    try:
        doc.save(tmp)
        validate_saved_docx(tmp)
        if os.path.isfile(dest_path):
            os.remove(dest_path)
        os.replace(tmp, dest_path)
    except Exception:
        if os.path.isfile(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise

#  Context / classification

def _ancestor_tags(el: etree._Element) -> list[str]:
    tags: list[str] = []
    node = el
    while node is not None:
        tags.append(node.tag)
        node = node.getparent()
    return tags


def is_in_body(el: etree._Element, body: etree._Element) -> bool:
    for tag in _ancestor_tags(el):
        if tag == TAG_BODY:
            return True
        if tag in PROTECTED_ANCESTOR_TAGS:
            return False
    return False


def is_inside_tracked_change(el: etree._Element) -> bool:
    return any(t in TRACKED_ANCESTOR_TAGS for t in _ancestor_tags(el))


def classify_drawing(drawing: etree._Element) -> str:
    """Return image | smartart | chart | drawing."""
    A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
    GD = f"{{{A_NS}}}graphicData"
    for gd in drawing.iter(GD):
        uri = (gd.get("uri") or "").lower()
        if GRAPHIC_URI_SMARTART in uri or "diagram" in uri:
            return "smartart"
        if GRAPHIC_URI_CHART in uri or "chart" in uri:
            return "chart"
        if GRAPHIC_URI_PICTURE in uri:
            return "image"
    return "drawing"


def _find_containing_run(el: etree._Element, max_depth: int = 12) -> tuple[
    Optional[etree._Element], Optional[etree._Element]
]:
    """
    Return (w:r, direct_child_of_r_to_replace) for a visual node.
    direct_child may be w:drawing, mc:AlternateContent, w:pict, w:object.
    """
    node = el
    child = el
    depth = 0
    while node is not None and depth < max_depth:
        if node.tag == TAG_R:
            return node, child
        child = node
        node = node.getparent()
        depth += 1
    return None, None

#  Safe element builders (inherit nsmap)

def _nsmap_from(anchor: etree._Element) -> Optional[dict]:
    return getattr(anchor, "nsmap", None) or None


def make_text_run(tag_text: str, anchor: etree._Element) -> etree._Element:
    r = etree.Element(TAG_R, nsmap=_nsmap_from(anchor))
    t = etree.SubElement(r, TAG_T)
    t.set(f"{{{XML_NS}}}space", "preserve")
    t.text = tag_text
    return r


def make_placeholder_para(
    tag_text: str,
    height_pt: float,
    anchor: etree._Element,
    twips_per_pt: int = 20,
    min_h_pt: float = 10.0,
) -> etree._Element:
    p = etree.Element(TAG_P, nsmap=_nsmap_from(anchor))
    pPr = etree.SubElement(p, _w("pPr"))
    h_twips = max(int(height_pt * twips_per_pt), int(min_h_pt * twips_per_pt))
    sp = etree.SubElement(pPr, _w("spacing"))
    sp.set(_w("before"), "0")
    sp.set(_w("after"), "0")
    sp.set(_w("line"), str(h_twips))
    sp.set(_w("lineRule"), "exact")
    p.append(make_text_run(tag_text, anchor))
    return p


def replace_run_child_with_text(
    run: etree._Element,
    child_to_remove: etree._Element,
    tag_text: str,
) -> bool:
    """
    Remove one visual child of w:r (drawing, pict, object, AlternateContent)
    and insert a single w:t, preserving w:rPr and other non-visual children.
    """
    children = list(run)
    if child_to_remove not in children:
        # mc:AlternateContent may be ancestor — remove topmost matching child
        for c in children:
            if c.tag == TAG_ALT or c.tag == child_to_remove.tag:
                child_to_remove = c
                break
        else:
            return False

    idx = list(run).index(child_to_remove)
    run.remove(child_to_remove)

    # Collapse duplicate w:t if present at same index
    existing_t = run.find(TAG_T)
    if existing_t is not None:
        existing_t.text = (existing_t.text or "") + tag_text
        return True

    t = etree.Element(TAG_T, nsmap=_nsmap_from(run))
    t.set(f"{{{XML_NS}}}space", "preserve")
    t.text = tag_text
    run.insert(idx, t)
    return True


def replace_paragraph_child_with_run(
    para: etree._Element,
    child: etree._Element,
    tag_text: str,
) -> None:
    """Replace block-level child (e.g. m:oMathPara) with a w:r tag run."""
    idx = list(para).index(child)
    para.remove(child)
    para.insert(idx, make_text_run(tag_text, para))


#  Table height (unchanged logic, namespace-safe)

def table_height_pt(tbl_el: etree._Element, default_row_pt: float = 14.0) -> float:
    h_twips = 0
    rows = tbl_el.findall(f".//{TAG_TR}")
    for r in rows:
        trPr = r.find(TAG_TRPR)
        if trPr is not None:
            trH = trPr.find(TAG_TRHEIGHT)
            if trH is not None:
                try:
                    h_twips += int(trH.get(_w("val"), trH.get("val", 0)) or 0)
                except (TypeError, ValueError):
                    pass
    return (h_twips / 20.0) if h_twips else (len(rows) * default_row_pt)


#  Body replacements

def _tag_for_visual(kind: str, idx: int) -> str:
    return f'<doc_ai type="{kind}" id={idx}>'


def replace_body_drawings(
    body: etree._Element,
    start_idx: int = 1,
    *,
    include_tracked: bool = True,
) -> tuple[int, dict[str, int]]:
    """
    Replace w:drawing in body with placeholder tags.
    Returns (next_idx, stats).
    """
    stats = {"drawing": 0, "smartart": 0, "chart": 0, "skipped_tracked": 0,
             "skipped_protected": 0, "failed": 0}
    idx = start_idx

    for drawing in list(body.iter(TAG_DRAWING)):
        if not is_in_body(drawing, body):
            stats["skipped_protected"] += 1
            continue
        if not include_tracked and is_inside_tracked_change(drawing):
            stats["skipped_tracked"] += 1
            continue

        kind = classify_drawing(drawing)
        if kind == "smartart":
            stats["smartart"] += 1
        elif kind == "chart":
            stats["chart"] += 1
        else:
            stats["drawing"] += 1

        run, child = _find_containing_run(drawing)
        if run is None or child is None:
            stats["failed"] += 1
            continue

        tag_text = _tag_for_visual(
            "smartart" if kind == "smartart" else ("chart" if kind == "chart" else "image"),
            idx,
        )
        if replace_run_child_with_text(run, child, tag_text):
            idx += 1
        else:
            stats["failed"] += 1

    return idx, stats


def replace_body_vml_and_objects(
    body: etree._Element,
    start_idx: int = 1,
) -> tuple[int, dict[str, int]]:
    """Replace legacy w:pict and w:object in body."""
    stats = {"pict": 0, "object": 0, "skipped_tracked": 0, "failed": 0}
    idx = start_idx

    for tag, kind in ((TAG_PICT, "pict"), (TAG_OBJECT, "embedded")):
        for el in list(body.iter(tag)):
            if not is_in_body(el, body):
                continue
            if is_inside_tracked_change(el):
                stats["skipped_tracked"] += 1
                continue
            run, child = _find_containing_run(el)
            if run is None or child is None:
                stats["failed"] += 1
                continue
            tag_text = _tag_for_visual(kind, idx)
            stat_key = "pict" if kind == "pict" else "object"
            if replace_run_child_with_text(run, child, tag_text):
                stats[stat_key] += 1
                idx += 1
            else:
                stats["failed"] += 1

    return idx, stats


def replace_body_equations(
    body: etree._Element,
    start_idx: int = 1,
) -> tuple[int, dict[str, int]]:
    """
    Replace m:oMathPara (and standalone m:oMath in paragraphs) with tag runs.
    OMML is not inside w:drawing — must be handled separately.
    """
    stats = {"oMathPara": 0, "oMath": 0, "skipped_tracked": 0, "failed": 0}
    idx = start_idx

    for omath_para in list(body.iter(TAG_OMATH_PARA)):
        if not is_in_body(omath_para, body):
            continue
        if is_inside_tracked_change(omath_para):
            stats["skipped_tracked"] += 1
            continue
        parent = omath_para.getparent()
        if parent is None:
            stats["failed"] += 1
            continue
        tag_text = _tag_for_visual("equation", idx)
        try:
            if parent.tag == TAG_P:
                replace_paragraph_child_with_run(parent, omath_para, tag_text)
            else:
                run, child = _find_containing_run(omath_para)
                if run and child:
                    replace_run_child_with_text(run, child, tag_text)
                else:
                    parent.remove(omath_para)
                    parent.insert(0, make_text_run(tag_text, parent))
            stats["oMathPara"] += 1
            idx += 1
        except (ValueError, IndexError):
            stats["failed"] += 1

    for omath in list(body.iter(TAG_OMATH)):
        if omath.getparent() is not None and omath.getparent().tag == TAG_OMATH_PARA:
            continue
        if not is_in_body(omath, body) or is_inside_tracked_change(omath):
            continue
        parent = omath.getparent()
        if parent is None or parent.tag != TAG_P:
            continue
        tag_text = _tag_for_visual("equation", idx)
        try:
            replace_paragraph_child_with_run(parent, omath, tag_text)
            stats["oMath"] += 1
            idx += 1
        except (ValueError, IndexError):
            stats["failed"] += 1

    return idx, stats


def replace_body_tables(body: etree._Element) -> tuple[int, dict[str, int]]:
    """
    Replace top-level w:tbl in body (not nested tables).
    Skips tables inside tracked-change wrappers to avoid revision corruption.
    """
    stats = {"replaced": 0, "skipped_tracked": 0, "skipped_nested": 0}
    tables = [c for c in list(body) if c.tag == TAG_TBL]

    for i, tbl_el in enumerate(tables, start=1):
        if is_inside_tracked_change(tbl_el):
            stats["skipped_tracked"] += 1
            continue
        tag_text = _tag_for_visual("table", i)
        height_pt = table_height_pt(tbl_el)
        placeholder = make_placeholder_para(tag_text, height_pt, body)
        pos = list(body).index(tbl_el)
        body.insert(pos, placeholder)
        body.remove(tbl_el)
        stats["replaced"] += 1

    return stats["replaced"], stats


def apply_safe_body_mutations(
    body: etree._Element,
    *,
    replace_images: bool = True,
    replace_tables: bool = True,
) -> dict[str, dict[str, int]]:
    """
    Run all body replacements in a safe order:
      equations → VML/OLE → drawings (avoids double-counting runs)
    """
    summary: dict[str, dict[str, int]] = {}
    idx = 1

    if replace_images:
        idx, eq_stats = replace_body_equations(body, idx)
        summary["equations"] = eq_stats
        idx, ole_stats = replace_body_vml_and_objects(body, idx)
        summary["vml_object"] = ole_stats
        idx, dr_stats = replace_body_drawings(body, idx, include_tracked=True)
        summary["drawings"] = dr_stats

    if replace_tables:
        n, tbl_stats = replace_body_tables(body)
        summary["tables"] = tbl_stats

    validate_body_after_mutation(body)
    return summary
