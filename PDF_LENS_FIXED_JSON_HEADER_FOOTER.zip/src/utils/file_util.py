import os
import re
import time
import uuid
import shutil
import functools
import configparser
from pathlib import Path
from typing import Any, Callable, Optional
from src.constants.constant import ALLOWED_EXTENSIONS, RPC_E_CALL_REJECTED

from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.utils.file_util")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)


_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_DEFAULT_CONFIG = str(_PROJECT_ROOT / "config" / "config.properties")


def load_config(config_path: str = _DEFAULT_CONFIG) -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    if not os.path.isfile(config_path):
        _slog(f"  [config] WARNING: config file not found at {config_path}")
    else:
        cfg.read(config_path)
        _slog(f"  [config] Loaded → {config_path}")
    return cfg


_CONFIG: Optional[configparser.ConfigParser] = None

def get_config() -> configparser.ConfigParser:
    global _CONFIG
    if _CONFIG is None:
        _CONFIG = load_config()
    return _CONFIG


# ── Path helpers 

def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def build_job_dirs(base_output_dir: str, job_id: str) -> dict:
    job_dir    = ensure_dir(os.path.join(base_output_dir, job_id))
    tables_dir = ensure_dir(os.path.join(job_dir, "table_screenshots"))
    images_dir = ensure_dir(os.path.join(job_dir, "extracted_images"))
    return {
        "job_dir":    job_dir,
        "upload_dir": job_dir,  
        "tables_dir": tables_dir,
        "images_dir": images_dir,
    }


def new_job_id(pdf_name: str = "") -> str:
    """Return a job-folder name: [4-char uuid][first 10 chars of pdf stem]."""
    short_uuid = uuid.uuid4().hex[:4]
    stem = Path(pdf_name).stem if pdf_name else ""
    safe_stem = re.sub(r"[^A-Za-z0-9_\-]", "_", stem)[:10]
    return short_uuid + safe_stem


def clean_job_dir(job_dir: str) -> None:
    """Remove a job's working directory after the response is sent."""
    try:
        if os.path.isdir(job_dir):
            shutil.rmtree(job_dir, ignore_errors=True)
    except Exception:
        pass


def get_file_extension(filename: str) -> str:
    return Path(filename).suffix.lower()


def is_allowed_file(filename: str) -> bool:
    return get_file_extension(filename) in ALLOWED_EXTENSIONS


def safe_unlink(path: Optional[str]) -> bool:
    """Remove a file if it exists; return True when removed."""
    if not path:
        return False
    try:
        if os.path.isfile(path):
            os.remove(path)
            return True
    except OSError:
        pass
    return False


def atomic_replace(temp_path: str, final_path: str) -> str:
    """
    Atomically publish *temp_path* as *final_path* (same-directory replace).
    Caller must write only to *temp_path* first; on failure temp may remain.
    """
    temp_path = os.path.abspath(temp_path)
    final_path = os.path.abspath(final_path)
    parent = os.path.dirname(final_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    if not os.path.isfile(temp_path):
        raise FileNotFoundError(f"Atomic replace source missing: {temp_path}")
    if os.path.isfile(final_path):
        os.remove(final_path)
    os.replace(temp_path, final_path)
    return final_path


def validate_input_file(path: str, ext: str, min_bytes: int = 1) -> int:
    """
    Validate upload exists, extension matches, and size >= min_bytes.
    Returns file size in bytes.
    """
    path = os.path.abspath(path)
    if not os.path.isfile(path):
        raise ValueError(f"Input file not found: {path}")
    size = os.path.getsize(path)
    if size < min_bytes:
        raise ValueError(f"Input file is empty or too small ({size} bytes): {path}")
    expected = get_file_extension(path)
    if ext and expected != ext.lower():
        raise ValueError(
            f"Input extension mismatch: path has {expected!r}, expected {ext!r}"
        )
    if ext == ".pdf":
        with open(path, "rb") as fh:
            if fh.read(5) != b"%PDF-":
                raise ValueError(f"File is not a valid PDF (missing %PDF- header): {path}")
    return size


def validate_docx_package(path: str, min_bytes: int = 512) -> None:
    """
    Validate that *path* is a readable DOCX OPC package (ZIP with word/document.xml).
    Raises ValueError on corrupt or non-DOCX files.
    """
    import zipfile

    path = os.path.abspath(path)
    if not os.path.isfile(path):
        raise ValueError(f"DOCX not found: {path}")
    size = os.path.getsize(path)
    if size < min_bytes:
        raise ValueError(f"DOCX too small to be valid ({size} bytes): {path}")
    try:
        with zipfile.ZipFile(path, "r") as archive:
            if "word/document.xml" not in archive.namelist():
                raise ValueError(f"Missing word/document.xml — not a valid DOCX: {path}")
            with archive.open("word/document.xml") as doc_xml:
                header = doc_xml.read(64)
                if not header:
                    raise ValueError(f"Empty word/document.xml in DOCX: {path}")
    except zipfile.BadZipFile as exc:
        raise ValueError(f"Corrupt or non-ZIP DOCX: {path}") from exc


def _is_com_busy(exc: Exception) -> bool:
    try:
        if hasattr(exc, "hresult") and exc.hresult == RPC_E_CALL_REJECTED:
            return True
        if (hasattr(exc, "excepinfo") and exc.excepinfo and
                len(exc.excepinfo) > 5 and
                exc.excepinfo[5] == RPC_E_CALL_REJECTED):
            return True
    except Exception:
        pass
    return (str(RPC_E_CALL_REJECTED) in str(exc) or
            "callee" in str(exc).lower())


def com_retry(max_retries: int = 5, base_delay: float = 0.5):
    """Decorator that retries a COM call when Word returns RPC_E_CALL_REJECTED."""
    def decorator(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            delay = base_delay
            for attempt in range(max_retries + 1):
                try:
                    return fn(*args, **kwargs)
                except Exception as exc:
                    if attempt < max_retries and _is_com_busy(exc):
                        _slog(f"    [COM busy] {fn.__name__} retry "
                              f"{attempt+1}/{max_retries} in {delay:.1f}s …")
                        time.sleep(delay)
                        delay = min(delay * 2, 5.0)
                    else:
                        raise
        return wrapper
    return decorator


def safe_com(fn: Callable, default: Any = None, label: str = "") -> Any:
    """Call fn() and return default on any exception (with optional logging)."""
    try:
        return fn()
    except Exception as exc:
        if label:
            _slog(f"    [safe_com] {label}: {exc}")
        return default


# Text helpers 

def pt_to_inch(pt: float) -> float:
    return (pt / 72.0) if pt else 0.0


def clean_word_text(text: str) -> str:
    if text is None:
        return ""
    text = text.replace("\r", " ")
    text = text.replace("\n", " ")
    text = text.replace("\t", " ")
    text = text.replace("\x07", "")
    text = " ".join(text.split())
    return text


def sanitize_cell(text: str) -> str:
    if not isinstance(text, str):
        return text
    text = text.replace("\r", " ").replace("\x07", "")
    text = re.sub(r"[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]", "", text)
    text = re.sub(r"\[\s{2,}\]", "[]", text)
    return text.strip()


def _clean_fp(t: str) -> str:
    t = re.sub(r"[^\w\s@.:,/+\-]", " ", t.lower())
    return re.sub(r"\s+", " ", t).strip()


def build_fingerprints(block: str, min_word_len: int = 5) -> list:
    words = [w for w in _clean_fp(block).split() if len(w) >= min_word_len]
    seen, out = set(), []
    for w in words:
        if w not in seen:
            seen.add(w); out.append(w)
    return out[:12]


def para_matches_fingerprints(para_text: str, fingerprints: list,
                               threshold: int = 2) -> bool:
    if not fingerprints or not para_text:
        return False
    cleaned = _clean_fp(para_text)
    return sum(1 for fp in fingerprints if fp in cleaned) >= threshold