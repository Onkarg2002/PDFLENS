"""
Enterprise structured JSON logging for PDF_LENS.

Every log line is a single JSON object on stdout with:
  - timestamp (ISO-8601 UTC)
  - level, service, component, event
  - request_id, job_id, worker_id (process pid in worker pool)
  - duration_ms when using LogTimer or passed explicitly
  - worker restart / timeout diagnostics when in worker context

Configure once per process via configure_logging().
"""
from __future__ import annotations

import json
import logging
import os
import sys
import time
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Callable, Optional

_SERVICE_NAME = "pdf_lens"
_CONFIGURED = False

_ctx_request_id: ContextVar[Optional[str]] = ContextVar("request_id", default=None)
_ctx_job_id: ContextVar[Optional[str]] = ContextVar("job_id", default=None)
_ctx_component: ContextVar[Optional[str]] = ContextVar("component", default=None)


_worker_diagnostics_provider: Optional[Callable[[], dict]] = None


def register_worker_diagnostics_provider(fn: Callable[[], dict]) -> None:
    """Called from worker.py at import to attach restart counters to logs."""
    global _worker_diagnostics_provider
    _worker_diagnostics_provider = fn


def bind_context(
    *,
    request_id: Optional[str] = None,
    job_id: Optional[str] = None,
    component: Optional[str] = None,
) -> None:
    if request_id is not None:
        _ctx_request_id.set(request_id)
    if job_id is not None:
        _ctx_job_id.set(job_id)
    if component is not None:
        _ctx_component.set(component)


def clear_context() -> None:
    _ctx_request_id.set(None)
    _ctx_job_id.set(None)
    _ctx_component.set(None)


def get_context() -> dict[str, Any]:
    return {
        "request_id": _ctx_request_id.get(),
        "job_id": _ctx_job_id.get(),
        "component": _ctx_component.get(),
        "worker_id": os.getpid(),
        "process_pid": os.getpid(),
    }


def new_request_id() -> str:
    return str(uuid.uuid4())


class JsonLogFormatter(logging.Formatter):
    """Emit one JSON object per log record (no duplicate print)."""

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "service": _SERVICE_NAME,
            "logger": record.name,

        }

        ctx = get_context()
        if ctx.get("request_id"):
            payload["request_id"] = ctx["request_id"]
        if ctx.get("job_id"):
            payload["job_id"] = ctx["job_id"]
        if ctx.get("component"):
            payload["component"] = ctx["component"]

        msg = record.getMessage()
        if msg:
            payload["msg"] = msg

        extra = getattr(record, "structured_fields", None)
        if isinstance(extra, dict):
            for k, v in extra.items():
                if k not in payload and v is not None:
                    payload[k] = v

        if record.exc_info and record.exc_info[1]:
            payload["exception"] = str(record.exc_info[1])
            payload["exception_type"] = type(record.exc_info[1]).__name__

        return json.dumps(payload, default=str, ensure_ascii=False)


def configure_logging(
    *,
    level: int = logging.INFO,
    stream: Any = None,
) -> None:
    """Idempotent root setup — JSON lines to stdout."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    stream = stream if stream is not None else sys.stdout
    handler = logging.StreamHandler(stream)
    handler.setFormatter(JsonLogFormatter())

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)

    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "fastapi"):
        lg = logging.getLogger(name)
        lg.handlers.clear()
        lg.propagate = True

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    if not _CONFIGURED:
        configure_logging()
    return logging.getLogger(name)


def _merge_worker_diagnostics(fields: dict[str, Any], include_diagnostics: bool) -> None:
    if not include_diagnostics or _worker_diagnostics_provider is None:
        return
    try:
        diag = _worker_diagnostics_provider()
        if not diag:
            return
        fields["worker_diagnostics"] = {
            k: diag.get(k)
            for k in (
                "pid", "jobs_ok", "jobs_failed", "jobs_in_batch",
                "word_launches", "word_restarts", "forced_kills",
                "stale_com_events", "hang_recoveries", "cancelled_jobs",
                "dismiss_clicks", "last_error", "tracked_winword_pids",
                "word_proxy_alive",
            )
            if k in diag
        }
    except Exception:
        pass


def log_event(
    logger: logging.Logger,
    event: str,
    msg: str = "",
    *,
    level: int = logging.INFO,
    duration_ms: Optional[float] = None,
    include_worker_diagnostics: bool = False,
    **fields: Any,
) -> None:
    """
    Primary structured log API.

    Examples:
        log_event(logger, "job_start", job_id=jid, file=name)
        log_event(logger, "timeout", msg="HTTP wait exceeded", timeout_s=1800, level=logging.WARNING)
    """
    payload = dict(fields)
    if duration_ms is not None:
        payload["duration_ms"] = round(float(duration_ms), 2)
    if msg:
        payload.setdefault("msg", msg)
    _merge_worker_diagnostics(payload, include_worker_diagnostics)

    record = logger.makeRecord(
        logger.name,
        level,
        "(structured)",
        0,
        msg or event,
        (),
        None,
    )
    record.event = event
    record.structured_fields = payload
    logger.handle(record)


class LogTimer:
    """Context manager — logs completion with duration_ms."""

    def __init__(
        self,
        logger: logging.Logger,
        event: str,
        msg: str = "",
        *,
        level: int = logging.INFO,
        log_start: bool = False,
        include_worker_diagnostics: bool = False,
        **fields: Any,
    ):
        self._logger = logger
        self._event = event
        self._msg = msg
        self._level = level
        self._fields = fields
        self._log_start = log_start
        self._include_diag = include_worker_diagnostics
        self._t0 = 0.0

    def __enter__(self) -> "LogTimer":
        self._t0 = time.perf_counter()
        if self._log_start:
            log_event(
                self._logger,
                f"{self._event}_start",
                self._msg,
                level=self._level,
                include_worker_diagnostics=self._include_diag,
                **self._fields,
            )
        return self

    def __exit__(self, exc_type, exc, tb) -> bool:
        elapsed_ms = (time.perf_counter() - self._t0) * 1000.0
        fields = dict(self._fields)
        fields["duration_ms"] = round(elapsed_ms, 2)
        if exc is not None:
            fields["error"] = str(exc)
            fields["exception_type"] = type(exc).__name__
            log_event(
                self._logger,
                f"{self._event}_error",
                self._msg,
                level=logging.ERROR,
                include_worker_diagnostics=self._include_diag,
                **fields,
            )
            return False
        log_event(
            self._logger,
            self._event,
            self._msg,
            level=self._level,
            include_worker_diagnostics=self._include_diag,
            **fields,
        )
        return False


@contextmanager
def pipeline_log_mirror():
    """Bind pipeline component for nested document_pipeline logs."""
    prev = _ctx_component.get()
    _ctx_component.set("pipeline")
    try:
        yield
    finally:
        _ctx_component.set(prev)


def log_timeout(
    logger: logging.Logger,
    *,
    kind: str,
    timeout_s: float,
    elapsed_s: Optional[float] = None,
    job_id: Optional[str] = None,
    request_id: Optional[str] = None,
    include_worker_diagnostics: bool = False,
    **fields: Any,
) -> None:
    """Dedicated timeout diagnostic event."""
    log_event(
        logger,
        "timeout",
        msg=f"{kind} timeout after {timeout_s}s",
        level=logging.WARNING,
        timeout_kind=kind,
        timeout_s=timeout_s,
        elapsed_s=round(elapsed_s, 2) if elapsed_s is not None else None,
        job_id=job_id or _ctx_job_id.get(),
        request_id=request_id or _ctx_request_id.get(),
        include_worker_diagnostics=include_worker_diagnostics,
        **fields,
    )
