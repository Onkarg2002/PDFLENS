from fastapi import APIRouter, UploadFile, File, Form, status, Request
from fastapi.responses import FileResponse
from src.controller.convert_controller import handle_convert
from src.schema.convert_schema import ErrorResponseSchema

router = APIRouter(prefix="/api/v1", tags=["PDF-LENS"])


@router.post(
    "/convert",
    status_code=status.HTTP_200_OK,
    summary="Convert and extract content from a PDF or Word document",
    response_class=FileResponse,
    responses={
        200: {
            "content": {"application/zip": {}},
            "description": "ZIP archive containing the processed .docx and meta .json files",
        },
        400: {"model": ErrorResponseSchema, "description": "Invalid file type"},
        500: {"model": ErrorResponseSchema, "description": "Extraction error"},
    },
)
async def convert_document(
    request: Request,
    file: UploadFile = File(
        ...,
        description="PDF or Word document (.pdf / .docx / .doc)",
    ),
    extract_tables: bool = Form(
        True,
        description="Extract table grids, screenshots, and Excel export",
    ),
    extract_images: bool = Form(
        True,
        description="Extract and save embedded images",
    ),
    extract_header: bool = Form(
        True,
        description="Extract header zone content into header_text field",
    ),
    extract_footer: bool = Form(
        True,
        description="Extract footer zone content into footer_text field",
    ),
    extract_hyperlinks: bool = Form(
        True,
        description="Extract hyperlinks/URLs found in the document",
    ),
    extract_footnote: bool = Form(
        False,
        description="Extract footnotes from the document",
    ),
) -> FileResponse:

    return await handle_convert(
        request=request,
        file=file,
        extract_tables=extract_tables,
        extract_images=extract_images,
        extract_header=extract_header,
        extract_footer=extract_footer,
        extract_hyperlinks=extract_hyperlinks,
        extract_footnote=extract_footnote,
    )