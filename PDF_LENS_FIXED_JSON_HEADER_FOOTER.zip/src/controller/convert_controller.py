from __future__ import annotations
import asyncio
import os
import shutil
import traceback
import functools
from worker import worker_task
from typing import Optional
from dataclasses import dataclass, field
from concurrent.futures import Future, TimeoutError as _FutureTimeoutError
from fastapi import BackgroundTasks, HTTPException, UploadFile, status, Request
from fastapi.responses import FileResponse
from src.utils.file_util import (build_job_dirs, get_config, get_file_extension, is_allowed_file, new_job_id,)
from src.utils.structured_log import (bind_context, configure_logging, get_logger, log_event, log_timeout, new_request_id,)

configure_logging()
_LOG = get_logger("pdf_lens.controller")
_DEFAULT_MAX_UPLOAD_BYTES: int = 100 * 1024 * 1024   # 100 MiB
_DEFAULT_JOB_TIMEOUT_S: float = 1800.0               # 30 minutes
_STREAM_CHUNK_BYTES: int = 1024 * 1024               # 1 MiB read buffer
_MAX_FILENAME_LEN: int = 255


# Config helpers
def _output_base() -> str:
    return get_config().get("paths", "output_dir", fallback="./data/outputs")


def _max_upload_bytes() -> int:
    cfg = get_config()
    raw = cfg.get("upload", "max_upload_bytes", fallback="") or cfg.get(
        "app", "max_upload_bytes", fallback=str(_DEFAULT_MAX_UPLOAD_BYTES))
    try:
        return max(1, int(raw))
    except (TypeError, ValueError):
        return _DEFAULT_MAX_UPLOAD_BYTES

def _job_timeout_s() -> float:
    cfg = get_config()
    raw = cfg.get("app", "job_timeout_s", fallback=str(_DEFAULT_JOB_TIMEOUT_S))
    try:
        return max(30.0, float(raw))
    except (TypeError, ValueError):
        return _DEFAULT_JOB_TIMEOUT_S

# Structured logging

def _log(event: str, msg: str = "", **fields) -> None:
    log_event(_LOG, event, msg=msg, component="controller", **fields)

# Upload session & cleanup

def _safe_unlink(path: Optional[str]) -> bool:
    if not path:
        return False
    try:
        if os.path.isfile(path):
            os.remove(path)
            return True
    except OSError as exc:
        _log("cleanup_unlink_failed", path=path, error=str(exc))
    return False


def _safe_rmtree(path: Optional[str]) -> bool:
    if not path or not os.path.isdir(path):
        return False
    try:
        shutil.rmtree(path, ignore_errors=True)
        return True
    except OSError as exc:
        _log("cleanup_rmtree_failed", path=path, error=str(exc))
    return False


def _sanitize_filename(name: Optional[str]) -> str:
    if not name:
        return "upload"
    base = os.path.basename(name.replace("\\", "/").replace("\x00", ""))
    base = base.strip() or "upload"
    return base[:_MAX_FILENAME_LEN]


@dataclass
class _JobSession:
    job_id: str
    job_dir: str
    upload_path: str
    cancel_flag_path: str
    filename: str
    worker_future: Optional[Future] = field(default=None, repr=False)
    worker_submitted: bool = False
    timed_out: bool = False

    def write_cancel_flag(self, reason: str = "cancelled") -> None:
        try:
            with open(self.cancel_flag_path, "w", encoding="utf-8") as fh:
                fh.write(f"{reason}\n")
        except OSError as exc:
            _log("cancel_flag_failed", job_id=self.job_id, error=str(exc))

    def cleanup_upload_if_worker_done(self) -> None:
        if self.worker_future is not None and not self.worker_future.done():
            return
        if _safe_unlink(self.upload_path):
            _log("upload_removed", job_id=self.job_id, path=self.upload_path)

    def cleanup_pre_submit_failure(self) -> None:
        """Validation/stream errors before worker starts — remove entire job dir."""
        _safe_unlink(self.upload_path)
        _safe_rmtree(self.job_dir)
        _log("job_dir_removed_pre_submit", job_id=self.job_id)


async def _stream_upload_to_disk(
    upload: UploadFile,
    dest_path: str,
    max_bytes: int,
) -> int:
    """
    Stream UploadFile to *dest_path* without loading the whole body into RAM.
    Raises HTTP 413 if size exceeds *max_bytes*.
    """
    total = 0
    parent = os.path.dirname(dest_path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    try:
        with open(dest_path, "wb") as out:
            while True:
                chunk = await upload.read(_STREAM_CHUNK_BYTES)
                if not chunk:
                    break
                total += len(chunk)
                if total > max_bytes:
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=(
                            f"Upload exceeds maximum allowed size of "
                            f"{max_bytes} bytes ({max_bytes // (1024 * 1024)} MiB)."
                        ),
                    )
                out.write(chunk)
    except HTTPException:
        _safe_unlink(dest_path)
        raise
    except Exception as exc:
        _safe_unlink(dest_path)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to store upload: {exc}",
        ) from exc

    if total == 0:
        _safe_unlink(dest_path)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Uploaded file is empty.",
        )
    return total


async def _await_future(future: Future, timeout_s: float) -> dict:
    """
    Await a ProcessPoolExecutor Future without blocking the asyncio event loop.
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None,
        functools.partial(future.result, timeout=timeout_s),
    )


def _schedule_upload_cleanup_when_done(
    future: Future,
    upload_path: str,
    job_id: str,
) -> None:
    """
    If HTTP returned before the worker finished, delete the upload file once the
    worker process completes (success, error, or hang recovery).
    """

    async def _wait_and_cleanup() -> None:
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, future.result)
        except Exception as exc:
            _log(
                "deferred_cleanup_worker_finished",
                job_id=job_id,
                error=str(exc),
            )
        finally:
            if _safe_unlink(upload_path):
                _log("deferred_upload_removed", job_id=job_id, path=upload_path)

    try:
        asyncio.get_running_loop().create_task(_wait_and_cleanup())
    except RuntimeError:
        pass

# Response builder

def _build_success_response(
    raw: dict,
    job_id: str,
    job_dir: str,
    background_tasks: BackgroundTasks,
) -> FileResponse:
    """
    Return the output ZIP as a downloadable FileResponse.
    The job directory (containing the ZIP) is deleted after the response is sent.
    """
    saved = raw.get("saved_files", {}) or {}
    zip_path = saved.get("zip_location")

    if not zip_path or not os.path.isfile(zip_path):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"ZIP file not found at expected path: {zip_path!r}",
        )

    zip_filename = os.path.basename(zip_path)   # e.g. "3c9e14.zip"

    # Clean up the job directory from disk after the ZIP has been streamed
    background_tasks.add_task(_safe_rmtree, job_dir)
    _log("zip_response_ready", job_id=job_id, zip_path=zip_path)

    return FileResponse(
        path=zip_path,
        media_type="application/zip",
        filename=zip_filename,          # sets Content-Disposition: attachment; filename="3c9e14.zip"
    )

# Public handler

async def handle_convert(
    request: Request,
    file: UploadFile,
    extract_tables: bool,
    extract_images: bool,
    extract_header: bool,
    extract_footer: bool,
    extract_hyperlinks: bool,
    extract_footnote: bool = False,
) -> FileResponse:
    executor = getattr(request.app.state, "executor", None)
    max_bytes = _max_upload_bytes()
    timeout_s = _job_timeout_s()

    safe_name = _sanitize_filename(file.filename)
    if not is_allowed_file(safe_name):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                "Unsupported file type. Only PDF and Word documents accepted. "
                f"Got: '{safe_name}'"
            ),
        )

    if executor is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Worker pool is not ready. Try again in a moment.",
        )

    if getattr(request.app.state, "shutting_down", False):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Server is shutting down. Try again later.",
        )

    request_id = request.headers.get("X-Request-ID") or new_request_id()
    bind_context(request_id=request_id, component="controller")

    job_id = new_job_id(safe_name)
    bind_context(job_id=job_id)
    dirs = build_job_dirs(_output_base(), job_id)
    job_dir = dirs["job_dir"]
    ext = get_file_extension(safe_name) or ".pdf"
    upload_path = os.path.join(job_dir, f"_upload{ext}")
    cancel_flag_path = os.path.join(job_dir, f".cancel_{job_id}")

    session = _JobSession(
        job_id=job_id,
        job_dir=job_dir,
        upload_path=os.path.abspath(upload_path),
        cancel_flag_path=cancel_flag_path,
        filename=safe_name,
    )

    _log(
        "convert_start",
        job_id=job_id,
        filename=safe_name,
        max_upload_bytes=max_bytes,
        timeout_s=timeout_s,
    )

    try:
        size_bytes = await _stream_upload_to_disk(file, session.upload_path, max_bytes)
        _log("upload_stored", job_id=job_id, size_bytes=size_bytes, path=session.upload_path)

        payload = {
            "job_id": job_id,
            "request_id": request_id,
            "file_path": session.upload_path,
            "filename": safe_name,
            "output_folder": os.path.abspath(job_dir),
            "extract_tables": extract_tables,
            "extract_images": extract_images,
            "extract_header": extract_header,
            "extract_footer": extract_footer,
            "extract_hyperlinks": extract_hyperlinks,
            "extract_footnote": extract_footnote,
            "cancel_flag_path": cancel_flag_path,
        }

        session.worker_future = executor.submit(worker_task, payload)
        session.worker_submitted = True
        _log("worker_submitted", job_id=job_id)

        try:
            worker_result = await _await_future(session.worker_future, timeout_s=timeout_s)
        except _FutureTimeoutError:
            session.timed_out = True
            session.write_cancel_flag("timeout")
            session.worker_future.cancel()
            log_timeout(
                _LOG,
                kind="convert_job",
                timeout_s=timeout_s,
                job_id=job_id,
                request_id=request_id,
                note="cancel_flag_set; worker may still run until cooperative exit",
            )
            _schedule_upload_cleanup_when_done(
                session.worker_future,
                session.upload_path,
                job_id,
            )
            raise HTTPException(
                status_code=status.HTTP_504_GATEWAY_TIMEOUT,
                detail=(
                    f"Conversion timed out after {timeout_s:.0f}s. "
                    "The document may be too large or Word became unresponsive."
                ),
            )

        session.cleanup_upload_if_worker_done()

        if worker_result.get("status") == "error":
            _log(
                "worker_error",
                job_id=job_id,
                error=worker_result.get("error"),
            )
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Extraction failed: {worker_result.get('error')}",
            )

        raw = worker_result.get("result")
        if not raw:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Worker returned success but no result payload.",
            )

        try:
            background_tasks = BackgroundTasks()
            response = _build_success_response(
                raw=raw,
                job_id=job_id,
                job_dir=session.job_dir,
                background_tasks=background_tasks,
            )
        except HTTPException:
            raise
        except Exception as exc:
            tb = traceback.format_exc()
            _log("response_build_error", job_id=job_id, error=str(exc), traceback=tb)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to build response: {exc}",
            ) from exc

        _log("convert_success", job_id=job_id, total_pages=raw.get("total_pages", 0))
        return response

    except HTTPException:
        if not session.worker_submitted:
            session.cleanup_pre_submit_failure()
        raise

    except Exception as exc:
        tb = traceback.format_exc()
        _log("convert_unexpected_error", job_id=job_id, error=str(exc), traceback=tb)
        if not session.worker_submitted:
            session.cleanup_pre_submit_failure()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Worker process failed: {exc}",
        ) from exc

    finally:
        try:
            await file.close()
        except Exception:
            pass
        if session.worker_submitted and not session.timed_out:
            session.cleanup_upload_if_worker_done()