import gc
import logging
import multiprocessing
import os
import time
import traceback
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)

_DEFAULT_JOB_TIMEOUT_S = 300   
_MAX_BATCH_SIZE        = 8     
_WORD_RESTART_COOLDOWN = 3.0 

# JOB DESCRIPTOR

@dataclass
class ConversionJob:
    job_id:             str
    file_path:          str
    filename:           str
    output_folder:      str
    extract_tables:     bool = True
    extract_images:     bool = True
    extract_header:     bool = True
    extract_footer:     bool = True
    extract_hyperlinks: bool = True
    extract_footnote:   bool = False
    result:      Optional[dict]      = field(default=None, repr=False)
    error:       Optional[Exception] = field(default=None, repr=False)
    queued_at:   float               = field(default_factory=time.monotonic, repr=False)
    started_at:  Optional[float]     = field(default=None, repr=False)
    finished_at: Optional[float]     = field(default=None, repr=False)

# WORKER PROCESS FUNCTION  (no threading — runs in its own OS process)

def _worker_process_main(
    jobs: list[dict],
    result_q: "multiprocessing.Queue",
) -> None:
    """
    Entry-point for each worker Process.

    Receives a list of serialised job dicts, processes them one by one,
    and puts result dicts into result_q.  Runs entirely on its own main
    thread — no threads created inside this function.

    COM is initialised once on this thread and uninitialised at exit.
    Word is kept alive across all jobs in the batch (persistent instance).
    """
    com_init = False
    word     = None

    def _com_initialize():
        nonlocal com_init
        # Suppress "Word will now convert your PDF…" popup before Word launches
        try:
            import winreg
            hive = winreg.HKEY_CURRENT_USER
            base = r"SOFTWARE\Microsoft\Office"
            for ver in ("16.0", "15.0", "14.0"):
                path = rf"{base}\{ver}\Word\Options"
                try:
                    with winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE) as k:
                        winreg.SetValueEx(k, "DontWarnPDFToWord", 0, winreg.REG_DWORD, 1)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            import pythoncom
            pythoncom.CoInitialize()
            com_init = True
        except ImportError:
            pass

    def _com_uninitialize():
        if com_init:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass

    def _launch() -> Any:
        """Create Word.Application with performance flags."""
        import win32com.client
        w = win32com.client.DispatchEx("Word.Application")
        w.Visible        = False
        w.DisplayAlerts  = 0
        w.ScreenUpdating = False
        for attr, val in [("DisplayStatusBar", False)]:
            try:
                setattr(w, attr, val)
            except Exception:
                pass
        for opt, val in [
            ("Pagination",                       False),
            ("CheckSpellingAsYouType",           False),
            ("CheckGrammarAsYouType",            False),
            ("CheckGrammarWithSpelling",         False),
            ("ShowReadabilityStatistics",        False),
            ("AutoFormatAsYouTypeApplyHeadings", False),
            ("AutoFormatAsYouTypeApplyBullets",  False),
        ]:
            try:
                setattr(w.Options, opt, val)
            except Exception:
                pass
        return w

    def _quit(w) -> None:
        if w is not None:
            try:
                w.Quit()
            except Exception:
                pass
            try:
                del w
            except Exception:
                pass
        gc.collect()

    _com_initialize()

    try:
        word = _launch()
        logger.info("[COMWorker/proc] pid=%s Word launched", os.getpid())

        for job_dict in jobs:
            job_id = job_dict.get("job_id", "unknown")
            started = time.monotonic()
            try:
                from src.services.document_service import process_document
                res = process_document(
                    file_path          = job_dict["file_path"],
                    filename           = job_dict["filename"],
                    output_folder      = job_dict["output_folder"],
                    extract_tables     = job_dict["extract_tables"],
                    extract_images     = job_dict["extract_images"],
                    extract_header     = job_dict["extract_header"],
                    extract_footer     = job_dict["extract_footer"],
                    extract_hyperlinks = job_dict["extract_hyperlinks"],
                    extract_footnote   = job_dict["extract_footnote"],
                )
                elapsed = time.monotonic() - started
                result_q.put({
                    "job_id":  job_id,
                    "status":  "success",
                    "result":  res,
                    "error":   None,
                    "elapsed": elapsed,
                })
                logger.info("[COMWorker/proc] job=%s done in %.1fs", job_id, elapsed)
            except Exception as exc:
                elapsed = time.monotonic() - started
                tb = traceback.format_exc()
                logger.error("[COMWorker/proc] job=%s failed: %s", job_id, exc)
                result_q.put({
                    "job_id":  job_id,
                    "status":  "error",
                    "result":  None,
                    "error":   str(exc),
                    "elapsed": elapsed,
                })

            gc.collect()

    finally:
        _quit(word)
        _com_uninitialize()
        logger.info("[COMWorker/proc] pid=%s exiting cleanly", os.getpid())


# COM QUEUE WORKER  — threading-free facade

class COMQueueWorker:
    """
    Threading-free COM worker.  Each submitted job runs in an isolated
    OS process (multiprocessing.Process).  No threads are created anywhere.

    The public API (start, stop, submit, queue_depth, stats) is unchanged
    from v2 so callers need no modifications.

    Usage (unchanged from v2):
        worker = COMQueueWorker()
        worker.start()
        result = worker.submit(job)
        worker.stop()
        info   = worker.stats
    """

    def __init__(
        self,
        maxsize:       int   = 0,
        job_timeout_s: float = _DEFAULT_JOB_TIMEOUT_S,
    ) -> None:
        self._job_timeout_s = job_timeout_s
        self._pending_jobs:  list[ConversionJob] = []
        self._started = False

        # Stats (written only from submit(), single-caller assumption)
        self._stats: dict[str, Any] = {
            "jobs_processed":  0,
            "jobs_failed":     0,
            "jobs_timed_out":  0,
            "current_job":     None,
            "worker_restarts": 0,
            "batch_count":     0,
        }

    # Lifecycle 

    def start(self) -> None:
        """No background thread to start — processes are spawned per-submit."""
        self._started = True
        logger.info(
            "[COMWorker] started (threading-free, timeout=%ss, batch=%s)",
            self._job_timeout_s, _MAX_BATCH_SIZE,
        )

    def stop(self, timeout: float = 60.0) -> None:
        """No-op: no background thread or process to stop."""
        self._started = False
        logger.info("[COMWorker] stopped")

    # public API 

    def submit(self, job: ConversionJob) -> dict:
        """
        Run *job* in an isolated OS process.  Block until it completes or
        times out.  Returns the result dict or raises on error.

        No threads are created.  The spawned Process runs _worker_process_main
        which initialises COM on its own main thread.
        """
        if not self._started:
            raise RuntimeError("COMQueueWorker is not running. Call .start() first.")

        job.started_at = time.monotonic()
        self._stats["current_job"] = job.job_id

        # Serialise job to a plain dict for IPC
        job_dict = {
            "job_id":             job.job_id,
            "file_path":          job.file_path,
            "filename":           job.filename,
            "output_folder":      job.output_folder,
            "extract_tables":     job.extract_tables,
            "extract_images":     job.extract_images,
            "extract_header":     job.extract_header,
            "extract_footer":     job.extract_footer,
            "extract_hyperlinks": job.extract_hyperlinks,
            "extract_footnote":   job.extract_footnote,
        }

        ctx      = multiprocessing.get_context("spawn")
        result_q = ctx.Queue()
        proc     = ctx.Process(
            target = _worker_process_main,
            args   = ([job_dict], result_q),
            name   = f"COMWorker-{job.job_id}",
            daemon = False,  
        )

        proc.start()
        proc.join(timeout=self._job_timeout_s)

        job.finished_at = time.monotonic()
        elapsed = job.finished_at - job.started_at
        self._stats["current_job"] = None
        self._stats["batch_count"] += 1

        # ── Timeout ─────────────────────────────────────────────────────
        if proc.is_alive():
            logger.error(
                "[COMWorker] job=%s TIMED OUT after %.1fs — terminating process",
                job.job_id, elapsed,
            )
            proc.terminate()
            proc.join(timeout=10)
            if proc.is_alive():
                proc.kill()
            self._stats["jobs_timed_out"] += 1
            self._stats["jobs_failed"]    += 1
            job.error = TimeoutError(
                f"Conversion timed out after {self._job_timeout_s:.0f}s"
            )
            raise job.error

        #  Collect result 
        try:
            outcome = result_q.get_nowait()
        except Exception:
            job.error = RuntimeError(
                f"Worker process for job {job.job_id} exited without a result "
                f"(exit code {proc.exitcode})"
            )
            self._stats["jobs_failed"] += 1
            raise job.error

        if outcome.get("status") == "error":
            job.error = RuntimeError(outcome.get("error", "unknown error"))
            self._stats["jobs_failed"] += 1
            raise job.error

        self._stats["jobs_processed"] += 1
        job.result = outcome["result"]
        return job.result 

    @property
    def queue_depth(self) -> int:
        """Always 0: each job is dispatched immediately to its own process."""
        return 0

    @property
    def stats(self) -> dict:
        return dict(self._stats)
