from pydantic import BaseModel
from typing import List, Optional

class BoundingBox(BaseModel):
    x0: float
    y0: float
    x1: float
    y1: float

class Paragraph(BaseModel):
    text: str
    bbox: Optional[BoundingBox] = None
    block_type: Optional[str] = "text"

class HeaderCandidate(BaseModel):
    text: str
    bbox: Optional[BoundingBox] = None
    confidence: float = 0.0

class FooterCandidate(BaseModel):
    text: str
    bbox: Optional[BoundingBox] = None
    confidence: float = 0.0

class ImagePlaceholder(BaseModel):
    tag: str
    bbox: Optional[BoundingBox] = None

class TablePlaceholder(BaseModel):
    tag: str
    bbox: Optional[BoundingBox] = None

class Footnote(BaseModel):
    footnote_index: int
    reference_text: str
    text: str
    bbox: Optional[BoundingBox] = None

class Hyperlink(BaseModel):
    text: str
    url: str
    bbox: Optional[BoundingBox] = None

class PageLayout(BaseModel):
    page_number: int
    width: float
    height: float
    paragraphs: List[Paragraph] = []
    headers: List[HeaderCandidate] = []
    footers: List[FooterCandidate] = []
    images: List[ImagePlaceholder] = []
    tables: List[TablePlaceholder] = []
    footnotes: List[Footnote] = []
    hyperlinks: List[Hyperlink] = []

class DocumentLayout(BaseModel):
    total_pages: int
    pages: List[PageLayout] = []

    def find_true_page_for_text(self, query_text: str, hint_page: int) -> int:
        """
        Searches the PyMuPDF parsed layout for a text snippet and returns the true page number.
        Falls back to hint_page if not found or query is too short.
        """
        if not query_text:
            return hint_page
            
        import re
        
        # Normalize: lowercase and remove all non-alphanumeric whitespace sequences
        norm_query = re.sub(r'\s+', '', query_text.lower())
        
        if len(norm_query) < 5:
            return hint_page
            
        def search_page(page_num: int) -> bool:
            page = next((p for p in self.pages if p.page_number == page_num), None)
            if not page:
                return False
                
            page_text = ""
            for p in page.paragraphs:
                page_text += p.text
            for f in page.footnotes:
                page_text += f.text
                
            norm_page_text = re.sub(r'\s+', '', page_text.lower())
            return norm_query in norm_page_text

        # 1. Search the hint page first
        if search_page(hint_page):
            return hint_page
            
        # 2. Search adjacent pages
        if search_page(hint_page - 1):
            return hint_page - 1
        if search_page(hint_page + 1):
            return hint_page + 1
            
        # 3. Search all other pages
        for page in self.pages:
            pn = page.page_number
            if pn not in (hint_page, hint_page - 1, hint_page + 1):
                if search_page(pn):
                    return pn
                    
        return hint_page
