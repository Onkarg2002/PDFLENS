from pydantic import BaseModel
from typing import Optional, Dict, List


class HyperlinkSchema(BaseModel):
    """Single hyperlink entry."""
    page_number: int
    text:        str = ""
    url:         str = ""
    sub_address: str = ""


class PageResultSchema(BaseModel):
    """Per-page extraction result returned in the API response."""
    page_number:  int
    full_text:    str
    header_text:  Optional[str] = None   
    footer_text:  Optional[str] = None   
    tables_count: Optional[int] = None   
    images_count: Optional[int] = None 


class FootnoteSchema(BaseModel):
    """Single footnote entry."""
    footnote_index: int
    page_number:    int
    reference_text: str = ""
    text:           str = ""


class ConvertResponseSchema(BaseModel):
    status:      str = "success"
    saved_files: Optional[Dict[str, Optional[str]]] = None


class ErrorResponseSchema(BaseModel):
    status:  str = "error"
    message: str
    detail:  Optional[str] = None