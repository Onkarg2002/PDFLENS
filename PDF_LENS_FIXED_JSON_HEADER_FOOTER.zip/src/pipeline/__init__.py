# src/pipeline/__init__.py
# New performance optimization layer — wraps existing logic without modifying it.
