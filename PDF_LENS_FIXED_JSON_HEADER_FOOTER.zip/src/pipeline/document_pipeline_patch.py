from __future__ import annotations
import logging
logger = logging.getLogger(__name__)

def apply_pipeline_patch() -> None:
    logger.info(
        "[Patch] apply_pipeline_patch() called — patch is now native in "
        "document_pipeline.py; this call is a no-op."
    )
