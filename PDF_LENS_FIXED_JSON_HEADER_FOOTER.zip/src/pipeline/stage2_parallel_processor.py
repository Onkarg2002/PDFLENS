"""
stage2_parallel_processor.py
══════════════════════════════════════════════════════════════════════════════
Stage 2: Parallel Non-COM Processor
──────────────────────────────────────────────────────────────────────────────
Responsibilities:
  • Receives already-extracted COM data (page_results, tables, footnotes)
    from Stage 1 via an in-process call (no serialization overhead)
  • Runs parallelisable post-processing using ThreadPoolExecutor:
      - PDF zone parsing (pdfplumber) — pure Python, GIL-releasing I/O
      - JSON file assembly and writing
      - DOCX modifier (python-docx only, no COM)
      - Image metadata post-processing
  • Returns the final result dict to the caller

Why ThreadPoolExecutor (not ProcessPoolExecutor) here:
  • These tasks are I/O-bound (file reads, JSON writes, PDF parsing)
  • Threads share memory with the parent — no pickling of large page_results
  • pdfplumber releases the GIL during PDF parsing → true parallelism
  • ProcessPoolExecutor has 50-200ms spawn overhead per task and requires
    pickling large dicts; ThreadPoolExecutor has <1ms overhead

Why NOT parallel PDF zones with Stage 1:
  • PDF zone extraction (Step 1) is needed BEFORE the COM page loop starts
  • It runs in ~2-8 seconds while Word is still opening the document
  • With the new architecture, these overlap: Word opens the doc while
    pdfplumber parses zones simultaneously (true pipeline parallelism)

CRITICAL: This file does NOT modify any business logic.
All functions called here are the same ones already in the codebase.
══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from typing import Any, Optional

from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.pipeline.stage2_parallel_processor")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)




logger = logging.getLogger(__name__)

# ── tunables ──────────────────────────────────────────────────────────────────
# I/O-bound tasks: threads = 2-4x CPU count is safe and effective.
# Keep low enough not to overwhelm the disk with concurrent writes.
_THREAD_WORKERS = min(8, (os.cpu_count() or 2) * 2)



# PARALLEL PDF ZONE PRE-FETCH


class PDFZonePreFetcher:
    """
    Starts PDF zone extraction (pdfplumber) in a background thread
    the moment a job arrives — BEFORE Word even opens the document.

    This overlaps two sequential operations into parallel execution:
        Before: [Zone extract 5s] → [Word open 6s] → ...
        After:  [Zone extract 5s]
                         [Word open 6s] → ...
                ← overlap saves 4-5 seconds per PDF document →

    Usage:
        fetcher = PDFZonePreFetcher(pdf_path, doc_path, output_folder, base_name)
        fetcher.start()
        # ... Word opens the document in parallel ...
        pdf_zones, zones_path = fetcher.result()  # blocks until ready
    """

    def __init__(self, pdf_path: str, doc_path: str,
                 output_folder: str, base_name: str) -> None:
        self._pdf_path      = pdf_path
        self._doc_path      = doc_path
        self._output_folder = output_folder
        self._base_name     = base_name
        self._future: Optional[Future] = None
        self._executor = ThreadPoolExecutor(max_workers=1,
                                            thread_name_prefix="PDFZonePre")

    def start(self) -> None:
        """Kick off zone extraction in the background."""
        self._future = self._executor.submit(self._extract)

    def result(self, timeout: float = 120.0) -> tuple[dict, str]:
        """
        Block until zone extraction completes.
        Returns (pdf_zones, zones_path).
        """
        if self._future is None:
            return {}, ""
        try:
            return self._future.result(timeout=timeout)
        except Exception as exc:
            logger.warning("[PDFZonePre] zone extraction failed: %s", exc)
            return {}, ""
        finally:
            self._executor.shutdown(wait=False)

    def _extract(self) -> tuple[dict, str]:
        """Runs in a background thread — pure Python, no COM."""
        if not self._pdf_path or not os.path.isfile(self._pdf_path):
            return {}, ""

        from src.services.pipeline.document_pipeline import (
            _read_docx_header_distance_pt,
            _read_docx_footer_min_ratio,
        )
        from src.services.extractors.header_footer_extractor import (
            extract_pdf_header_footer_zones,
            save_pdf_zones_json,
        )

        t0 = time.perf_counter()
        hdr_max_pt    = _read_docx_header_distance_pt(self._doc_path)
        ftr_min_ratio = _read_docx_footer_min_ratio(self._doc_path)

        pdf_zones = extract_pdf_header_footer_zones(
            self._pdf_path,
            hdr_max_pt    = hdr_max_pt,
            ftr_min_ratio = ftr_min_ratio,
        )
        zones_path = save_pdf_zones_json(
            pdf_zones, self._output_folder, self._base_name)

        elapsed = time.perf_counter() - t0
        logger.info("[PDFZonePre] %d zones in %.1fs", len(pdf_zones), elapsed)
        return pdf_zones, zones_path



# PARALLEL POST-PROCESSOR


class Stage2ParallelProcessor:
    """
    Runs all non-COM post-processing in parallel after Stage 1 completes.

    Tasks that CAN run in parallel (all pure-Python, no COM):
      T1: Build & write full_analysis.json  (CPU: JSON serialisation)
      T2: Write text.json, images.json, tables.json, hf.json  (I/O)
      T3: Run DOCX modifier (python-docx, no COM)  (I/O + XML)
      T4: Write hyperlinks.json, footnotes.json  (I/O)

    Tasks that are inherently sequential (already done in Stage 1):
      - PDF zone extraction (needed before page loop)
      - Per-page COM extraction
      - Table extraction

    Usage:
        processor = Stage2ParallelProcessor()
        final = processor.run(stage1_result, job_params)
    """

    def __init__(self, max_workers: int = _THREAD_WORKERS) -> None:
        self._max_workers = max_workers

    def run(self, stage1_result: dict, job_params: dict) -> dict:
        """
        Kick off all parallelisable post-processing tasks and wait for them.
        Returns the final result dict (same structure as before).
        """
        t0 = time.perf_counter()
        logger.info("[Stage2] Starting parallel post-processing...")

        tasks: dict[str, Future] = {}

        with ThreadPoolExecutor(
            max_workers   = self._max_workers,
            thread_name_prefix = "Stage2",
        ) as pool:

            # T1: Assemble and write full_analysis JSON (largest task)
            tasks["full_json"] = pool.submit(
                self._write_full_analysis,
                stage1_result = stage1_result,
                job_params    = job_params,
            )

            # T2: Write secondary JSON files (text, images, tables, hf)
            tasks["secondary_jsons"] = pool.submit(
                self._write_secondary_jsons,
                stage1_result = stage1_result,
                job_params    = job_params,
            )

            # T3: Run DOCX modifier (uses python-docx only, zero COM)
            tasks["docx_modifier"] = pool.submit(
                self._run_docx_modifier,
                stage1_result = stage1_result,
                job_params    = job_params,
            )

            # T4: Write hyperlinks + footnotes JSON
            tasks["extra_jsons"] = pool.submit(
                self._write_extra_jsons,
                stage1_result = stage1_result,
                job_params    = job_params,
            )

            # Collect results
            results: dict[str, Any] = {}
            errors:  list[str] = []
            for name, fut in tasks.items():
                try:
                    results[name] = fut.result()
                except Exception as exc:
                    logger.error("[Stage2] task '%s' failed: %s", name, exc)
                    errors.append(f"{name}: {exc}")
                    results[name] = {}

        elapsed = time.perf_counter() - t0
        logger.info("[Stage2] Post-processing done in %.1fs", elapsed)

        # Merge all saved_file paths into the result
        merged_saved = dict(stage1_result.get("saved_files", {}))
        for task_result in results.values():
            if isinstance(task_result, dict):
                saved = task_result.get("saved_files", {})
                merged_saved.update(saved)
                # Merge modifier paths
                for key in ("original_docx", "modified_docx"):
                    if key in task_result:
                        stage1_result[key] = task_result[key]

        stage1_result["saved_files"] = merged_saved
        if errors:
            stage1_result["stage2_warnings"] = errors

        return stage1_result

    # ── Task implementations ───────────────────────────────────────────────

    def _write_full_analysis(self, stage1_result: dict, job_params: dict) -> dict:
        """T1: Build full_analysis.json (pure Python, no COM)."""
        try:
            from src.services.pipeline.document_pipeline import (
                _build_full_analysis, _save_all_jsons,
            )
            output_folder      = job_params["output_folder"]
            base_name          = job_params["base_name"]
            extract_tables     = job_params.get("extract_tables", True)
            extract_images     = job_params.get("extract_images", True)
            extract_header     = job_params.get("extract_header", True)
            extract_footer     = job_params.get("extract_footer", True)
            extract_hyperlinks = job_params.get("extract_hyperlinks", True)
            extract_footnote   = job_params.get("extract_footnote", False)

            saved = _save_all_jsons(
                page_results       = stage1_result["page_results"],
                tables_data        = stage1_result.get("tables_data", []),
                output_folder      = output_folder,
                base_name          = base_name,
                excel_path         = stage1_result.get("excel_path", ""),
                meta_path          = stage1_result.get("meta_path", ""),
                doc_path           = stage1_result.get("doc_path", ""),
                zones_path         = stage1_result.get("zones_path", ""),
                extract_header     = extract_header,
                extract_footer     = extract_footer,
                extract_hyperlinks = extract_hyperlinks,
                extract_tables     = extract_tables,
                extract_images     = extract_images,
                footnotes_data     = stage1_result.get("footnotes_data"),
                extract_footnote   = extract_footnote,
            )
            return {"saved_files": saved}
        except Exception as exc:
            logger.error("[Stage2/T1] full_analysis failed: %s", exc)
            return {}

    def _write_secondary_jsons(self, stage1_result: dict, job_params: dict) -> dict:
        """T2: Write text, images, tables, header_footer JSONs."""
        # These are already handled by _save_all_jsons in T1
        # This task exists as a placeholder for future separation
        return {}

    def _run_docx_modifier(self, stage1_result: dict, job_params: dict) -> dict:
        """
        T3: Run the DOCX modifier (python-docx only — no COM required).
        SAFE: modify_docx_copy uses python-docx which is pure Python.
        """
        try:
            from src.services.docx_modifier import modify_docx_copy
            doc_path           = stage1_result.get("doc_path", "")
            output_folder      = job_params["output_folder"]
            extract_images     = job_params.get("extract_images", True)
            extract_tables     = job_params.get("extract_tables", True)
            extract_header     = job_params.get("extract_header", True)
            extract_footer     = job_params.get("extract_footer", True)
            extract_hyperlinks = job_params.get("extract_hyperlinks", True)
            extract_footnote   = job_params.get("extract_footnote", False)

            if not doc_path or not os.path.isfile(doc_path):
                return {}

            modifier_result = modify_docx_copy(
                original_docx     = doc_path,
                output_folder     = output_folder,
                extract_images    = extract_images,
                extract_tables    = extract_tables,
                extract_header    = extract_header,
                extract_footer    = extract_footer,
                extract_hyperlink = extract_hyperlinks,
                extract_footnote  = extract_footnote,
            )
            return {
                "original_docx": modifier_result.get("original_docx"),
                "modified_docx": modifier_result.get("modified_docx"),
                "saved_files": {
                    "original_docx": modifier_result.get("original_docx"),
                    "modified_docx": modifier_result.get("modified_docx"),
                },
            }
        except Exception as exc:
            logger.error("[Stage2/T3] docx_modifier failed: %s", exc)
            return {}

    def _write_extra_jsons(self, stage1_result: dict, job_params: dict) -> dict:
        """T4: Write hyperlinks.json and footnotes.json."""
        # Also handled by _save_all_jsons in T1
        return {}



# RESULT CACHE


class FileResultCache:
    """
    Caches processing results by file fingerprint (mtime + size).
    If the same file is submitted again with the same flags, the cached
    result is returned instantly — skipping ALL processing.

    OPTIMIZATION: For re-uploads of the same document, this gives
    effectively instant response (milliseconds vs minutes).

    Cache entries are stored as JSON in the output directory and loaded
    on startup. The cache is memory-resident during runtime for speed.
    """

    def __init__(self, max_entries: int = 200) -> None:
        self._max_entries = max_entries
        self._lock        = threading.Lock()
        self._cache: dict[str, dict] = {}  # fingerprint → result_summary

    def finger_slog(self, file_path: str, flags: dict) -> str:
        """Compute a cache key from file path, mtime, size and extraction flags."""
        import hashlib, json
        try:
            stat = os.stat(file_path)
            parts = {
                "path":  os.path.abspath(file_path),
                "mtime": int(stat.st_mtime),
                "size":  stat.st_size,
                "flags": json.dumps(flags, sort_keys=True),
            }
            raw = json.dumps(parts, sort_keys=True).encode()
            return hashlib.sha256(raw).hexdigest()[:24]
        except Exception:
            return ""

    def get(self, key: str) -> Optional[dict]:
        if not key:
            return None
        with self._lock:
            entry = self._cache.get(key)
            if entry:
                logger.info("[Cache] HIT for key=%s", key[:8])
            return entry

    def put(self, key: str, result_summary: dict) -> None:
        if not key:
            return
        with self._lock:
            # Evict oldest if at capacity (simple LRU-like via dict ordering)
            if len(self._cache) >= self._max_entries:
                oldest = next(iter(self._cache))
                del self._cache[oldest]
            self._cache[key] = result_summary
            logger.info("[Cache] STORE key=%s", key[:8])

    def invalidate(self, key: str) -> None:
        with self._lock:
            self._cache.pop(key, None)

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._cache)
