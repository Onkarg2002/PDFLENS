from __future__ import annotations
import gc
import logging
import os
import queue
import threading
import time
from concurrent.futures import Future
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)

_WORD_LAUNCH_TIMEOUT_S = 120.0   
_JOB_TIMEOUT_S         = 1800.0 
_TICKER_INTERVAL_S     = 3.0    
_WATCHDOG_INTERVAL_S   = 2.0    
_WORD_RESTART_COOLDOWN = 5.0   


@dataclass
class COMJob:
    job_id:             str
    pdf_path:           str
    doc_path:           str
    output_folder:      str
    base_name:          str
    extract_tables:     bool = True
    extract_images:     bool = True
    extract_header:     bool = True
    extract_footer:     bool = True
    extract_hyperlinks: bool = True
    extract_footnote:   bool = False
    # Set by orchestrator after completion
    result:  Optional[dict]      = field(default=None, repr=False)
    error:   Optional[Exception] = field(default=None, repr=False)
    done:    threading.Event     = field(default_factory=threading.Event, repr=False)
    queued_at:   float = field(default_factory=time.monotonic, repr=False)
    started_at:  Optional[float] = field(default=None, repr=False)
    finished_at: Optional[float] = field(default=None, repr=False)



class _PersistentWordInstance:

    def __init__(self):
        self._word = None
        self._task_q: queue.Queue = queue.Queue()
        self._thread: Optional[threading.Thread] = None
        self._ready = threading.Event()
        self._init_error: Optional[Exception] = None

    def start(self) -> None:
        """Launch the STA thread and wait for Word to be ready."""
        self._thread = threading.Thread(
            target=self._sta_loop,
            name="WordSTA-Persistent",
            daemon=True,
        )
        self._thread.start()

        ready = self._ready.wait(timeout=_WORD_LAUNCH_TIMEOUT_S)
        if not ready:
            raise TimeoutError("Word failed to launch within timeout")
        if self._init_error:
            raise self._init_error

    def stop(self) -> None:
        """Quit Word and stop the STA thread."""
        done_fut: Future = Future()
        self._task_q.put(("_quit", done_fut))
        try:
            done_fut.result(timeout=30)
        except Exception:
            pass
        if self._thread:
            self._thread.join(timeout=10)

    def run(self, fn: Callable, label: str = "COM call",
            timeout: float = 600.0) -> Any:
        """
        Submit fn(word) to the STA thread and block until it completes.
        fn receives the Word.Application COM object.
        """
        fut: Future = Future()
        self._task_q.put(("_call", fn, fut))

        t0 = time.perf_counter()
        while True:
            remaining = timeout - (time.perf_counter() - t0)
            if remaining <= 0:
                raise TimeoutError(f"COM call '{label}' timed out")
            try:
                return fut.result(timeout=min(_TICKER_INTERVAL_S, remaining))
            except Exception as exc:
                from concurrent.futures import TimeoutError as _FT
                if isinstance(exc, _FT):
                    elapsed = time.perf_counter() - t0
                    logger.debug("[COM] '%s' running %.1fs...", label, elapsed)
                    continue
                raise

    def is_alive(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def _sta_loop(self) -> None:
        """The actual STA thread — all COM objects live here."""
        try:
            import pythoncom
            pythoncom.CoInitialize()
        except ImportError:
            pass  

        try:
            self._launch_word()
            self._ready.set()

            while True:
                try:
                    item = self._task_q.get(timeout=1.0)
                except queue.Empty:
                    continue

                kind = item[0]

                if kind == "_call":
                    _, fn, fut = item
                    try:
                        fut.set_result(fn(self._word))
                    except Exception as exc:
                        fut.set_exception(exc)

                elif kind == "_quit":
                    _, fut = item
                    try:
                        self._quit_word()
                        fut.set_result(True)
                    except Exception as exc:
                        fut.set_exception(exc)
                    break

                elif kind == "_restart_word":
                    _, fut = item
                    try:
                        self._quit_word()
                        time.sleep(_WORD_RESTART_COOLDOWN)
                        self._launch_word()
                        fut.set_result(True)
                    except Exception as exc:
                        fut.set_exception(exc)

        except Exception as exc:
            self._init_error = exc
            self._ready.set()
        finally:
            try:
                import pythoncom
                pythoncom.CoUninitialize()
            except Exception:
                pass

    def _launch_word(self) -> None:
        # Suppress "Word will now convert your PDF…" popup before Word launches
        try:
            import winreg
            hive = winreg.HKEY_CURRENT_USER
            base = r"SOFTWARE\Microsoft\Office"
            for ver in ("16.0", "15.0", "14.0"):
                path = rf"{base}\{ver}\Word\Options"
                try:
                    with winreg.CreateKeyEx(hive, path, 0, winreg.KEY_SET_VALUE) as k:
                        winreg.SetValueEx(k, "DontWarnPDFToWord", 0, winreg.REG_DWORD, 1)
                except Exception:
                    pass
        except Exception:
            pass

        import win32com.client
        self._word = win32com.client.Dispatch("Word.Application")

        self._word.Visible        = False   
        self._word.DisplayAlerts  = 0      
        self._word.ScreenUpdating = False   

        try:
            self._word.DisplayStatusBar = False 
        except Exception:
            pass
        try:
            self._word.Options.Pagination = False  
        except Exception:
            pass

        logger.info("[PersistentWord] Word.Application launched")

    def _quit_word(self) -> None:
        if self._word is not None:
            try:
                self._word.Quit()
            except Exception:
                pass
            del self._word
            self._word = None


class Stage1COMOrchestrator:

    def __init__(self, job_timeout_s: float = _JOB_TIMEOUT_S) -> None:
        self._job_timeout_s = job_timeout_s
        self._job_q: queue.Queue[Optional[COMJob]] = queue.Queue()
        self._word = _PersistentWordInstance()
        self._dispatcher_thread: Optional[threading.Thread] = None
        self._watchdog_thread:   Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._started = False

        # Stats
        self._stats_lock = threading.Lock()
        self._stats: dict[str, Any] = {
            "jobs_processed": 0,
            "jobs_failed":    0,
            "word_restarts":  0,
            "current_job":    None,
        }


    def start(self) -> None:
        if self._started:
            return
        logger.info("[Stage1] Starting COM orchestrator...")
        self._stop_event.clear()

        
        self._word.start()
        logger.info("[Stage1] Word.Application ready")

        # Start the job dispatcher (reads from _job_q, drives Word)
        self._dispatcher_thread = threading.Thread(
            target=self._dispatcher_loop,
            name="Stage1-Dispatcher",
            daemon=True,
        )
        self._dispatcher_thread.start()

        # Start watchdog
        self._watchdog_thread = threading.Thread(
            target=self._watchdog_loop,
            name="Stage1-Watchdog",
            daemon=True,
        )
        self._watchdog_thread.start()

        self._started = True
        logger.info("[Stage1] Ready")

    def stop(self, timeout: float = 60.0) -> None:
        if not self._started:
            return
        logger.info("[Stage1] Stopping...")
        self._stop_event.set()
        self._job_q.put(None)  # sentinel
        if self._dispatcher_thread:
            self._dispatcher_thread.join(timeout=timeout)
        self._word.stop()
        self._started = False
        logger.info("[Stage1] Stopped")

    def submit(self, job: COMJob) -> dict:
        """
        Enqueue a job and block until COM stage completes.
        Returns the dict that document_pipeline.run_docx_pipeline() returns.
        Thread-safe — can be called from asyncio executor threads.
        """
        if not self._started:
            raise RuntimeError("Stage1COMOrchestrator is not running")
        self._job_q.put(job)
        deadline = self._job_timeout_s + 30.0
        signalled = job.done.wait(timeout=deadline)
        if not signalled:
            job.error = TimeoutError(
                f"Job {job.job_id} exceeded deadline {deadline:.0f}s")
        if job.error:
            raise job.error
        return job.result  # type: ignore

    @property
    def stats(self) -> dict:
        with self._stats_lock:
            return dict(self._stats)

    @property
    def queue_depth(self) -> int:
        return self._job_q.qsize()



    def _dispatcher_loop(self) -> None:
        """
        Reads jobs from _job_q one at a time and processes them.
        Sequential — COM is STA, no parallelism possible here.
        """
        while not self._stop_event.is_set():
            try:
                job = self._job_q.get(timeout=1.0)
            except queue.Empty:
                continue

            if job is None:  # shutdown sentinel
                break

            self._run_job(job)
            self._job_q.task_done()

    def _run_job(self, job: COMJob) -> None:
        """Execute one COM job. All Word calls go through self._word.run()."""
        job.started_at = time.monotonic()
        with self._stats_lock:
            self._stats["current_job"] = job.job_id

        logger.info("[Stage1] Starting job=%s  file=%s",
                    job.job_id, os.path.basename(job.doc_path))
        try:
            # ── Delegate entirely to existing pipeline logic ──────────────
            # run_docx_pipeline is NOT rewritten — it's called as-is.
            # The only change: it now receives the persistent _word instance
            # via the _word_override parameter (see patched pipeline below).
            from src.services.pipeline.document_pipeline import run_docx_pipeline

            result = run_docx_pipeline(
                pdf_path           = job.pdf_path,
                doc_path           = job.doc_path,
                output_folder      = job.output_folder,
                base_name          = job.base_name,
                extract_tables     = job.extract_tables,
                extract_images     = job.extract_images,
                extract_header     = job.extract_header,
                extract_footer     = job.extract_footer,
                extract_hyperlinks = job.extract_hyperlinks,
                extract_footnote   = job.extract_footnote,
                # Pass persistent Word instance so pipeline reuses it:
                _word_instance     = self._word,
            )

            job.result = result
            with self._stats_lock:
                self._stats["jobs_processed"] += 1

        except Exception as exc:
            logger.exception("[Stage1] job=%s FAILED: %s", job.job_id, exc)
            job.error = exc
            with self._stats_lock:
                self._stats["jobs_failed"] += 1

        finally:
            job.finished_at = time.monotonic()
            with self._stats_lock:
                self._stats["current_job"] = None
            gc.collect()
            job.done.set()

            elapsed = (job.finished_at or 0) - (job.started_at or 0)
            logger.info("[Stage1] job=%s done in %.1fs", job.job_id, elapsed)

    # ── Internal: watchdog ─────────────────────────────────────────────────

    def _watchdog_loop(self) -> None:
        """
        Monitors the Word STA thread. If it dies, restarts Word.
        OPTIMIZATION: Prevents permanent failure from COM crashes.
        """
        while not self._stop_event.is_set():
            time.sleep(_WATCHDOG_INTERVAL_S)
            if self._stop_event.is_set():
                break
            if not self._word.is_alive():
                logger.error("[Stage1-Watchdog] STA thread died — restarting Word...")
                with self._stats_lock:
                    self._stats["word_restarts"] += 1
                try:
                    self._word = _PersistentWordInstance()
                    self._word.start()
                    logger.info("[Stage1-Watchdog] Word restarted successfully")
                except Exception as exc:
                    logger.error("[Stage1-Watchdog] Word restart failed: %s", exc)
