import os
import json
import logging
from pathlib import Path

from src.services.layout_engine import LayoutAnalysisEngine
from src.schema.layout_schema import DocumentLayout
from src.services.extractors.pdf_converter import convert_pdf_to_docx
from src.services.pipeline.document_pipeline import run_docx_pipeline
from src.services.docx_repair_engine import DOCXRepairEngine
from src.services.validation_engine import ValidationEngine

logger = logging.getLogger(__name__)

class LayoutGuidedPipeline:
    """
    The orchestrator for the new Layout-Guided DOCX Repair Pipeline.
    It separates Document Understanding (LayoutAnalysisEngine) from
    Document Generation (Win32 COM).
    """

    def __init__(self, 
                 pdf_path: str | Path, 
                 output_folder: str | Path,
                 temp_docx_path: str | Path = None,
                 extract_tables: bool = True,
                 extract_images: bool = True,
                 extract_header: bool = True,
                 extract_footer: bool = True,
                 extract_hyperlinks: bool = True,
                 extract_footnote: bool = False,
                 word_instance = None):
        self.pdf_path = Path(pdf_path)
        self.output_folder = Path(output_folder)
        self.temp_docx_path = Path(temp_docx_path) if temp_docx_path else self.output_folder / "Temporary.docx"
        
        self.extract_tables = extract_tables
        self.extract_images = extract_images
        self.extract_header = extract_header
        self.extract_footer = extract_footer
        self.extract_hyperlinks = extract_hyperlinks
        self.extract_footnote = extract_footnote
        self.word_instance = word_instance

    def run_stage_1_understanding(self) -> DocumentLayout:
        """Runs the Layout Analysis Engine to understand the original PDF."""
        logger.info("Starting Layout Analysis Engine...")
        with LayoutAnalysisEngine(self.pdf_path) as engine:
            layout_model = engine.build_initial_layout()
            logger.info(f"Layout Analysis complete. Extracted {layout_model.total_pages} pages.")
            return layout_model

    def run_stage_2_generation(self) -> Path:
        """
        Runs the existing Win32 COM pipeline to generate the Temporary DOCX.
        Images and tables will be replaced by placeholders as per the existing pipeline logic.
        """
        logger.info("Starting Word COM Generation for Temporary.docx...")
        
        # Ensure output folder exists
        os.makedirs(self.output_folder, exist_ok=True)
        
        # 1. Convert PDF to DOCX
        logger.info("Converting PDF to DOCX...")
        convert_pdf_to_docx(str(self.pdf_path), str(self.temp_docx_path))
        
        # 2. Run the existing pipeline
        # The existing pipeline handles replacing images/tables with <IMAGE_x> and <TABLE_x>
        run_docx_pipeline(
            pdf_path=str(self.pdf_path),
            doc_path=str(self.temp_docx_path),
            output_folder=str(self.output_folder),
            base_name=self.pdf_path.stem,
            extract_tables=self.extract_tables,
            extract_images=self.extract_images,
            extract_header=True, 
            extract_footer=True, 
            extract_hyperlinks=self.extract_hyperlinks,
            extract_footnote=self.extract_footnote,
            _word_instance=self.word_instance
        )
        
        logger.info(f"Generated Temporary DOCX at {self.temp_docx_path}")
        return self.temp_docx_path

    def run_full_pipeline(self):
        """
        Executes the entire layout-guided pipeline sequentially.
        """
        # Phase 1 & 2 & 3: Understanding
        layout_model = self.run_stage_1_understanding()
        
        # Phase 4: Generation
        temp_docx = self.run_stage_2_generation()
        
        # Phase 5 & 6: Repair
        logger.info("Starting DOCX Repair Engine...")
        repair_engine = DOCXRepairEngine(temp_docx, layout_model)
        
        # Apply repairs
        repair_engine.repair_headers_and_footers()
        repair_engine.repair_footnotes_and_cleanup()
        repair_engine.repair_reading_order()
        
        # Save final repaired docx (for now overwriting temp, or save as final)
        final_docx_path = self.output_folder / f"{self.pdf_path.stem}_Repaired.docx"
        repair_engine.save(final_docx_path)
        logger.info(f"DOCX Repair complete. Saved to {final_docx_path}")
        
        # Phase 7: Validation, Anchoring, & Output
        logger.info("Merging Layout Engine Headers/Footers and Re-anchoring Elements...")
        original_meta_path = self.output_folder / f"{self.pdf_path.stem}_meta.json"
        
        if original_meta_path.exists():
            with open(original_meta_path, 'r', encoding='utf-8') as f:
                meta_data = json.load(f)
                
            if isinstance(meta_data, list):
                # 1. Extract all elements with their hint pages
                all_tables = []
                all_images_body = []
                all_footnotes = []
                
                for page_dict in meta_data:
                    hint = page_dict.get("page_number", 1)
                    
                    # Tables
                    for tbl in page_dict.get("table", []):
                        tbl["_hint"] = hint
                        all_tables.append(tbl)
                        
                    # Footnotes
                    for fn in page_dict.get("footnotes", []):
                        fn["_hint"] = hint
                        all_footnotes.append(fn)
                        
                    # Images (We only care about body images, headers/footers handled by PyMuPDF)
                    img_container = page_dict.get("image", {})
                    for img in img_container.get("body", []):
                        img["_hint"] = hint
                        all_images_body.append(img)
                        
                # 2. Text Anchor each element
                for tbl in all_tables:
                    true_page = layout_model.find_true_page_for_text(tbl.get("caption", ""), tbl["_hint"])
                    tbl["page_number"] = true_page
                    
                for fn in all_footnotes:
                    true_page = layout_model.find_true_page_for_text(fn.get("text", ""), fn["_hint"])
                    fn["_true_page"] = true_page
                    
                for img in all_images_body:
                    true_page = layout_model.find_true_page_for_text(img.get("caption", ""), img["_hint"])
                    img["_true_page"] = true_page

                # 3. Rebuild meta_data using True Pages
                new_meta_data = []
                for p_num in range(1, layout_model.total_pages + 1):
                    # Collect anchored elements for this page
                    # Get the original header/footer from the Word extraction
                    original_page_dict = next((pd for pd in meta_data if pd.get("page_number") == p_num), {})
                    header_text = original_page_dict.get("header", "")
                    footer_text = original_page_dict.get("footer", "")

                    # Collect anchored elements for this page
                    page_tables = [t for t in all_tables if t.get("page_number") == p_num]
                    for t in page_tables:
                        t.pop("_hint", None)
                        
                    page_footnotes = [f for f in all_footnotes if f.get("_true_page") == p_num]
                    for f in page_footnotes:
                        f.pop("_hint", None)
                        f.pop("_true_page", None)
                        
                    page_images = [i for i in all_images_body if i.get("_true_page") == p_num]
                    for i in page_images:
                        i.pop("_hint", None)
                        i.pop("_true_page", None)

                    new_page = {
                        "page_number": p_num,
                        "page_type": "even" if p_num % 2 == 0 else "odd",
                        "header": header_text,
                        "footer": footer_text,
                        "image": {
                            "body": page_images,
                            "header": [],
                            "footer": []
                        },
                        "table": page_tables,
                    }
                    if page_footnotes:
                        new_page["footnotes"] = page_footnotes
                        
                    new_meta_data.append(new_page)

                # Save the completely rebuilt metadata
                with open(original_meta_path, 'w', encoding='utf-8') as f:
                    json.dump(new_meta_data, f, indent=2)
                logger.info(f"Merged and anchored meta.json saved to {original_meta_path}")
            
            return {
                "pdf_path": str(self.pdf_path),
                "doc_path": str(final_docx_path),
                "output_folder": str(self.output_folder),
                "saved_files": {
                    "full_analysis_json": str(original_meta_path),
                    "converted_docx": str(final_docx_path)
                }
            }
            
        else:
            logger.warning(f"Could not find original meta.json at {original_meta_path}")
            return {
                "pdf_path": str(self.pdf_path),
                "doc_path": str(final_docx_path),
                "output_folder": str(self.output_folder),
                "saved_files": {
                    "converted_docx": str(final_docx_path)
                }
            }

if __name__ == "__main__":
    pass
