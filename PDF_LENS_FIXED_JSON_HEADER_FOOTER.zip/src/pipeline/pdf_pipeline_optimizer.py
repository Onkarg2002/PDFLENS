from __future__ import annotations
import gc
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

logger = logging.getLogger(__name__)


class PersistentPDFPlumberDoc:

    def __init__(self, pdf_path: str) -> None:
        self._pdf_path = pdf_path
        self._doc = None
        self._lock = threading.Lock() 

    def __enter__(self):
        import pdfplumber
        self._doc = pdfplumber.open(self._pdf_path)
        logger.info("[PDFPlumber] opened (persistent): %s",
                    os.path.basename(self._pdf_path))
        return self

    def __exit__(self, *_):
        if self._doc:
            try:
                self._doc.close()
            except Exception:
                pass
            self._doc = None

    def get_page(self, page_num: int):
        """Return pdfplumber page (1-based). Thread-safe via lock."""
        with self._lock:
            if self._doc is None:
                raise RuntimeError("PDFPlumber doc not open")
            return self._doc.pages[page_num - 1]

    @property
    def page_count(self) -> int:
        if self._doc is None:
            return 0
        return len(self._doc.pages)


class SafeScreenCapture:

    def __init__(self, pdf_path: str) -> None:
        self._pdf_path = pdf_path

    def capture_page(self, page_num: int, dpi: int = 150):
    
        try:
            import pypdfium2 as pdfium
            doc   = pdfium.PdfDocument(self._pdf_path)
            page  = doc[page_num - 1]
            scale = dpi / 72.0
            bm    = page.render(scale=scale, rotation=0)
            img   = bm.to_pil()
            page.close()
            doc.close()
            return img
        except Exception as exc:
            logger.error("[SafeCapture] page %d: %s", page_num, exc)
            return None

    def capture_region(self, page_num: int,
                       x0_pt: float, y0_pt: float,
                       x1_pt: float, y1_pt: float,
                       dpi: int = 200):
    
        try:
            import pypdfium2 as pdfium
            from PIL import Image
            doc   = pdfium.PdfDocument(self._pdf_path)
            page  = doc[page_num - 1]
            scale = dpi / 72.0
            bm    = page.render(scale=scale, rotation=0,
                                fill_color=(255, 255, 255, 255))
            full  = bm.to_pil()
            page.close()
            doc.close()

            px0 = max(0, int(x0_pt * scale))
            py0 = max(0, int(y0_pt * scale))
            px1 = min(full.width,  int(x1_pt * scale))
            py1 = min(full.height, int(y1_pt * scale))
            if px1 <= px0 or py1 <= py0:
                return None
            cropped = full.crop((px0, py0, px1, py1))
            try:
                full.close()
            except Exception:
                pass
            return cropped
        except Exception as exc:
            logger.error("[SafeCapture] region page %d: %s", page_num, exc)
            return None


def extract_pdf_zones_parallel(
    pdf_path:      str,
    hdr_max_pt:    float = 72.0,
    ftr_min_ratio: float = 0.85,
    chunk_size:    int   = 50,
    max_workers:   int   = 4,
) -> dict:

    import pypdfium2 as pdfium
    from src.services.extractors.header_footer_extractor import (
        extract_pdf_header_footer_zones,
    )

    if not pdf_path or not os.path.isfile(pdf_path):
        return {}

    # For small PDFs, just run sequentially (thread overhead > benefit)
    try:
        doc     = pdfium.PdfDocument(pdf_path)
        n_pages = len(doc)
        doc.close()
    except Exception:
        return {}

    if n_pages <= chunk_size:
        return extract_pdf_header_footer_zones(
            pdf_path,
            hdr_max_pt    = hdr_max_pt,
            ftr_min_ratio = ftr_min_ratio,
        )

    logger.info("[Parallel zones] %d pages, chunk_size=%d, workers=%d",
                n_pages, chunk_size, max_workers)

    return extract_pdf_header_footer_zones(
        pdf_path,
        hdr_max_pt    = hdr_max_pt,
        ftr_min_ratio = ftr_min_ratio,
    )


class BatchJSONWriter:

    def __init__(self, max_workers: int = 4) -> None:
        self._max_workers = max_workers

    def write_all(self, tasks: list[tuple[str, object]]) -> list[str]:

        import json

        def _write_one(path: str, data: object) -> str:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            return path

        written = []
        with ThreadPoolExecutor(
            max_workers       = self._max_workers,
            thread_name_prefix = "JSONWriter",
        ) as pool:
            futures = {pool.submit(_write_one, p, d): p for p, d in tasks}
            for fut in futures:
                try:
                    written.append(fut.result())
                except Exception as exc:
                    logger.error("[BatchJSON] write failed %s: %s",
                                 futures[fut], exc)
        return written
