import os
import sys
import logging
from pathlib import Path

# Setup basic logging to see stdout
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# Ensure the src module can be imported
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from src.pipeline.layout_guided_pipeline import LayoutGuidedPipeline

def test_pipeline():
    logger.info("Initializing Layout-Guided Pipeline Test...")
    
    # Paths
    pdf_path = Path(r"C:\Sahai\PDF_LENS_STABLE_ALL_V1\data\uploads\15.pdf")
    output_dir = Path(r"C:\Sahai\PDF_LENS_STABLE_ALL_V1\data\uploads\15_output")
    
    print(f"Testing Layout-Guided Pipeline on: {pdf_path}")
    print(f"Outputs will be saved to: {output_dir}")
    
    if not pdf_path.exists():
        print(f"Error: Could not find PDF at {pdf_path}")
        return
        
    pipeline = LayoutGuidedPipeline(pdf_path, output_dir)
    result = pipeline.run_full_pipeline()
    final_docx = result.get("doc_path")
    meta_json = result.get("saved_files", {}).get("full_analysis_json")
    
    print("\n--- TEST COMPLETE ---")
    print(f"Final DOCX: {final_docx}")
    print(f"Meta JSON: {meta_json}")

if __name__ == "__main__":
    test_pipeline()
