from __future__ import annotations

import gc
import os
import re
import tempfile
import time
from typing import Any, Optional
import pypdfium2 as pdfium
from PIL import Image, ImageGrab
from src.constants.constant import FOLDER_EXTRACTED_IMAGES
from src.utils.file_util import safe_com, ensure_dir
from src.services.extractors.extractor_com_safe import (extraction_scope,iter_com_collection,is_smartart_like_shape,log_classified,normalize_word_text,release_com_refs,safe_doc_range,_DEFAULT_MAX_SHAPES_PER_RANGE,)
from src.utils.structured_log import configure_logging, get_logger, log_event

configure_logging()
_SLOG = get_logger("pdf_lens.services.extractors.image_extractor")


def _slog(msg: str = "", event: str = "log", **fields) -> None:
    text = str(msg).strip() if msg else ""
    log_event(_SLOG, event, msg=text, **fields)

def register_pdf_cache(pdf_path: str, doc) -> None:
    """No-op: whole-document pdfium cache removed for large-PDF stability."""
    pass

def unregister_pdf_cache(pdf_path: str) -> None:
    """No-op: whole-document pdfium cache removed for large-PDF stability."""
    pass

# PDF RENDER HELPERS

def pdf_page_to_pil(pdf_path: str, page_num: int,
                    dpi: int = 150) -> Optional[Image.Image]:
    """
    Render a single PDF page to a PIL Image.

    Opens the file, renders page_num (1-based), closes the PdfDocument and
    returns the PIL Image.  Peak memory = one rendered page bitmap only.
    """
    doc = None
    try:
        doc   = pdfium.PdfDocument(pdf_path)
        page  = doc[page_num - 1]
        scale = dpi / 72.0
        bm    = page.render(scale=scale, rotation=0)
        img   = bm.to_pil()
        page.close()
        return img
    except Exception as exc:
        _slog(f"    [pdf_render] page {page_num}: {exc}")
        return None
    finally:
        if doc is not None:
            try:
                doc.close()
            except Exception:
                pass
        del doc

def pdf_region_to_pil(pdf_path: str, page_num: int,
                       x0_pt: float, y0_pt: float,
                       x1_pt: float, y1_pt: float,
                       dpi: int = 200) -> Optional[Image.Image]:
    """
    Render a rectangular PDF region (points, top-left origin) to PIL Image.
    Opens the file, renders the requested page, crops to the bbox, closes the
    document immediately.  No global PDF state is modified.
    """
    doc = None
    full = None
    try:
        doc   = pdfium.PdfDocument(pdf_path)
        page  = doc[page_num - 1]
        scale = dpi / 72.0
        bm    = page.render(scale=scale, rotation=0,
                             fill_color=(255, 255, 255, 255))
        full  = bm.to_pil()
        page.close()

        px0 = max(0, int(x0_pt * scale))
        py0 = max(0, int(y0_pt * scale))
        px1 = min(full.width,  int(x1_pt * scale))
        py1 = min(full.height, int(y1_pt * scale))
        if px1 <= px0 or py1 <= py0:
            return None
        return full.crop((px0, py0, px1, py1))
    except Exception as exc:
        _slog(f"    [pdf_region] page {page_num}: {exc}")
        return None
    finally:
        if full is not None:
            try:
                full.close()
            except Exception:
                pass
        if doc is not None:
            try:
                doc.close()
            except Exception:
                pass
        del doc, full

# FILE-SIZE HELPER

def _human_size(filepath: str) -> str:
    try:
        n = os.path.getsize(filepath)
        return (f"{n / (1024*1024):.2f} MB" if n >= 1024 * 1024
                else f"{n / 1024:.2f} KB")
    except Exception:
        return "unknown"


_CAPTION_RE = re.compile(
    r'''
    (?:
        \b(?:figure|fig\.?|image|img\.?|photo|plate|illustration|illus\.?|
             diagram|diag\.?|chart|graph|exhibit|table|tbl\.?)\s*[\d\w\-\.]+
      | ^\s*(?:figure|fig\.?|image|img\.?|photo|plate|illustration|illus\.?|
               diagram|diag\.?|chart|graph|exhibit|table|tbl\.)[\s:\.\-]
    )
    ''',
    re.I | re.X,
)

_IMG_CAPTION_RE = re.compile(
    r'\b(?:figure|fig\.?|image|img\.?|photo|plate|illustration|illus\.?|'
    r'diagram|diag\.?|chart|graph)\s*[\dIVXivx\w]',
    re.I,
)

_CAPTION_MIN_SCORE = 25
_WD_EXPORT_PNG     = 4
_CAPTION_WIN_CHARS = 4000
_CLIPBOARD_WAIT_S  = 0.08
_GC_IMAGE_THRESHOLD = 8   


# CAPTION SCORING ENGINE

def _score_image_caption_candidate(txt: str, sty: str, offset: int) -> int:
    txt = txt.strip().rstrip("\r\n\x07")
    if not txt:
        return 0

    score = 0
    if "caption" in sty.lower():
        score += 35
    if _IMG_CAPTION_RE.search(txt):
        score += 30
    elif _CAPTION_RE.search(txt):
        score += 15
    if offset > 0:
        score += 20
    dist = abs(offset)
    if dist == 1:
        score += 10
    elif dist == 2:
        score += 5
    elif dist >= 3:
        score -= 10
    return score


def _build_para_bounds(paras_coll) -> list[tuple[int, int]]:
    """One pass: (Range.Start, Range.End) for each paragraph in a collection."""
    bounds: list[tuple[int, int]] = []
    try:
        count = int(safe_com(lambda: paras_coll.Count, default=0) or 0)
    except Exception:
        return bounds
    for i in range(1, count + 1):
        para = safe_com(lambda idx=i: paras_coll(idx), default=None)
        if para is None:
            continue
        b = safe_com(
            lambda pp=para: (int(pp.Range.Start), int(pp.Range.End)),
            default=None,
        )
        if b:
            bounds.append(b)
    return bounds


def _find_para_index(bounds: list[tuple[int, int]], char_pos: int) -> Optional[int]:
    """1-based paragraph index containing *char_pos*, or None (binary search)."""
    if not bounds or char_pos < 0:
        return None
    lo, hi = 0, len(bounds) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        start, end = bounds[mid]
        if char_pos < start:
            hi = mid - 1
        elif char_pos > end:
            lo = mid + 1
        else:
            return mid + 1
    return None


def _make_caption_context(paras_coll, bounds: list[tuple[int, int]]) -> dict:
    return {"paras": paras_coll, "bounds": bounds}


def _caption_context_near_shape(shape_obj) -> Optional[dict]:
    """
    Build a small paragraph window around the shape (~±4k chars) for caption
    detection — avoids scanning the entire document Paragraphs collection.
    """
    win_rng = None
    try:
        try:
            shape_rng = shape_obj.Range
        except Exception:
            shape_rng = safe_com(lambda: shape_obj.Anchor, default=None)
        if shape_rng is None:
            return None

        doc = safe_com(lambda: shape_rng.Document, default=None)
        if doc is None:
            return None

        containing = safe_com(lambda: shape_rng.Paragraphs(1), default=None)
        if containing is None:
            return None

        shape_start = safe_com(
            lambda: int(containing.Range.Start), default=-1)
        if shape_start < 0:
            return None

        doc_end = int(safe_com(lambda: doc.Content.End, default=0) or 0)
        win_start = max(0, shape_start - _CAPTION_WIN_CHARS)
        win_end   = min(doc_end, shape_start + _CAPTION_WIN_CHARS)
        win_rng   = safe_doc_range(doc, win_start, win_end, context="caption_window")
        if win_rng is None:
            return None
        paras     = win_rng.Paragraphs
        bounds    = _build_para_bounds(paras)
        if not bounds:
            return None
        return _make_caption_context(paras, bounds)
    except Exception as exc:
        log_classified(exc, "caption_context")
        return None
    finally:
        release_com_refs(win_rng)


def _para_text_style(para) -> tuple[str, str]:
    """Batch paragraph text + style in one COM round-trip."""
    packed = safe_com(
        lambda pp=para: (
            pp.Range.Text,
            pp.Range.Style.NameLocal,
        ),
        default=None,
    )
    if not packed:
        return "", ""
    return normalize_word_text(packed[0]), normalize_word_text(packed[1], max_len=200)


def _collect_candidates_image(ctx: dict, img_idx: int) -> list:
    """
    Collect up to 3 paragraphs above and below *img_idx* (1-based in ctx).
    Returns list of (offset, txt, sty).
    """
    paras  = ctx["paras"]
    bounds = ctx["bounds"]
    total  = len(bounds)
    candidates: list = []

    for offset in range(1, 4):
        idx = img_idx - offset
        if idx < 1:
            break
        para = safe_com(lambda i=idx: paras(i), default=None)
        if para is None:
            break
        txt, sty = _para_text_style(para)
        if not txt:
            continue
        candidates.append((-offset, txt, sty))
        break

    blanks = 0
    for offset in range(1, 4):
        idx = img_idx + offset
        if idx > total:
            break
        para = safe_com(lambda i=idx: paras(i), default=None)
        if para is None:
            break
        txt, sty = _para_text_style(para)
        if not txt:
            blanks += 1
            if blanks > 1:
                break
            continue
        candidates.append((offset, txt, sty))
        break

    return candidates


def _extract_image_caption(
    shape_obj,
    caption_context: Optional[dict] = None,
) -> str:
    """
    Caption: AlternativeText → scored nearby paragraphs → Title.
    Uses *caption_context* when provided (page-range cache); otherwise a
    tight ±4k character window — never a full-document paragraph scan.
    """
    alt = normalize_word_text(safe_com(lambda: shape_obj.AlternativeText, default=""))
    if alt:
        return alt

    try:
        try:
            shape_rng = shape_obj.Range
        except Exception:
            shape_rng = safe_com(lambda: shape_obj.Anchor, default=None)
        if shape_rng is None:
            raise ValueError("no range")

        ctx = caption_context or _caption_context_near_shape(shape_obj)
        if ctx is None:
            raise ValueError("no caption context")

        shape_start = safe_com(
            lambda: int(shape_rng.Paragraphs(1).Range.Start),
            default=-1,
        )
        img_idx = _find_para_index(ctx["bounds"], shape_start)

        if img_idx is not None:
            candidates = _collect_candidates_image(ctx, img_idx)
            if candidates:
                best_score = -1
                best_txt   = ""
                for offset, txt, sty in candidates:
                    s = _score_image_caption_candidate(txt, sty, offset)
                    if s > best_score:
                        best_score = s
                        best_txt   = txt
                if best_score >= _CAPTION_MIN_SCORE and best_txt:
                    return best_txt
    except Exception:
        pass

    title = normalize_word_text(safe_com(lambda: shape_obj.Title, default=""))
    return title or ""


# SHAPE EXPORT

def _save_pil_to_png(img: Image.Image, filepath: str) -> tuple[int, int]:
    width_px, height_px = img.size
    img.save(filepath, "PNG")
    img.close()
    return width_px, height_px

def _export_via_clipboard(shape_obj, filepath: str) -> tuple[int, int]:
    """
    Clipboard fallback: prefer shape.Copy() (no Selection).
    Selection.CopyAsPicture() is the last resort (UI-heavy).
    """
    img = None
    try:
        try:
            shape_obj.Copy()
        except Exception:
            shape_obj.Select()
            shape_obj.Application.Selection.CopyAsPicture()
        time.sleep(_CLIPBOARD_WAIT_S)
        img = ImageGrab.grabclipboard()
        if img is None:
            return 0, 0
        return _save_pil_to_png(img, filepath)
    except Exception:
        if img is not None:
            try:
                img.close()
            except Exception:
                pass
        return 0, 0


def _export_shape_to_png(shape_obj, filepath: str, img_id: int) -> tuple[int, int, bool]:
    """
    Returns (width_px, height_px, success).
    Fast path: shape.Export. Fallback: clipboard without Selection when possible.
    SmartArt-like shapes skip Export (often hangs / empty).
    """
    if is_smartart_like_shape(shape_obj):
        return 0, 0, False

    tmp_path = None
    try:
        tmp_fd, tmp_path = tempfile.mkstemp(
            suffix=".png", prefix=f"shp_{img_id}_")
        os.close(tmp_fd)
        shape_obj.Export(tmp_path, _WD_EXPORT_PNG)
        if os.path.isfile(tmp_path) and os.path.getsize(tmp_path) > 0:
            img = Image.open(tmp_path)
            w, h = _save_pil_to_png(img, filepath)
            del img
            return w, h, True
    except Exception as exc:
        log_classified(exc, f"shape_export_{img_id}")
    finally:
        if tmp_path:
            try:
                if os.path.isfile(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass

    w, h = _export_via_clipboard(shape_obj, filepath)
    return w, h, w > 0 and h > 0 and os.path.isfile(filepath)


def extract_and_save_image(
    shape_obj,
    output_folder: str,
    prefix: str = "img",
    page_number: int = 0,
    tag_name: str = "",
    caption_context: Optional[dict] = None,
) -> dict:
    """
    Export a Word InlineShape / Shape to PNG and return full metadata.

    Fast path  : shape.Export() → temp file → PNG on disk.
    Fallback   : Copy / Selection.CopyAsPicture (only when Export fails).

    Caption COM runs only after a successful export (skipped on failure).
    PIL handles are closed immediately after save.
    """
    # Guard 1: skip msoLine shapes (type=9) — these are decorative lines not images
    _shape_type = safe_com(lambda: shape_obj.Type, default=None)
    if _shape_type == 9:
        return {}

    # Guard 2: skip line-like shapes by aspect ratio (very wide, very thin)
    try:
        _sw = float(safe_com(lambda: shape_obj.Width,  default=0) or 0)
        _sh = float(safe_com(lambda: shape_obj.Height, default=1) or 1)
        if _sh > 0 and (_sw / _sh) > 20:
            _slog(f"  [image] skip line-like shape w={_sw:.0f} h={_sh:.0f} ratio={_sw/_sh:.0f}")
            return {}
    except Exception:
        pass

    ensure_dir(output_folder)

    try:
        img_id = shape_obj.ID
    except Exception:
        img_id = id(shape_obj)

    filename   = f"{tag_name}.png" if tag_name else f"{prefix}_{img_id}.png"
    filepath   = os.path.join(output_folder, filename)
    image_type = "floating" if "float" in prefix else "inline"

    width_px, height_px, ok = _export_shape_to_png(shape_obj, filepath, img_id)
    if not ok:
        return {}

    alt = safe_com(lambda: shape_obj.AlternativeText.strip(), default="")
    caption = alt or _extract_image_caption(shape_obj, caption_context)

    return {
        "filename":    filename,
        "extension":   "png",
        "caption":     caption,
        "width_px":    width_px,
        "height_px":   height_px,
        "file_size":   _human_size(filepath),
        "page_number": page_number,
        "image_type":  image_type,
    }


# PAGE-LEVEL IMAGE EXTRACTION

def extract_images_from_range(
    page_range,
    img_folder: str,
    page_number: int = 0,
    start_img_idx: int = 1,
) -> dict:
    """
    Extract all inline and floating images from a Word page range.

    Builds one paragraph-bound cache for the page (caption detection).
    Calls gc.collect() only when many images were exported on this page.
    """
    imgs: list = []
    ensure_dir(img_folder)
    img_idx = start_img_idx

    with extraction_scope(f"images_p{page_number}"):
        caption_ctx: Optional[dict] = None
        try:
            paras_coll = page_range.Paragraphs
            bounds     = _build_para_bounds(paras_coll)
            if bounds:
                caption_ctx = _make_caption_context(paras_coll, bounds)
        except Exception as exc:
            log_classified(exc, "image_caption_ctx")

        try:
            for s in iter_com_collection(
                    page_range.InlineShapes,
                    max_items=_DEFAULT_MAX_SHAPES_PER_RANGE,
                    label="InlineShapes",
            ):
                tag_name = f"doc_ai_img_id_{img_idx}"
                try:
                    meta = extract_and_save_image(
                        s, img_folder, prefix="body_inline",
                        page_number=page_number, tag_name=tag_name,
                        caption_context=caption_ctx,
                    )
                except Exception as exc:
                    log_classified(exc, f"inline_img_p{page_number}")
                    meta = {}
                if meta:
                    meta["tag"] = f"<{tag_name}>"
                    imgs.append(meta)
                    img_idx += 1
                release_com_refs(s)
        except Exception as exc:
            log_classified(exc, "InlineShapes")

        try:
            for s in iter_com_collection(
                    page_range.ShapeRange,
                    max_items=_DEFAULT_MAX_SHAPES_PER_RANGE,
                    label="ShapeRange",
            ):
                tag_name = f"doc_ai_img_id_{img_idx}"
                try:
                    meta = extract_and_save_image(
                        s, img_folder, prefix="body_float",
                        page_number=page_number, tag_name=tag_name,
                        caption_context=caption_ctx,
                    )
                except Exception as exc:
                    log_classified(exc, f"float_img_p{page_number}")
                    meta = {}
                if meta:
                    meta["tag"] = f"<{tag_name}>"
                    imgs.append(meta)
                    img_idx += 1
                release_com_refs(s)
        except Exception as exc:
            log_classified(exc, "ShapeRange")

        if img_idx - start_img_idx >= _GC_IMAGE_THRESHOLD:
            gc.collect()

    return {"total_count": len(imgs), "details": imgs, "next_img_idx": img_idx}