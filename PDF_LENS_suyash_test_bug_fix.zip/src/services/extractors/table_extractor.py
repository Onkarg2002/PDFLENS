from __future__ import annotations

import gc
import json
import os
import re

from src.constants.constant import (FOLDER_TABLE_SCREENSHOTS,)
from src.utils.file_util import safe_com, sanitize_cell, ensure_dir
from src.services.extractors.table_screenshot import capture_table_screenshot
from src.services.extractors.extractor_com_safe import (classify_exception,extraction_scope,log_classified,normalize_word_text,release_com_refs,safe_doc_range,)

_MAX_TABLE_ROWS = 500
_MAX_TABLE_COLS = 100


# TABLE CAPTION DETECTION

# Keyword patterns for table caption scoring 
_TBL_CAP_RE = re.compile(
    r"(?:table|tbl\.?|exhibit|tab\.?)\s*[\dIVXivx\w]"
    r"|(?:figure|fig\.?|image|img\.?|diagram|chart)\s*[\dIVXivx\w]",
    re.I,
)
_TBL_STRONG_RE = re.compile(
    r"\b(?:table|tbl\.?|exhibit)\s*[\dIVXivx\w]", re.I
)

_TBL_MIN_SCORE = 25

_STRIP_CHARS = "\r\n\x07"
_LARGE_GRID_CELLS = 2500


def _clean_cell_text(raw: str) -> str:
    return normalize_word_text(raw or "", max_len=50_000)


def _score_table_caption_candidate(txt, sty, position):
    """
    Score a paragraph as a table caption candidate (0-100 scale).

    +35  Word Caption style
    +30  Strong table keyword  (Table / Tbl / Exhibit + number)
    +15  Generic caption keyword via _TBL_CAP_RE
    +25  Preferred position: ABOVE the table
    - 5  Position is below  (valid fallback)
    """
    txt = txt.strip().rstrip(_STRIP_CHARS)
    if not txt:
        return 0

    score = 0

    if "caption" in sty.lower():
        score += 35

    if _TBL_STRONG_RE.search(txt):
        score += 30
    elif _TBL_CAP_RE.search(txt):
        score += 15

    if position == "above":
        score += 25
    else:
        score -= 5

    return score


def _collect_multiline_caption(doc, direction, char_window, table_start, table_end):
    """
    Collect consecutive caption-style paragraphs in one direction and merge.

    direction : "above" | "below"
    Returns (merged_text, style_of_first_para).
    """
    try:
        if direction == "above":
            rng   = safe_doc_range(
                doc, max(0, table_start - char_window), table_start,
                context="caption_above",
            )
            if rng is None:
                return "", ""
            paras = rng.Paragraphs
            count = paras.Count
            if count == 0:
                return "", ""
            lines, sty0 = [], ""
            for offset in range(count, max(count - 3, 0), -1):
                p   = paras(offset)
                txt = p.Range.Text.strip().rstrip(_STRIP_CHARS)
                sty = p.Range.Style.NameLocal
                if not txt:
                    break
                if "caption" in sty.lower() or _TBL_CAP_RE.search(txt):
                    if not sty0:
                        sty0 = sty
                    lines.insert(0, txt)
                else:
                    break
            return " ".join(lines), sty0

        else:  # below
            doc_end = int(safe_com(lambda: doc.Content.End, default=0) or 0)
            rng   = safe_doc_range(
                doc, table_end, min(doc_end, table_end + char_window),
                context="caption_below",
            )
            if rng is None:
                return "", ""
            paras = rng.Paragraphs
            count = paras.Count
            if count == 0:
                return "", ""
            lines, sty0 = [], ""
            for offset in range(1, min(4, count + 1)):
                p   = paras(offset)
                txt = p.Range.Text.strip().rstrip(_STRIP_CHARS)
                sty = p.Range.Style.NameLocal
                if not txt:
                    break
                if "caption" in sty.lower() or _TBL_CAP_RE.search(txt):
                    if not sty0:
                        sty0 = sty
                    lines.append(txt)
                else:
                    break
            return " ".join(lines), sty0
    except Exception:
        return "", ""


def detect_table_caption(
    doc,
    table_obj,
    table_start: int = 0,
    table_end: int = 0,
):
    """
    Scan above and below a table for caption paragraphs using adaptive scoring.

    Strategy
    --------
    1. Collect first non-blank candidate above the table.
    2. Collect first non-blank candidate below the table.
    3. Attempt multiline merge for whichever direction has a caption hit.
    4. Score both candidates; pick highest scorer above _TBL_MIN_SCORE.
    5. Tables strongly prefer ABOVE; below is a fallback.

    Returns dict: {caption_text, caption_position, caption_style}
    """
    caption_text  = ""
    caption_pos   = None
    caption_style = ""

    try:
        if not table_start or not table_end:
            _bounds = safe_com(
                lambda t=table_obj: (t.Range.Start, t.Range.End),
                default=(0, 0),
            )
            if _bounds:
                table_start, table_end = _bounds

        candidates = []  

        # Candidate ABOVE
        if table_start > 0:
            above_rng = safe_doc_range(
                doc, max(0, table_start - 400), table_start, context="caption_probe_above")
            if above_rng is None or above_rng.Paragraphs.Count <= 0:
                pass
            elif above_rng.Paragraphs.Count > 0:
                p   = above_rng.Paragraphs.Last
                txt = p.Range.Text.strip().rstrip(_STRIP_CHARS)
                sty = p.Range.Style.NameLocal
                if txt:
                    
                    if "caption" in sty.lower() or _TBL_CAP_RE.search(txt):
                        merged, msty = _collect_multiline_caption(
                            doc, "above", 400, table_start, table_end)
                        if merged:
                            txt, sty = merged, (msty or sty)
                    candidates.append((txt, sty, "above"))

        doc_end = int(safe_com(lambda: doc.Content.End, default=0) or 0)
        below_rng = safe_doc_range(
            doc, table_end, min(doc_end, table_end + 400), context="caption_probe_below")
        if below_rng is not None and below_rng.Paragraphs.Count > 0:
            p   = below_rng.Paragraphs.First
            txt = p.Range.Text.strip().rstrip(_STRIP_CHARS)
            sty = p.Range.Style.NameLocal
            if txt:
                if "caption" in sty.lower() or _TBL_CAP_RE.search(txt):
                    merged, msty = _collect_multiline_caption(
                        doc, "below", 400, table_start, table_end)
                    if merged:
                        txt, sty = merged, (msty or sty)
                candidates.append((txt, sty, "below"))

        best_score = -1
        best_txt   = ""
        best_pos   = None
        best_sty   = ""
        for (txt, sty, pos) in candidates:
            s = _score_table_caption_candidate(txt, sty, pos)
            if s > best_score:
                best_score = s
                best_txt   = txt
                best_pos   = pos
                best_sty   = sty

        if best_score >= _TBL_MIN_SCORE and best_txt:
            caption_text  = best_txt
            caption_pos   = best_pos
            caption_style = best_sty

    except Exception as exc:
        log_classified(exc, "caption_detect")

    return {
        "caption_text":     caption_text,
        "caption_position": caption_pos,
        "caption_style":    caption_style,
    }



# TABLE GRID EXTRACTION 

def _extract_cell_dict(table, r: int, c: int) -> dict:
    """Legacy per-cell path: logical (r,c) with merge detection on COM failure."""
    cell_dict = {"row": r, "col": c, "text": "", "merged": False, "vertical_merge": 0}
    try:
        cell = table.Cell(r, c)
        _packed = safe_com(
            lambda cl=cell: (
                _clean_cell_text(cl.Range.Text),
                int(cl.VerticalMerge),
            ),
            default=None,
        )
        if _packed:
            cell_dict["text"], cell_dict["vertical_merge"] = _packed
    except Exception:
        cell_dict["merged"] = True
    return cell_dict


def _extract_grid_cell_by_cell(table, rows: int, cols: int) -> list:
    """Original O(rows×cols) table.Cell traversal — used as fallback."""
    grid: list = []
    for r in range(1, rows + 1):
        row_data = [_extract_cell_dict(table, r, c) for c in range(1, cols + 1)]
        grid.append(row_data)
    return grid


def _extract_grid_via_cells_collection(table, rows: int, cols: int) -> list | None:
    """
    One enumeration of table.Range.Cells (physical cells), then hole-fill for
    logical positions that are vertically/horizontally merged.

    Typically far fewer COM calls than nested table.Cell(r,c) on wide tables.
    Returns None when the Cells collection cannot be used.
    """
    try:
        cells_coll = table.Range.Cells
        count      = int(cells_coll.Count)
    except Exception:
        return None

    if count <= 0:
        return None

    slots: list = [[None] * cols for _ in range(rows)]
    filled = 0

    for i in range(1, count + 1):
        try:
            cell = cells_coll(i)
        except Exception:
            continue
        _packed = safe_com(
            lambda cl=cell: (
                int(cl.Row),
                int(cl.Column),
                _clean_cell_text(cl.Range.Text),
                int(cl.VerticalMerge),
            ),
            default=None,
        )
        if not _packed:
            continue
        r, c, txt, vm = _packed
        if 1 <= r <= rows and 1 <= c <= cols:
            if slots[r - 1][c - 1] is None:
                filled += 1
            slots[r - 1][c - 1] = {
                "row":             r,
                "col":             c,
                "text":            txt,
                "merged":          False,
                "vertical_merge":  vm,
            }

    # Fast path: dense table — every logical cell seen in one pass
    if filled == rows * cols:
        return [[slots[r][c] for c in range(cols)] for r in range(rows)]

    # Hole-fill only for missing logical coordinates (merged areas)
    grid: list = []
    for r in range(1, rows + 1):
        row_data: list = []
        for c in range(1, cols + 1):
            entry = slots[r - 1][c - 1]
            if entry is not None:
                row_data.append(entry)
            else:
                row_data.append(_extract_cell_dict(table, r, c))
        grid.append(row_data)
    return grid


def _extract_table_grid(table, rows: int, cols: int) -> list:
    """Choose the fastest safe grid extractor for this table size."""
    if rows <= 0 or cols <= 0:
        return []
    rows = min(rows, _MAX_TABLE_ROWS)
    cols = min(cols, _MAX_TABLE_COLS)
    if rows * cols > _LARGE_GRID_CELLS:
        bulk = _extract_grid_via_cells_collection(table, rows, cols)
        if bulk is not None:
            return bulk
        return _extract_grid_cell_by_cell(table, rows, cols)
    bulk = _extract_grid_via_cells_collection(table, rows, cols)
    if bulk is not None:
        return bulk
    return _extract_grid_cell_by_cell(table, rows, cols)


# SHARED PER-TABLE RECORD BUILDER

def _build_table_record(doc, table, i: int,
                         pdf_path: str, pdf_zones: dict,
                         screenshot_folder: str) -> dict:
    """
    Extract one table's metadata, cell grid, and screenshot.
    COM proxy variables are explicitly del-ed as soon as they are no longer
    needed so Python's reference counter can release them promptly.
    Returns a complete record dict (or an error dict on failure).
    """
    section_ps = None
    try:
        with extraction_scope(f"table_{i}"):
            _tbl_meta = safe_com(
                lambda t=table: (
                    int(t.Range.Information(3)),
                    int(t.Range.Start),
                    int(t.Range.End),
                    int(t.Rows.Count),
                    int(t.Columns.Count),
                ),
                default=None,
            )
            if _tbl_meta:
                page_num, tbl_start, tbl_end, rows, cols = _tbl_meta
            else:
                page_num  = safe_com(
                    lambda t=table: int(t.Range.Information(3)), default=1)
                tbl_start = safe_com(lambda t=table: t.Range.Start, default=0)
                tbl_end   = safe_com(lambda t=table: t.Range.End,   default=0)
                rows = safe_com(lambda t=table: t.Rows.Count,    default=0)
                cols = safe_com(lambda t=table: t.Columns.Count, default=0)

            cap_info = detect_table_caption(
                doc, table, table_start=tbl_start, table_end=tbl_end)

            grid = _extract_table_grid(table, rows, cols)

            section_ps = safe_com(
                lambda t=table: t.Range.Sections(1).PageSetup)
            screenshot_f, coords = capture_table_screenshot(
                pdf_path=pdf_path,
                table_obj=table,
                section_page_setup=section_ps,
                pdf_zones=pdf_zones,
                output_folder=screenshot_folder,
                table_index=i,
            )

            return {
                "table_index":       i,
                # page_number is the Word-rendered DOCX page and may differ from the
                # original PDF page when conversion caused table reflow across pages.
                "page_number":       page_num,
                "docx_page_number":   page_num,
                "page_number_source": "word_com_rendered",
                "rows":              rows,
                "columns":           cols,
                "caption":           cap_info["caption_text"],
                "caption_position":  cap_info["caption_position"],
                "caption_style":     cap_info["caption_style"],
                "coordinates":       coords,
                "screenshot_file":   screenshot_f,
                "screenshot_folder": FOLDER_TABLE_SCREENSHOTS,
                "grid":              grid,
            }
    except Exception as exc:
        log_classified(exc, f"table_{i}")
        return {
            "table_index": i,
            "error": str(exc),
            "error_category": classify_exception(exc).category.value,
        }
    finally:
        release_com_refs(section_ps)